-- Run once in Supabase SQL Editor. Adds the "This Week" leaderboard. Nothing else is touched
-- (names, admin and score saving keep working). The week starts Monday 00:00 UTC.
create or replace view public.leaderboard_week_all as
  select min(name) as name, sum(kills)::int as kills, sum(deaths)::int as deaths,
         (count(*) filter (where won))::int as wins, count(*)::int as matches
  from public.scores
  where created_at >= date_trunc('week', now())
  group by lower(name);

create or replace view public.leaderboard_week_modes as
  select min(name) as name, mode, sum(kills)::int as kills, sum(deaths)::int as deaths,
         (count(*) filter (where won))::int as wins, count(*)::int as matches
  from public.scores
  where created_at >= date_trunc('week', now())
  group by lower(name), mode;

grant select on public.leaderboard_week_all, public.leaderboard_week_modes to anon, authenticated;
