// Bundle src/js/main.js into public/js/game.<name>.js without the full asset pipeline.
//   node scripts/bundle-only.mjs [name]      (default name: shop15)
// Keep <name> in sync with public/index.html and public/sw.js (also bump VERSION in sw.js).
import { build } from 'esbuild';
import fs from 'node:fs';
const name = process.argv[2] || 'shop15';
const r = await build({ entryPoints: ['src/js/main.js'], bundle: true, format: 'esm', target: ['es2022'], platform: 'browser',
    minify: true, legalComments: 'eof', write: false, logLevel: 'warning' });
for (const f of fs.readdirSync('public/js')) if (/^game\..+\.js$/.test(f) && f !== `game.${name}.js`) fs.unlinkSync('public/js/' + f);
fs.writeFileSync(`public/js/game.${name}.js`, r.outputFiles[0].contents);
console.log(`public/js/game.${name}.js`, (r.outputFiles[0].contents.length / 1024).toFixed(0) + ' KB');
