// obj2glb.mjs — converts the grenade OBJs (Blender export) into small, game-ready GLBs.
//   node scripts/obj2glb.mjs <in.obj> <out.glb> <targetHeightMetres> [simplifyRatio]
// Objects become named nodes (Body / Pin / Spoon) so the viewmodel can animate them;
// the whole model is recentred on the body and scaled to real-world size.
import fs from 'node:fs';
import { Document, NodeIO } from '@gltf-transform/core';
import { weld, simplify, unweld, normals } from '@gltf-transform/functions';
import { MeshoptSimplifier } from 'meshoptimizer';

const [inF, outF, hStr, rStr] = process.argv.slice(2);
const targetH = parseFloat(hStr), ratio = parseFloat(rStr || '1');
const lines = fs.readFileSync(inF, 'utf8').split('\n');
const mtl = {};
const mtlFile = inF.replace(/\.obj$/i, '.mtl');
if (fs.existsSync(mtlFile)) {
    let cur = null;
    for (const l of fs.readFileSync(mtlFile, 'utf8').split('\n')) {
        const p = l.trim().split(/\s+/);
        if (p[0] === 'newmtl') cur = mtl[p[1]] = { kd: [0.5, 0.5, 0.5], illum: 2 };
        else if (p[0] === 'Kd' && cur) cur.kd = p.slice(1, 4).map(Number);
        else if (p[0] === 'illum' && cur) cur.illum = +p[1];
    }
}
const V = [], N = [], objs = [];
let obj = null, mat = null;
for (const l of lines) {
    const p = l.trim().split(/\s+/);
    if (p[0] === 'v') V.push(p.slice(1, 4).map(Number));
    else if (p[0] === 'vn') N.push(p.slice(1, 4).map(Number));
    else if (p[0] === 'o') { obj = { name: p[1], groups: {} }; objs.push(obj); }
    else if (p[0] === 'usemtl') mat = p[1];
    else if (p[0] === 'f') {
        const g = (obj.groups[mat] ||= { tris: [] });
        const c = p.slice(1).map(t => { const s = t.split('/'); return [+s[0] - 1, +s[2] - 1]; });
        for (let i = 1; i < c.length - 1; i++) g.tris.push(c[0], c[i], c[i + 1]);
    }
}
const kind = n => /pin/i.test(n) ? 'Pin' : /spoon/i.test(n) ? 'Spoon' : 'Body';

// bounding box of the body → centre + scale
const bb = { min: [1e9, 1e9, 1e9], max: [-1e9, -1e9, -1e9] };
for (const o of objs) if (kind(o.name) === 'Body')
    for (const g of Object.values(o.groups)) for (const [vi] of g.tris)
        for (let k = 0; k < 3; k++) { bb.min[k] = Math.min(bb.min[k], V[vi][k]); bb.max[k] = Math.max(bb.max[k], V[vi][k]); }
const ctr = bb.min.map((m, k) => (m + bb.max[k]) / 2);
const s = targetH / (bb.max[1] - bb.min[1]);
console.log('body bbox', bb.min.map(n => n.toFixed(2)), bb.max.map(n => n.toFixed(2)), 'scale', s.toFixed(5));

const doc = new Document(); const buf = doc.createBuffer(); const scene = doc.createScene();
const mats = {};
for (const o of objs) {
    const node = doc.createNode(kind(o.name)); scene.addChild(node);
    const mesh = doc.createMesh(o.name); node.setMesh(mesh);
    for (const [mname, g] of Object.entries(o.groups)) {
        const map = new Map(), pos = [], nor = [], idx = [];
        for (const [vi, ni] of g.tris) {
            const key = vi + '/' + ni;
            let id = map.get(key);
            if (id === undefined) {
                id = pos.length / 3; map.set(key, id);
                const v = V[vi], n = N[ni] || [0, 1, 0];
                pos.push((v[0] - ctr[0]) * s, (v[1] - ctr[1]) * s, (v[2] - ctr[2]) * s); nor.push(...n);
            }
            idx.push(id);
        }
        const m = mtl[mname] || { kd: [0.5, 0.5, 0.5], illum: 2 };
        const gm = mats[mname] ||= doc.createMaterial(mname).setBaseColorFactor([...m.kd, 1])
            .setMetallicFactor(m.illum === 3 ? 0.75 : 0.1).setRoughnessFactor(m.illum === 3 ? 0.4 : 0.55);
        const prim = doc.createPrimitive();
        // normals are only kept when we are not decimating (decimation needs welded positions)
        if (ratio >= 1) prim.setAttribute('NORMAL', doc.createAccessor().setType('VEC3').setArray(new Float32Array(nor)).setBuffer(buf));
        mesh.addPrimitive(prim.setMaterial(gm)
            .setAttribute('POSITION', doc.createAccessor().setType('VEC3').setArray(new Float32Array(pos)).setBuffer(buf))
            .setIndices(doc.createAccessor().setType('SCALAR').setArray(new Uint32Array(idx)).setBuffer(buf)));
    }
}
await MeshoptSimplifier.ready;
const fns = [weld({ tolerance: 1e-5 })];
if (ratio < 1) fns.push(simplify({ simplifier: MeshoptSimplifier, ratio, error: 0.02, lockBorder: false }), unweld(), normals({ overwrite: true }));
await doc.transform(...fns);
// report per-part bounds (metres, model space) so animation pivots can be chosen
for (const n of scene.listChildren()) {
    const mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9]; let tris = 0;
    for (const pr of n.getMesh().listPrimitives()) {
        const a = pr.getAttribute('POSITION').getArray();
        for (let i = 0; i < a.length; i += 3) for (let k = 0; k < 3; k++) { mn[k] = Math.min(mn[k], a[i + k]); mx[k] = Math.max(mx[k], a[i + k]); }
        tris += (pr.getIndices() ? pr.getIndices().getCount() : a.length / 3) / 3;
    }
    console.log(n.getName().padEnd(6), 'tris', tris, 'min', mn.map(v => v.toFixed(3)).join(','), 'max', mx.map(v => v.toFixed(3)).join(','));
}
await new NodeIO().write(outF, doc);
console.log(outF, (fs.statSync(outF).size / 1024).toFixed(0) + ' KB');
