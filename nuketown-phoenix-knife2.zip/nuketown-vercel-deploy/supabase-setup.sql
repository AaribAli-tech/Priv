-- Run this once in Supabase: SQL Editor -> New query -> paste -> Run
create table public.scores (
  id bigint generated always as identity primary key,
  created_at timestamptz default now(),
  name text not null check (char_length(name) between 1 and 16),
  mode text not null check (mode in ('tdm','ffa','gun','ctl')),
  kills int not null check (kills between 0 and 100),
  deaths int not null check (deaths between 0 and 500),
  won boolean not null default false,
  secs int not null default 0 check (secs between 0 and 7200)
);
alter table public.scores enable row level security;
create policy "anyone can read"   on public.scores for select using (true);
create policy "anyone can submit" on public.scores for insert with check (true);
-- no update/delete policies: players cannot edit or remove scores
