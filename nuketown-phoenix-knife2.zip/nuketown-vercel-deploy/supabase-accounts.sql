-- Run once in Supabase SQL Editor. Unique permanent names + protected score submission.
create table public.players (
  name text primary key check (char_length(name) between 2 and 14),
  token text not null,
  created_at timestamptz default now()
);
alter table public.players enable row level security;  -- no policies = nobody can read tokens

create or replace function public.claim_name(p_name text, p_token text) returns text
language plpgsql security definer set search_path = public as $$
declare v text := upper(regexp_replace(trim(p_name), '\s+', ' ', 'g'));
begin
  if v !~ '^[A-Z0-9 _.-]{2,14}$' or length(p_token) < 16 then return 'invalid'; end if;
  insert into players(name, token) values (v, p_token);
  return 'ok';
exception when unique_violation then return 'taken';
end $$;

create or replace function public.submit_score(p_name text, p_token text, p_mode text, p_kills int, p_deaths int, p_won boolean) returns text
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from players where name = upper(p_name) and token = p_token) then return 'denied'; end if;
  insert into scores(name, mode, kills, deaths, won, secs)
  values (upper(p_name), p_mode, least(greatest(p_kills,0),100), least(greatest(p_deaths,0),500), coalesce(p_won,false), 0);
  return 'ok';
end $$;

grant execute on function public.claim_name(text,text), public.submit_score(text,text,text,int,int,boolean) to anon, authenticated;
drop policy if exists "anyone can submit" on public.scores;  -- scores can now only be added through submit_score
