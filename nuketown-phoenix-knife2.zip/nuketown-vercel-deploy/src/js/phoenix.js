// ============================================================================
// gign.js — Counter-Strike: Source GIGN as the bot model.
//
// The mesh, textures and animation come from CS:S files (ct_gign.mdl/.vvd/.vtx,
// cs_player_shared.mdl). They were converted offline into assets/phoenix/:
//   phoenix.json  layout + animation table      phoenix.bin  mesh, skin weights, poses
//   ct_gign.jpg / ct_gign_glass.png  textures
// Every pose is a baked set of 50 bone matrices (12 floats each) plus the point
// where a weapon is held, one table per weapon type × {idle, walk, run, cidle,
// cwalk}. Skinning runs on the CPU (5 k vertices), so there is no skeleton.
//
// It is a drop-in rig: same surface as RebelSoldier / AnimatedSoldier, and it
// holds the game's own procedural weapons via createWorldWeapon().
//
//   ?gign=off | enemy | all     in the game URL  (default: all)
// ============================================================================
import * as THREE from 'three';
import { createWorldWeapon, WEAPON_GRIPS } from './weapons.js';
import { TEAM_B } from './utils.js';

const BASE = 'assets/phoenix/';
const SCALE = 0.92;            // the CS:S model is ~1.96 m; the game's soldiers are ~1.8 m
const FADE = 0.15;             // seconds of cross-fade between poses
const WALK_REF = 2.1, RUN_REF = 5.2;   // m/s each clip was authored for

const S = { status: 'off', mode: 'enemy', meta: null, bin: null, tex: {}, err: '' };
try {
    const q = new URLSearchParams(location.search).get('phoenix');
    if (q === 'off' || q === 'all' || q === 'enemy') S.mode = q;
} catch { /* no URL to read */ }

export function phoenixMode() { return S.mode; }
export function setPhoenixMode(m) { if (m === 'off' || m === 'all' || m === 'enemy') S.mode = m; return S.mode; }
export function phoenixActive(team) {
    return S.status === 'ready' && (S.mode !== 'off' && team === TEAM_B);
}

/** Build the shared data from already-fetched pieces (also used by the node test). */
export function initPhoenix(meta, buf, textures) {
    const L = meta.layout, nv = meta.nv;
    const f32 = (k, n) => new Float32Array(buf, L[k], n);
    S.meta = meta;
    S.d = {
        pos: f32('pos', nv * 3), nor: f32('nor', nv * 3), uv: f32('uv', nv * 2), sw: f32('sw', nv * 3),
        si: new Uint8Array(buf, L.si, nv * 3), nb: new Uint8Array(buf, L.nb, nv),
        anim: new Float32Array(buf, L.anim),
        idx: meta.groups.map(g => new Uint16Array(buf, g.off, g.count))
    };
    S.tex = textures;
    HAND_VERTS = [];
    for (let v = 0; v < nv; v++) {
        let best = 0;
        for (let k = 1; k < d.nb[v]; k++) if (d.sw[v * 3 + k] > d.sw[v * 3 + best]) best = k;
        if (HAND_BONES.includes(d.si[v * 3 + best])) HAND_VERTS.push(v);
    }
    S.status = 'ready';
    return true;
}

export async function loadPhoenix(base = BASE) {
    if (S.mode === 'off') return false;
    if (S.status === 'ready') return true;
    S.status = 'loading';
    try {
        const [meta, buf] = await Promise.all([
            fetch(base + 'phoenix.json').then(r => { if (!r.ok) throw new Error('phoenix.json ' + r.status); return r.json(); }),
            fetch(base + 'phoenix.bin').then(r => { if (!r.ok) throw new Error('phoenix.bin ' + r.status); return r.arrayBuffer(); })
        ]);
        const loader = new THREE.TextureLoader();
        const load = (u) => new Promise((res, rej) => loader.load(base + u, t => {
            t.flipY = false;                       // Source UVs have v = 0 at the top
            t.colorSpace = THREE.SRGBColorSpace;
            t.anisotropy = 4;
            res(t);
        }, undefined, rej));
        const body = await load('phoenix.jpg');
        return initPhoenix(meta, buf, { phoenix: body });
    } catch (err) {
        S.status = 'failed';
        S.err = String((err && err.message) || err);
        console.warn('[phoenix] model unavailable, soldiers stay as they were —', S.err);
        return false;
    }
}

const _wp = new THREE.Vector3();
const HAND_BONES = [17, 18, 19, 20];     // right hand + fingers in the CS:S GIGN rig
let HAND_VERTS = [];

export class PhoenixSoldier {
    constructor(team, weaponType = 'rifle') {
        this.isPhoenix = true;
        this.deadT = -1;               // must exist before setWeapon() decides visibility
        this.team = team;
        this.root = new THREE.Group();
        this.tilt = new THREE.Group();          // death fold; ai.js owns root's position/yaw
        this.model = new THREE.Group();         // Source faces +X, the game faces -Z
        this.model.rotation.y = Math.PI / 2;
        this.model.scale.setScalar(SCALE);
        this.model.position.y = 0.0;            
        this.tilt.add(this.model);
        this.root.add(this.tilt);

        const d = S.d, nv = S.meta.nv;
        this.pos = new Float32Array(nv * 3);
        this.nor = new Float32Array(nv * 3);
        const pa = new THREE.BufferAttribute(this.pos, 3), na = new THREE.BufferAttribute(this.nor, 3);
        pa.setUsage(THREE.DynamicDrawUsage); na.setUsage(THREE.DynamicDrawUsage);
        this.pa = pa; this.na = na;
        this.geos = []; this.mats = [];
        const uv = new THREE.BufferAttribute(d.uv, 2);
        S.meta.groups.forEach((g, i) => {
            const geo = new THREE.BufferGeometry();
            geo.setAttribute('position', pa); geo.setAttribute('normal', na); geo.setAttribute('uv', uv);
            geo.setIndex(new THREE.BufferAttribute(d.idx[i], 1));
            const glass = g.tex.indexOf('glass') >= 0;
            // enemies get a red cast so the two sides stay readable in an all-GIGN match
            const tint = new THREE.Color(2.0, 1.75, 1.7);   // texture is very dark; lift it and give a slight red cast
            const mat = glass
                ? new THREE.MeshStandardMaterial({ map: S.tex[g.tex], transparent: true, opacity: 0.55, roughness: 0.2, side: THREE.DoubleSide, depthWrite: false })
                : new THREE.MeshStandardMaterial({ map: S.tex[g.tex], color: tint, roughness: 0.85, metalness: 0.0 });
            const mesh = new THREE.Mesh(geo, mat);
            mesh.frustumCulled = false;         // the box of the bind pose is not the box being drawn
            mesh.castShadow = !glass;
            this.model.add(mesh);
            this.geos.push(geo); this.mats.push(mat);
        });

        this.weaponType = null;
        this.weaponMount = new THREE.Group();
        this.root.add(this.weaponMount);
        this.muzzle = new THREE.Group();
        this.weaponMount.add(this.muzzle);
        this.setWeapon(weaponType);

        const flashMat = new THREE.MeshBasicMaterial({ color: 0xffd27a, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending });
        this.flashA = new THREE.Mesh(new THREE.SphereGeometry(0.075, 6, 5), flashMat);
        this.flashB = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.22, 6), flashMat.clone());
        this.flashB.rotation.x = -Math.PI / 2;
        this.flashB.position.z = -0.12;
        this.muzzle.add(this.flashA, this.flashB);

        this.flashTimer = 0;
        this.deadT = -1;
        this.aimPitch = 0; this.lookYaw = 0;
        this.speed = 0; this.crouch = 0;
        this._shadows = true;
        this._opacity = 1;

        const n = S.meta.stride;
        this.cur = new Float32Array(n);       // pose being played
        this.prev = new Float32Array(n);      // pose being faded out of
        this.out = new Float32Array(n);       // what is skinned
        this.state = 'idle'; this.t = Math.random() * 1.5; this.fade = 1;
        this._sample(0, true);
        this.out.set(this.cur);
        this._skin();
        this._placeWeapon();
    }

    setWeapon(type) {
        if (this.weaponType === type) return;
        if (this.weapon) {
            this.weaponMount.remove(this.weapon);
            this.weapon.traverse(o => { if (o.isMesh) o.geometry.dispose(); });
        }
        this.weaponType = type;
        this.weapon = createWorldWeapon(type);
        const g = WEAPON_GRIPS[type] || WEAPON_GRIPS.rifle;
        this.weapon.position.copy(g.rear).negate();
        this.weaponMount.add(this.weapon);
        this.muzzle.position.copy(g.muzzle).sub(g.rear);
        this.weapon.visible = this.deadT < 0;
    }

    fireFlash() { this.flashTimer = 0.055; }

    startDeath() { this.deadT = 0; if (this.weapon) this.weapon.visible = false; }

    resetPose() {
        this.deadT = -1;
        this.speed = 0; this.crouch = 0;
        if (this.weapon) this.weapon.visible = true;
        this.tilt.rotation.set(0, 0, 0);
        this.tilt.position.set(0, 0, 0);
        this.model.rotation.set(0, Math.PI / 2, 0);
        this.model.visible = true;
        this.setOpacity(1);
        this.root.position.y = 0;
        this.state = 'idle'; this.t = 0; this.fade = 1;
    }

    setShadows(on) {
        if (this._shadows === on) return;
        this._shadows = on;
        this.model.traverse(o => { if (o.isMesh && !(o.material && o.material.transparent && o.material.map === S.tex.__none)) o.castShadow = on; });
    }

    setOpacity(v) {
        if (v === this._opacity) return;
        this._opacity = v;
        this.mats.forEach((m, i) => {
            const glass = S.meta.groups[i].tex.indexOf('glass') >= 0;
            m.transparent = v < 1 || glass;
            m.opacity = glass ? 0.55 * v : v;
            m.depthWrite = !glass && v >= 1;
            m.needsUpdate = true;
        });
    }

    _pick(speed) {
        if (this.crouch > 0.5) return speed > 0.3 ? 'cwalk' : 'cidle';
        if (speed <= 0.3) return 'idle';
        return speed < (WALK_REF + RUN_REF) / 2 ? 'walk' : 'run';
    }

    /** Advance the clip and write the (cross-faded) pose into this.out. */
    _sample(dt, snap) {
        const A = S.meta.anim[this.weaponType] || S.meta.anim.rifle;
        const want = this._pick(this.speed);
        if (want !== this.state && !snap) { this.prev.set(this.out); this.fade = 0; this.state = want; this.t = 0; }
        const e = A[this.state], n = S.meta.stride;
        const ref = this.state === 'run' ? RUN_REF : (this.state === 'walk' || this.state === 'cwalk') ? WALK_REF : 1;
        const rate = (this.state === 'idle' || this.state === 'cidle') ? 1 : Math.min(1.5, Math.max(0.6, this.speed / ref));
        this.t += dt * e.fps * rate;
        const f = ((this.t % e.n) + e.n) % e.n, i = Math.floor(f), j = (i + 1) % e.n, k = f - i;
        const base = e.off, a = S.d.anim, cur = this.cur;
        const oa = base + i * n, ob = base + j * n;
        for (let q = 0; q < n; q++) cur[q] = a[oa + q] * (1 - k) + a[ob + q] * k;
        this.fade = Math.min(1, this.fade + dt / FADE);
        const out = this.out, prev = this.prev, w = this.fade;
        if (w >= 1) out.set(cur);
        else for (let q = 0; q < n; q++) out[q] = prev[q] * (1 - w) + cur[q] * w;
    }

    _skin() {
        const d = S.d, M = this.out, nv = S.meta.nv, P = d.pos, N = d.nor, sw = d.sw, si = d.si, nb = d.nb, op = this.pos, on = this.nor;
        for (let v = 0, v3 = 0; v < nv; v++, v3 += 3) {
            let x = 0, y = 0, z = 0, nx = 0, ny = 0, nz = 0;
            const px = P[v3], py = P[v3 + 1], pz = P[v3 + 2], qx = N[v3], qy = N[v3 + 1], qz = N[v3 + 2];
            for (let k = 0, c = nb[v]; k < c; k++) {
                const w = sw[v3 + k], o = si[v3 + k] * 12;
                x += w * (M[o] * px + M[o + 1] * py + M[o + 2] * pz + M[o + 9]);
                y += w * (M[o + 3] * px + M[o + 4] * py + M[o + 5] * pz + M[o + 10]);
                z += w * (M[o + 6] * px + M[o + 7] * py + M[o + 8] * pz + M[o + 11]);
                nx += w * (M[o] * qx + M[o + 1] * qy + M[o + 2] * qz);
                ny += w * (M[o + 3] * qx + M[o + 4] * qy + M[o + 5] * qz);
                nz += w * (M[o + 6] * qx + M[o + 7] * qy + M[o + 8] * qz);
            }
            op[v3] = x; op[v3 + 1] = y; op[v3 + 2] = z;
            on[v3] = nx; on[v3 + 1] = ny; on[v3 + 2] = nz;
        }
        this.pa.needsUpdate = true; this.na.needsUpdate = true;
    }

    // the weapon is held where the CS:S rig holds one (its weapon bone), carried
    // into the game's frame: model space → +90° about Y → scale
    _placeWeapon() {
        if (!this.weapon) return;
        // Grip the gun at the skinned right hand (bones 17-20) rather than the
        // baked weapon point, which sits ~0.25 m off the palm and made it float.
        const H = HAND_VERTS, p = this.pos;
        let x = 0, y = 0, z = 0;
        for (let i = 0; i < H.length; i++) { const v = H[i] * 3; x += p[v]; y += p[v + 1]; z += p[v + 2]; }
        const n = H.length || 1;
        _wp.set(z / n, y / n, -x / n).multiplyScalar(SCALE);
        this.weaponMount.position.copy(_wp);
        this.weaponMount.rotation.set(this.aimPitch, 0, 0);
    }

    _flash(dt) {
        if (this.flashTimer > 0) {
            this.flashTimer -= dt;
            const o = Math.max(0, this.flashTimer / 0.055), s = 0.8 + Math.random() * 0.7;
            this.flashA.material.opacity = o;
            this.flashB.material.opacity = o * 0.9;
            this.flashA.scale.setScalar(s);
            this.flashB.scale.set(s, 1, s);
        } else if (this.flashA.material.opacity !== 0) {
            this.flashA.material.opacity = 0;
            this.flashB.material.opacity = 0;
        }
    }

    _death() {
        const t = Math.min(1, this.deadT / 0.85), e = 1 - Math.pow(1 - t, 3);
        this.tilt.rotation.x = -1.35 * e;
        this.tilt.position.y = -0.30 * e;
        this.model.rotation.z = 0.25 * e;
        if (this.deadT > 4.0) this.setOpacity(Math.max(0, 1 - (this.deadT - 4.0)));
    }

    /** state: { speed, aiming, crouching, aimPitch, lookYaw } — as AnimatedSoldier. */
    update(dt, state) {
        if (this.deadT >= 0) { this.deadT += dt; this._death(); return; }
        this.speed += ((state.speed || 0) - this.speed) * Math.min(1, dt * 8);
        this.crouch += ((state.crouching ? 1 : 0) - this.crouch) * Math.min(1, dt * 9);
        const pitch = THREE.MathUtils.clamp(state.aimPitch || 0, -0.8, 0.8);
        const yaw = THREE.MathUtils.clamp(state.lookYaw || 0, -0.7, 0.7);
        this.aimPitch += (pitch - this.aimPitch) * Math.min(1, dt * 10);
        this.lookYaw += (yaw - this.lookYaw) * Math.min(1, dt * 10);
        this._sample(dt, false);
        if (this.root.visible) { this._skin(); this._placeWeapon(); }
        this._flash(dt);
    }

    muzzleWorld(out) {
        this.muzzle.updateWorldMatrix(true, false);
        return out.setFromMatrixPosition(this.muzzle.matrixWorld);
    }

    dispose() {
        // textures and the index/uv buffers are shared; the per-bot buffers go
        for (const g of this.geos) g.dispose();
        for (const m of this.mats) m.dispose();
        if (this.weapon) this.weapon.traverse(o => { if (o.isMesh) o.geometry.dispose(); });
        this.flashA.material.dispose();
        this.flashB.material.dispose();
    }

    get hand() { return this.weaponMount; }
}
