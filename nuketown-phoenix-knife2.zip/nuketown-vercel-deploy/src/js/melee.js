// ============================================================================
// melee.js — combat knife (slot 3). Self-contained, like grenades.js: its own
// first-person rig in the viewmodel scene, hides the gun while drawn, and any
// loadout / mode can use it (key 3, or the touch KNIFE button).
// Model: CS:S v_knife_t converted offline to assets/models/wpn_knife.glb.
// ============================================================================
import * as THREE from 'three';
import * as M from './materials.js';
import { loadGLB } from './glb.js';
import { playWeaponSwap, playJump } from './audio.js';

const HIP = new THREE.Vector3(0.17, -0.20, -0.34);
const DRAW_T = 0.30, HIT_AT = 0.17, SLASH_T = 0.42;
const RANGE = 2.3, CONE = 0.70, DAMAGE = 100;
const UP = new THREE.Vector3(0, 1, 0);
const ease = t => { t = Math.min(1, Math.max(0, t)); return t * t * (3 - 2 * t); };
const _e = new THREE.Vector3(), _t = new THREE.Vector3(), _f = new THREE.Vector3();

export class Melee {
    constructor({ vm, cw, camera, player, getBots, onHit }) {
        Object.assign(this, { vm, cw, camera, player, getBots, onHit });
        this.active = false; this.state = 'none'; this.t = 0;
        this.combo = 0; this.dir = 1; this.hit = false; this._wasDown = false;
        this.asset = null; this.rig = null;
        loadGLB('assets/models/wpn_knife.glb', true).then(g => { this.asset = g; });
    }

    equip() {
        const p = this.player;
        if (!p.alive || p.paused) return;
        if (this.active) return this.unequip();
        const g = p.ctx && p.ctx.grenades; if (g && g.active) g.unequip();
        if (this.state === 'slash') return;
        const r = this._rig();
        r.root.visible = true; this.active = true; this.state = 'draw'; this.t = 0;
        this.vm.holder.visible = false;
        p.mouseRight = false; p.isADS = false;
        playWeaponSwap();
    }

    unequip() {
        if (!this.active) return;
        if (this.rig) this.rig.root.visible = false;
        this.active = false; this.state = 'none';
        this.vm.holder.visible = true;
    }

    reset() { this.unequip(); this.combo = 0; }

    update(dt) {
        const p = this.player;
        if (!this.active) return;
        if (!p.alive) return this.unequip();
        const down = p.mouseDown || p.touch.fire;
        const edge = down && !this._wasDown; this._wasDown = down;
        if (p.paused) return;
        this.t += dt;
        if (this.state === 'draw' && this.t >= DRAW_T) { this.state = 'idle'; this.t = 0; }
        if (this.state === 'idle' && edge) this._swing();
        if (this.state === 'slash') {
            if (!this.hit && this.t >= HIT_AT) { this.hit = true; this._strike(); }
            if (this.t >= SLASH_T) { this.state = 'idle'; this.t = 0; }
        }
        this._pose(this.rig, dt);
    }

    _swing() {
        this.state = 'slash'; this.t = 0; this.hit = false;
        this.dir = -this.dir; this.combo = (this.combo + 1) % 3;    // every third is a lunge
        playJump();
    }

    _strike() {
        const p = this.player, cam = this.camera;
        cam.getWorldDirection(_f);
        _e.copy(cam.position);
        let best = null, bd = 1e9;
        for (const bot of this.getBots()) {
            if (!bot.alive || !p.canShoot(bot)) continue;
            _t.set(bot.position.x, bot.position.y + 1.0, bot.position.z).sub(_e);
            const d = _t.length();
            if (d > RANGE || d >= bd) continue;
            if (_t.divideScalar(d || 1).dot(_f) < CONE) continue;
            _t.set(bot.position.x, bot.position.y + 1.0, bot.position.z);
            if (d > 1.0 && !this.cw.isLineOfSight(_e, _t)) continue;
            best = bot; bd = d;
        }
        if (!best) return;
        const killed = best.takeDamage(DAMAGE, p.name);
        this.onHit(best, killed, false, { short: 'KNIFE', name: 'COMBAT KNIFE' });
    }

    _rig() {
        if (this.rig && this.rig.fallback && this.asset) { this.vm.scene.remove(this.rig.root); this.rig = null; }
        if (this.rig) return this.rig;
        const glove = M.glove(), sleeve = M.camoBlue();
        const root = new THREE.Group(); root.position.copy(HIP);
        const blade = new THREE.Group(); root.add(blade);       // knife frame: tip -Z, spine +Y
        let fallback = true;
        if (this.asset) { blade.add(this.asset.scene.clone(true)); fallback = false; }
        else blade.add(new THREE.Mesh(new THREE.BoxGeometry(0.008, 0.04, 0.3), new THREE.MeshStandardMaterial({ color: 0x9aa0a6, metalness: 0.8, roughness: 0.4 })));
        const box = (w, h, d, x, y, z, rx = 0) => {
            const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), glove);
            m.position.set(x, y, z); m.rotation.x = rx; blade.add(m); return m;
        };
        // fist wrapped round the handle (handle centre ~ z 0.03), thumb along the spine
        box(0.050, 0.046, 0.075, 0, -0.004, 0.035);
        for (let i = 0; i < 4; i++) box(0.056, 0.014, 0.016, 0, -0.030, 0.006 + i * 0.019, 0.2);
        box(0.018, 0.016, 0.050, 0.004, 0.030, 0.030);
        const dir = new THREE.Vector3(0.12, -0.45, 0.62), len = 0.5;
        const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.040, 0.056, len, 10), sleeve);
        const cuff = new THREE.Mesh(new THREE.CylinderGeometry(0.034, 0.036, 0.05, 10), glove);
        const a = new THREE.Group(); arm.position.y = len / 2 + 0.05; cuff.position.y = 0.025; a.add(cuff, arm);
        a.quaternion.setFromUnitVectors(UP, dir.normalize()); a.position.set(0, -0.01, 0.06);
        blade.add(a);
        root.visible = false;
        this.vm.scene.add(root);
        return (this.rig = { root, blade, fallback });
    }

    _pose(r, dt) {
        const { root, blade } = r;
        // follow the camera the way the guns do: walk bob, look sway, sprint tilt, landing dip
        const v = this.vm, sp = v.sprint || 0;
        const bobT = v.bobT || 0, br = (v.breath || 0) * 1.6;
        let x = HIP.x + Math.sin(bobT) * 0.014 + (v.swayX || 0) * 1.4;
        let y = HIP.y + (Math.abs(Math.cos(bobT)) - 0.5) * 0.016 + Math.sin(br) * 0.004 + (v.swayY || 0) * 1.4 - (v.landDip || 0);
        let z = HIP.z, rx = 0.42 + (v.swayY || 0) * -2.2, ry = 0.30 + (v.swayX || 0) * 2.6, rz = -0.10 + Math.sin(bobT) * 0.03;
        // sprinting: knife drops and angles across the body, like a run pose
        x -= 0.05 * sp; y -= 0.05 * sp; z += 0.02 * sp; rx += 0.35 * sp; ry += 0.55 * sp; rz -= 0.25 * sp;
        if (this.state === 'draw') {
            const k = 1 - ease(this.t / DRAW_T);
            y -= 0.28 * k; x += 0.10 * k; rx -= 0.7 * k;
        } else if (this.state === 'slash') {
            const t = this.t, s = this.dir;
            const wind = ease(t / 0.09), swing = ease((t - 0.07) / 0.14), back = ease((t - 0.24) / 0.18);
            const k = (wind * (1 - swing)) * -1 + swing * (1 - back);      // -1 wound back .. +1 follow-through
            if (this.combo === 0) {                                       // lunge forward
                const th = swing * (1 - back);
                z -= 0.20 * th - 0.05 * wind * (1 - swing); x -= 0.08 * th; rx += 0.25 * th - 0.2 * wind * (1 - swing);
            } else {                                                      // horizontal slash, alternating sides
                x += -s * 0.22 * k; y += 0.03 * Math.abs(k); z -= 0.05 * Math.abs(k);
                ry += s * 0.9 * k; rz += s * 0.5 * k; rx += 0.1 * Math.abs(k);
            }
        }
        root.position.set(x, y, z);
        root.rotation.set(rx, ry, rz);
        void blade; void dt;
    }
}
