// cinematic.js - match intro (flyover, team lineup, 3-2-1-GO) and the ending
// (slow-mo final kill, killer's-eye killcam, MVP). It only drives the camera,
// a few overlays and a time scale; main.js owns the match itself.
import * as THREE from 'three';

const $ = (id) => document.getElementById(id);
const clamp01 = (x) => Math.max(0, Math.min(1, x));
const sm = (x) => x * x * (3 - 2 * x);
const esc = (s) => String(s).replace(/[&<>]/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m]));
const FLY = 3.0, LINE = 4.8, GO = 7.8, END = 8.6;   // intro timeline, seconds
const SLOW = 3.0, MVP_T = 3.0, SLOW_SCALE = 0.3;     // ending

let c = null, phase = 'off', t = 0, sc = 1, root = null;
let onGo = null, onDone = null, curve = null, a0 = 0, went = false, hudOn = false, lastN = -1;
let mvp = null, kill = null, killAt = 0, finished = false;
const orbitC = new THREE.Vector3(), look0 = new THREE.Vector3(0, 3, 0);
const _p = new THREE.Vector3(), _l = new THREE.Vector3(), _pp = new THREE.Vector3(), _t = new THREE.Vector3();
const _pq = new THREE.Quaternion();

export function init(ctx) { c = ctx; }
export const timeScale = () => sc;
export const busy = () => phase !== 'off';
export const introActive = () => phase === 'intro' && t < GO;
export const frozen = () => introActive() || phase === 'slow' || phase === 'mvp';
export const hideVM = () => (phase === 'intro' && t < LINE - 0.4) || (phase === 'slow' && !(kill && kill.byPlayer)) || phase === 'mvp';

const CSS = `#ntc{position:fixed;inset:0;z-index:9000;pointer-events:none;font-family:Teko,Rajdhani,sans-serif;color:#fff;overflow:hidden}
#ntc .bar{position:absolute;left:0;right:0;height:0;background:#000;transition:height .7s cubic-bezier(.2,.8,.2,1)}
#ntc .bar.t{top:0}#ntc .bar.b{bottom:0}#ntc.lb .bar{height:11vh}
#ntcFade{position:absolute;inset:0;background:#000;opacity:0}
#ntc .bx{position:absolute;left:0;right:0;text-align:center;opacity:0;transform:translateY(16px);transition:opacity .4s,transform .5s}
#ntc .bx.on{opacity:1;transform:none}
#ntcTitle{top:17vh}#ntcTitle b{display:block;font-size:min(15vw,112px);letter-spacing:.3em;font-weight:600;text-shadow:0 4px 30px #000}
#ntcTitle span{font-size:min(5vw,26px);letter-spacing:.5em;color:#ffb02e}
#ntcLine{top:30vh;display:flex;justify-content:center;gap:min(9vw,80px)}#ntcLine .col{min-width:min(34vw,220px)}
#ntcLine h4{margin:0 0 6px;font-size:26px;letter-spacing:.3em;color:#5ab0ff;font-weight:600}#ntcLine .r h4{color:#ff5a4a}
#ntcLine p{margin:0;font-size:24px;letter-spacing:.12em;text-shadow:0 2px 8px #000}#ntcLine p.me{color:#ffd23a}
#ntcCount{position:absolute;left:0;right:0;top:50%;margin-top:-.62em;text-align:center;font-size:min(32vw,230px);font-weight:700;opacity:0;text-shadow:0 6px 40px #000;line-height:1.1}
#ntcCount.pop{animation:ntcPop .95s ease-out}
@keyframes ntcPop{0%{transform:scale(2.4);opacity:0}22%{transform:scale(1);opacity:1}70%{opacity:1}100%{transform:scale(.88);opacity:0}}
#ntcTag{bottom:15vh}#ntcTag small{display:block;color:#ff4d3a;letter-spacing:.5em;font-size:22px}#ntcTag b{display:block;font-size:min(9vw,54px);letter-spacing:.1em;font-weight:600;text-shadow:0 3px 14px #000}#ntcTag span{font-size:24px;letter-spacing:.3em;color:#ffb02e}
#ntcMvp{top:16vh}#ntcMvp small{display:block;color:#ffd23a;letter-spacing:.5em;font-size:26px}#ntcMvp b{display:block;font-size:min(14vw,100px);letter-spacing:.12em;font-weight:600;color:#ffd23a;text-shadow:0 4px 30px #000}#ntcMvp span{font-size:28px;letter-spacing:.25em}
#ntcSkip{position:absolute;bottom:3.5vh;left:0;right:0;text-align:center;font:600 14px Rajdhani,sans-serif;letter-spacing:.3em;color:#aaa;display:none}
@media (max-width:700px),(max-height:520px){#ntcTitle{top:14vh}#ntcLine{top:20vh;gap:5vw}#ntcLine h4{font-size:15px;letter-spacing:.15em}#ntcLine p{font-size:15px;letter-spacing:.05em;line-height:1.15}
#ntcLine .col{min-width:38vw}#ntcTitle span{letter-spacing:.25em}#ntcTag{bottom:13vh}#ntcTag small{font-size:14px}#ntcMvp{top:14vh}#ntcMvp small{font-size:16px}#ntcSkip{font-size:12px;bottom:max(2vh,env(safe-area-inset-bottom))}}
@media (max-height:520px){#ntc.lb .bar{height:8vh}#ntcCount{font-size:min(30vh,230px)}}
#ntMvpLine{font:600 22px Rajdhani,sans-serif;margin:4px 0;color:#ddd}#ntMvpLine b{color:#ffd23a}`;

function dom() {
    if (root) return;
    const st = document.createElement('style'); st.textContent = CSS; document.head.appendChild(st);
    root = document.createElement('div'); root.id = 'ntc';
    root.innerHTML = '<div class="bar t"></div><div class="bar b"></div><div id="ntcFade"></div>' +
        '<div class="bx" id="ntcTitle"></div><div class="bx" id="ntcLine"></div><div id="ntcCount"></div>' +
        '<div class="bx" id="ntcTag"></div><div class="bx" id="ntcMvp"></div><div id="ntcSkip">TAP TO SKIP</div>';
    document.body.appendChild(root);
    addEventListener('keydown', (e) => { if (phase !== 'off' && (e.code === 'Enter' || e.code === 'Space')) skip(); });
    addEventListener('pointerdown', () => { if (phase !== 'off') skip(); });
}
function flash(o) {
    const f = $('ntcFade'); f.style.transition = 'none'; f.style.opacity = o; void f.offsetWidth;
    f.style.transition = 'opacity .55s'; f.style.opacity = 0;
}
function say(s) {
    try {
        if (c.audio.isMuted && c.audio.isMuted()) return;
        const u = new SpeechSynthesisUtterance(s); u.rate = 1.05; u.pitch = 0.5; u.volume = 0.9;
        speechSynthesis.cancel(); speechSynthesis.speak(u);
    } catch { /* no speech support */ }
}
function count(text, go) {
    const el = $('ntcCount'); el.textContent = text; el.style.color = go ? '#7dff8a' : '#fff';
    el.classList.remove('pop'); void el.offsetWidth; el.classList.add('pop');
    if (!go && c.audio.playCountdown) c.audio.playCountdown();
    say(go ? 'Go!' : text);
}
function orbit(a, R, h, out) { out.set(orbitC.x + Math.cos(a) * R, orbitC.y + h, orbitC.z + Math.sin(a) * R); }
const show = (id, on) => $(id).classList.toggle('on', on);

export function cancel() {
    phase = 'off'; sc = 1; t = 0; finished = false;
    if (root) {
        root.classList.remove('lb');
        for (const id of ['ntcTitle', 'ntcLine', 'ntcTag', 'ntcMvp']) show(id, false);
        $('ntcCount').classList.remove('pop'); $('ntcCount').style.opacity = 0;
        $('ntcSkip').style.display = 'none'; $('ntcFade').style.opacity = 0;
    }
    try { speechSynthesis.cancel(); } catch { /* ignore */ }
}

// ---------------------------------------------------------------- intro
export function intro(o) {
    cancel(); dom(); kill = null; mvp = null;
    const p = c.player();
    phase = 'intro'; t = 0; went = false; hudOn = false; lastN = -1; onGo = o.onGo;
    orbitC.set(p.position.x, 1.5, p.position.z);
    a0 = Math.atan2(-Math.cos(p.yaw), -Math.sin(p.yaw));      // start in front of the player
    orbit(a0, 6, 2.4, _p);
    curve = new THREE.CatmullRomCurve3([new THREE.Vector3(-54, 28, -46), new THREE.Vector3(-26, 16, -30),
        new THREE.Vector3(4, 9, -16), new THREE.Vector3(20, 7, 6), _p.clone()], false, 'centripetal');
    const bots = c.bots(), me = esc(c.playerName());
    const col = (title, names, cls, you) => `<div class="col ${cls}"><h4>${title}</h4>${you ? `<p class="me">${me}</p>` : ''}${names.map(n => `<p>${esc(n)}</p>`).join('')}</div>`;
    $('ntcLine').innerHTML = col('YOUR TEAM', bots.filter(b => b.team === c.teamA).map(b => b.name), '', true) +
        col('ENEMY TEAM', bots.filter(b => b.team !== c.teamA).map(b => b.name), 'r', false);
    $('ntcTitle').innerHTML = `<b>NUKETOWN</b><span>${esc(o.modeName || '')}</span>`;
    c.hud.show(false);
    root.classList.add('lb'); $('ntcSkip').style.display = 'block'; flash(1);
}

// -------------------------------------------------------------- ending
export function noteKill(k) { kill = k; killAt = performance.now(); }

export function finale(done) {
    if (finished || phase === 'slow' || phase === 'mvp') return;
    dom(); onDone = done; t = 0;
    c.hud.show(false); c.hud.hideDeath();
    root.classList.add('lb'); $('ntcSkip').style.display = 'block';
    if (kill && performance.now() - killAt < 1500) {
        phase = 'slow';
        $('ntcTag').innerHTML = `<small>KILLCAM</small><b>${esc(kill.killerName)} &#9656; ${esc(kill.victimName)}</b><span>${esc(kill.weapon || '')}${kill.head ? ' &middot; HEADSHOT' : ''}</span>`;
        if (c.audio.duckAudio) c.audio.duckAudio(0.35, 3.5);
        if (!kill.byPlayer) flash(0.8);
    } else startMvp();
}
function pickMvp() {
    const p = c.player();
    const list = [{ name: c.playerName(), kills: p.matchKills, deaths: p.deaths, you: true, obj: p }];
    for (const b of c.bots()) list.push({ name: b.name, kills: b.kills || 0, deaths: b.deaths || 0, you: false, obj: b });
    return list.sort((a, b) => b.kills - a.kills || a.deaths - b.deaths)[0];
}
function startMvp() {
    phase = 'mvp'; t = 0; sc = 1; mvp = pickMvp();
    show('ntcTag', false);
    $('ntcMvp').innerHTML = `<small>&#9819; MATCH MVP &#9819;</small><b>${esc(mvp.name)}${mvp.you ? ' (YOU)' : ''}</b><span>${mvp.kills} KILLS &middot; ${mvp.deaths} DEATHS</span>`;
    flash(0.8);
}
function finish() {
    const f = onDone; onDone = null;
    if (mvp) {
        let el = $('ntMvpLine');
        if (!el) { el = document.createElement('div'); el.id = 'ntMvpLine'; const s = $('endStats'); s.parentNode.insertBefore(el, s); }
        el.innerHTML = `MVP <b>${esc(mvp.name)}</b> &middot; ${mvp.kills} kills`;
    }
    cancel(); finished = true;
    if (f) f();
}
function skip() {
    if (phase === 'intro' && t < LINE) t = LINE;
    else if (phase === 'slow' && t > 0.8) startMvp();
    else if (phase === 'mvp' && t > 1.2) finish();
}

// ---------------------------------------------------------- per frame
/** dt is REAL seconds (not slowed). */
export function update(dt) {
    if (phase === 'off') return;
    t += dt;
    if (phase === 'intro') {
        show('ntcTitle', t > 0.3 && t < FLY - 0.2);
        show('ntcLine', t >= FLY && t < LINE);
        if (t >= LINE && !hudOn) { hudOn = true; c.hud.show(true); root.classList.remove('lb'); $('ntcSkip').style.display = 'none'; }
        if (t >= LINE) {
            const n = t < GO ? 3 - Math.floor(t - LINE) : 0;
            if (n !== lastN) { lastN = n; count(n ? String(n) : 'GO!', !n); }
        }
        if (t >= GO && !went) { went = true; if (onGo) onGo(); }
        if (t >= END) { const keep = finished; cancel(); finished = keep; }
    } else if (phase === 'slow') {
        sc = 1 - (1 - SLOW_SCALE) * sm(clamp01(t / 0.3));
        show('ntcTag', t > 0.2);
        if (t >= SLOW) startMvp();
    } else if (phase === 'mvp') {
        show('ntcMvp', t > 0.25);
        if (t >= MVP_T) finish();
    }
}

/** Runs after the player has set the camera, right before rendering. */
export function applyCamera() {
    if (phase === 'off' || !c) return;
    const cam = c.camera, base = c.player().baseFov || 78;
    if (phase === 'intro') {
        if (t >= LINE) return;
        if (t < FLY) {
            const u = clamp01(t / FLY), e = 1 - (1 - u) * (1 - u);
            curve.getPoint(e, _p); cam.position.copy(_p); cam.updateMatrixWorld(true);
            cam.lookAt(_l.lerpVectors(look0, orbitC, e)); cam.fov = 62;
        } else {
            const k = (t - FLY) / (LINE - FLY), b = sm(clamp01((k - 0.4) / 0.6));
            _pp.copy(cam.position); _pq.copy(cam.quaternion);                 // the player's own view
            orbit(a0 + k * 0.9, 6 - 2.8 * sm(k), 2.4 - 1.9 * sm(k), _p);
            cam.position.copy(_p); cam.updateMatrixWorld(true); cam.lookAt(orbitC);
            cam.position.lerp(_pp, b); cam.quaternion.slerp(_pq, b);          // glide into first person
            cam.fov = 62 + (base - 62) * b;
        }
        cam.updateProjectionMatrix();
        return;
    }
    c.hud.hideDeath();
    if (phase === 'slow' && kill) {
        _l.copy(kill.victim.position); _l.y += kill.victimIsPlayer ? 1.5 : 1.2;
        if (!kill.byPlayer) {                       // cut to the killer's eyes and push in
            const u = clamp01(t / SLOW);
            _p.copy(kill.killerPos); _t.subVectors(_l, _p).setY(0).normalize(); _p.addScaledVector(_t, u * 0.6);
            cam.position.copy(_p); cam.updateMatrixWorld(true); cam.lookAt(_l);
            cam.fov = 48 - 8 * sm(u);
        } else {                                    // your own view, drifting onto the victim
            _pq.copy(cam.quaternion); cam.updateMatrixWorld(true); cam.lookAt(_l);
            cam.quaternion.slerp(_pq, 1 - 0.8 * sm(clamp01(t / 0.7)));
            cam.fov = base - 16 * sm(clamp01(t / 1.6));
        }
        cam.updateProjectionMatrix();
    } else if (phase === 'mvp' && mvp) {
        if (!mvp.you) {                             // slow orbit round the MVP
            const m = mvp.obj.position, a = 1.2 + t * 0.6;
            _l.set(m.x, m.y + 1.25, m.z);
            cam.position.set(_l.x + Math.cos(a) * 3.8, _l.y + 0.35, _l.z + Math.sin(a) * 3.8);
            cam.updateMatrixWorld(true); cam.lookAt(_l); cam.fov = 46;
        } else cam.fov = base - 8 * sm(clamp01(t / 1.5));
        cam.updateProjectionMatrix();
    }
}
