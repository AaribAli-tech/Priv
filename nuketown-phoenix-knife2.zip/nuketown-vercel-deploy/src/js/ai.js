// ============================================================================
// ai.js — bot soldiers
//
// Heading convention matches the player camera: forward = (-sin yaw, -cos yaw).
// The soldier mesh is authored facing -Z, so root.rotation.y = yaw puts the
// model, its weapon and its muzzle all pointing where the bot is actually
// going.  (The previous build set this from atan2(dx,dz), which pointed every
// soldier exactly backwards.)
// ============================================================================
import * as THREE from 'three';
import { rigFor } from './rebel.js';
// Bots draw from the four-weapon TDM pool, NOT the whole 15-gun Gun Game
// ladder — that ladder contains a 165-damage Barrett that would one-shot the
// player from across the map. Gun Game overrides this per bot via weaponPool.
import { WEAPON_DEFS, BOT_WEAPON_POOL } from './weapons.js';
import { WAYPOINTS, SPAWN_A, SPAWN_B, PERCHES } from './map.js';
import { TEAM_A, rand, randElement, dist2D, clamp, clampToMap } from './utils.js';
import { SOFT_COVER } from './physics.js';

const ST = { PATROL: 0, HUNT: 1, ENGAGE: 2, RELOAD: 3, FALLBACK: 4, HOLD: 5, DEAD: 6 };
const EYE = 1.52, EYE_CROUCH = 1.02;
const SHADOW_RANGE_SQ = 22 * 22;       // past this a soldier's own shadow does not read
const VIEW_RANGE = 46;
const FOV_DOT = Math.cos(1.15);        // ~132° total awareness cone

const _a = new THREE.Vector3(), _b = new THREE.Vector3(), _c = new THREE.Vector3();

/**
 * Where the nth soldier to land on one spawn point stands.
 *
 * Each point keeps its own counter and hands out six fixed places around it,
 * because the random ±1.2 m offset this replaced could — and did, in a nine-man
 * lobby spawning on a thirteen-point list — give two soldiers the same offset.
 * Standing inside a teammate is what "the bodies look clumped into them" meant:
 * the model was fine, the drop was crowded.
 */
export function nowSec() {
    return typeof performance !== 'undefined' && performance.now
        ? performance.now() / 1000 : Date.now() / 1000;
}

export const SPAWN_RING = 6;
export const SPAWN_RING_R = 1.6;
export function spawnOffset(index) {
    const a = (index / SPAWN_RING) * Math.PI * 2 + 0.4;
    return { dx: Math.cos(a) * SPAWN_RING_R, dz: Math.sin(a) * SPAWN_RING_R };
}

/**
 * Which spawn point to take when nobody was told: the one claimed by the fewest
 * soldiers in the last couple of seconds.
 *
 * The ledger is shared per team, on purpose. When it hung off the individual
 * soldier, every bot read an empty book and they all walked to the first line of
 * the table — four teammates standing in a ring around one spawn while the other
 * twelve points sat empty. That is the exact shape of "your bots look like the
 * bodies are clumped into them".
 */
const ledgers = new Map();
export function spawnLedger(team) {
    let m = ledgers.get(team);
    if (!m) ledgers.set(team, m = new Map());
    return m;
}

export function claimSpawnPoint(list, claim, nowSec = 0) {
    let best = list[0], bestN = Infinity;
    for (const s of list) {
        const held = claim.get(s);
        const n = held && held.until > nowSec ? held.n : 0;
        if (n < bestN) { bestN = n; best = s; }
    }
    const held = claim.get(best);
    if (held && held.until > nowSec) { held.n++; held.until = nowSec + 2.0; }
    else claim.set(best, { n: 1, until: nowSec + 2.0 });
    if (claim.size > 96) for (const [k, v] of claim) if (v.until <= nowSec) claim.delete(k);
    notePlacement(best, nowSec);
    return best;
}

/**
 * The last wave of placements, as the game saw them. A wave is the run of
 * soldiers put down within half a second of each other — which is what a match
 * start is, and what a cluster of respawns after a grenade is. Written down at
 * the moment of the decision, because by the time anyone looks the soldiers have
 * walked together and the measurement means nothing.
 */
let wave = null;
export function deploySpread() { return wave; }
/**
 * A new match means the table is dealt out again, so the previous hand is
 * forgotten. Left in place, two `startMatch()` calls in a row read as one crowd
 * of eighteen soldiers standing on nine points, and the harness blames a spawn
 * table that is actually fine.
 */
export function resetDeploySpread() { wave = null; }
function notePlacement(sp, nowSec) {
    if (!wave || nowSec - wave.t > 0.5) wave = { t: nowSec, pts: [{ x: sp.x, z: sp.z }], nearest: Infinity, widest: 0 };
    else wave.pts.push({ x: sp.x, z: sp.z });
    let nearest = Infinity, widest = 0;
    for (let i = 0; i < wave.pts.length; i++) {
        for (let j = i + 1; j < wave.pts.length; j++) {
            const d = Math.hypot(wave.pts[i].x - wave.pts[j].x, wave.pts[i].z - wave.pts[j].z);
            if (d < nearest) nearest = d;
            if (d > widest) widest = d;
        }
    }
    wave.count = wave.pts.length;
    wave.nearest = wave.pts.length > 1 ? +nearest.toFixed(2) : 0;
    wave.widest = +widest.toFixed(1);
}

/**
 * Mark a point as taken by somebody who chose it for themselves — the player, at
 * the start of a match and on every respawn. Without this, the soldier who picks
 * the table next has no idea a man is standing there already and materialises on
 * top of them. The claim fades after a few seconds, once that player has moved.
 */
export function claimPoint(sp, team, seconds = 3) {
    const claim = spawnLedger(team);
    claim.set(sp, { n: 99, until: nowSec() + seconds });
    notePlacement(sp, nowSec());
    return sp;
}

/**
 * True if a soldier standing at x/z would be inside something solid at torso
 * height, or would be stood up on a step, a verge or a porch. Bushes and glass
 * are not obstacles to being put down in: soft cover is meant to be stood in,
 * and a pane is not a wall. Same shapes the browser harness reads, so the two
 * never disagree about what "buried" means.
 */
const _footScratch = [];
function footingBlocked(cw, x, z) {
    if (!cw || !cw.boxes) return false;
    const r = 0.34;
    // Broadphase, not every box in the map: this runs once per candidate spot on
    // the spawn ring, and the ring is searched until one comes up clear.
    const ids = cw.queryBoxes ? cw.queryBoxes(x, z, r, _footScratch) : null;
    for (let i = 0; i < (ids ? ids.length : cw.boxes.length); i++) {
        const b = ids ? cw.boxes[ids[i]] : cw.boxes[i];
        if (b.tag === 'bound' || b.tag === 'ground' || b.tag === 'bush' || b.tag === 'glass') continue;
        if (x + r <= b.minX || x - r >= b.maxX || z + r <= b.minZ || z - r >= b.maxZ) continue;
        if (b.minY <= 0.2 && b.maxY >= 1.2) return true;
    }
    if (cw.groundHeight) {
        const g = cw.groundHeight(x, z, 2.2, 0.42, []);
        if (!Number.isFinite(g) || Math.abs(g) > 0.15) return true;
    }
    return false;
}

/**
 * The next place on the ring that is actually clear.
 *
 * Going round the ring in order fixed the soldiers standing inside each other,
 * and it briefly put one of them inside the stairs instead: a spawn point can sit
 * in a clear lane and still have a ring place that lands on a fence or a step.
 * So the order is kept, and each place is checked before it is used.
 */
export function pickRingSlot(sp, cw, start = takeRingSlot(sp)) {
    if (!cw || !cw.boxes) return start;
    for (let k = 0; k < SPAWN_RING; k++) {
        const i = (start + k) % SPAWN_RING;
        const o = spawnOffset(i);
        if (!footingBlocked(cw, sp.x + o.dx, sp.z + o.dz)) return i;
    }
    return start;
}

/** Round-robin over the ring, per point, for however long the map lives. */
const ringIndex = new Map();
export function takeRingSlot(sp) {
    const i = ringIndex.get(sp) | 0;
    ringIndex.set(sp, (i + 1) % SPAWN_RING);
    return i;
}

export class Bot {
    constructor(name, team, scene, skill = 0.5) {
        this.name = name;
        this.team = team;
        this.scene = scene;
        this.skill = skill;
        // Difficulty scales (see difficulty.js). Neutral by default so a bot built
        // without one fights exactly as it always did.
        this.aimScale = 1; this.spreadScale = 1; this.reactionScale = 1; this.chanceCap = 0.72;

        this.position = new THREE.Vector3();
        this.velocity = new THREE.Vector3();
        this.yaw = 0;
        this.targetYaw = 0;
        this.aimPitch = 0;

        this.health = 100; this.maxHealth = 100;
        this.alive = true;
        this.isCrouching = false;
        this.onGround = true;

        this.state = ST.PATROL;
        this.path = null;
        this.goal = null;
        this.goalTimer = 0;
        this.enemy = null;
        this.lastSeen = null;
        this.lastSeenTime = -99;
        this.reaction = 0;
        this.burst = 0;
        this.burstPause = 0;
        this.nextShot = 0;
        this.stuck = 0;
        this.stuckCount = 0;
        this.unstickTimer = 0;
        this.lastPos = new THREE.Vector3();
        this.respawnTimer = 0;
        this.spawnProtect = 0;
        this.suppressed = 0;
        this.blindT = 0;
        this.strafeDir = Math.random() < 0.5 ? 1 : -1;
        this.strafeTimer = 0;
        this.holdTimer = 0;

        this.kills = 0; this.deaths = 0; this.assists = 0; this.score = 0;
        this.killStreak = 0;
        this.damageFrom = {};

        this.weaponIndex = 0;
        this.setWeapon(randElement(this.weaponPool || BOT_WEAPON_POOL));
        this.ammo = this.weapon.magSize;

        // Skinned GLB soldier when the assets loaded, procedural rig otherwise.
        // Both expose the same interface, so nothing below this line cares
        // which one it got — and a missing asset costs looks, not a crash.
        // character.js's GLB soldiers, soldier.js's procedural rig, or the imported
        // FBX model from rebel.js — all the same surface, so nothing below this
        // line has to know which one it got.
        this.rig = rigFor(team, this.weapon.type);
        scene.add(this.rig.root);
        this.mesh = this.rig.root;

        this.events = [];
    }

    /** Which weapons a respawn may roll from. Gun Game pins this to its ladder. */
    setWeaponPool(list) {
        this.weaponPool = Array.isArray(list) && list.length ? list : null;
    }

    setWeapon(i) {
        this.weaponIndex = i;
        this.weapon = WEAPON_DEFS[i];
        this.ammo = this.weapon.magSize;
        if (this.rig) this.rig.setWeapon(this.weapon.type);
    }

    get eyeY() { return this.isCrouching ? EYE_CROUCH : EYE; }
    eyePos(out) { return out.set(this.position.x, this.position.y + this.eyeY, this.position.z); }

    // ── lifecycle ───────────────────────────────────────────────────────────
    spawn(pos) {
        // A mode may hand this soldier its own spawn list (Free For All spreads
        // everyone across both clusters so eight solos do not stack in one lane).
        const list = this.spawnPoints && this.spawnPoints.length
            ? this.spawnPoints : (this.team === TEAM_A ? SPAWN_A : SPAWN_B);
        const sp = pos || claimSpawnPoint(list, spawnLedger(this.team), nowSec());
        // Not a random shove: a fixed place on the point's own ring, so whoever
        // lands here second is 1.6 m to the side and not inside you. The place is
        // chosen clear of walls and steps when the collision world is known to us.
        this._ring = pickRingSlot(sp, this._cw, takeRingSlot(sp));
        const off = spawnOffset(this._ring);
        this.position.set(sp.x + off.dx, 0, sp.z + off.dz);
        clampToMap(this.position, 2.4);          // nobody is born in the fence strip
        this.velocity.set(0, 0, 0);
        this.health = this.maxHealth;
        this.alive = true;
        this.isCrouching = false;
        this.state = ST.PATROL;
        this.enemy = null;
        this.lastSeen = null;
        this.spawnProtect = 1.5;
        this.suppressed = 0;
        this.blindT = 0;
        this.damageFrom = {};
        this.setWeapon(randElement(this.weaponPool || BOT_WEAPON_POOL));
        this.rig.resetPose();
        this.rig.root.visible = true;
        this.rig.root.traverse(o => {
            if (o.isMesh && o.material && o.material.transparent && o.material.opacity < 1) o.material.opacity = 1;
        });
        this.yaw = this.team === TEAM_A ? -Math.PI / 2 : Math.PI / 2;
        this.pickGoal();
    }

    die(killerName) {
        if (!this.alive) return false;
        this.alive = false;
        this.state = ST.DEAD;
        this.deaths++;
        this.killStreak = 0;
        this.respawnTimer = 5.5;
        this.rig.startDeath();
        void killerName;
        return true;
    }

    takeDamage(amount, attackerId) {
        if (!this.alive || this.spawnProtect > 0) return false;
        this.health -= amount;
        this.suppressed = 1.4;
        this.damageFrom[attackerId] = (this.damageFrom[attackerId] || 0) + amount;
        if (this.health <= 0) { this.health = 0; return this.die(attackerId); }
        if (this.state === ST.PATROL || this.state === ST.HOLD) {
            this.state = ST.HUNT;
            this.reaction = rand(0.08, 0.22);
        }
        return false;
    }

    // ── navigation ──────────────────────────────────────────────────────────
    pickGoal() {
        // Supply drop (airdrop.js): a bot that has noticed the crate heads for it.
        if (this.dropGoal) { this.goal = this.dropGoal; this.goalTimer = 4; return; }
        // push toward the far half of the map, occasionally hold a perch.
        // `pushDir` lets a teamless mode send this soldier the other way instead.
        const forward = this.pushDir || (this.team === TEAM_A ? 1 : -1);
        if (Math.random() < 0.18) {
            const p = randElement(PERCHES.filter(q => Math.sign(q.x) === forward || Math.random() < 0.5));
            this.goal = { x: p.x, z: p.z, perch: true };
        } else {
            let best = null, bestScore = -1e9;
            for (let i = 0; i < 6; i++) {
                const w = randElement(WAYPOINTS);
                const towardEnemy = w.x * forward;
                const d = dist2D(this.position, w);
                const score = towardEnemy * 0.9 - Math.abs(d - 16) * 0.4 + Math.random() * 8;
                if (score > bestScore) { bestScore = score; best = w; }
            }
            this.goal = best;
        }
        this.goalTimer = rand(6, 12);
    }

    /**
     * Who this soldier will shoot at.
     *
     * Team play is a single comparison — `e.team === this.team` means friend.
     * Free For All cannot be expressed that way with two team ids, so the mode
     * sets `allHostile` and every live soldier becomes fair game, including the
     * rest of what used to be his own side. Bots killing each other is the point:
     * the leaderboard is per person, so an AI v AI kill scores the same as a kill
     * on you.
     */
    isHostile(e) {
        // `e === this` is not a rounding detail. In a teamless mode "everyone is
        // hostile" would otherwise include the self, the bot acquires its own
        // position as its target, and the distance is 0 — so the engage maths
        // divides by zero, velocity goes NaN, position goes NaN, and the soldier
        // silently disappears: unrenderable, unhittable, and unable to kill or be
        // killed. One poisoned bot stalled the whole Free For All.
        if (!e || !e.alive || e === this) return false;
        return this.allHostile || e.team !== this.team;
    }

    /**
     * Steer toward a point, sliding around obstacles.
     *
     * `faceTarget` decouples where the soldier WALKS from where he LOOKS. In
     * combat a soldier backing off or repositioning keeps his weapon on you and
     * moves with his body turned — without this the bot turns to face wherever
     * it is walking, which meant a bot backing away from you was firing over
     * its shoulder while facing 180 degrees in the wrong direction.
     */
    steerTo(target, speed, dt, cw, faceTarget) {
        // While reversing out of a snag, ignore steering entirely — otherwise
        // the pathing immediately turns the bot back into whatever it was stuck
        // on and it never gets clear.
        if (this.unstickTimer > 0) return 99;

        const dx = target.x - this.position.x, dz = target.z - this.position.z;
        const d = Math.hypot(dx, dz);
        if (d < 0.001) return 0;
        let dirX = dx / d, dirZ = dz / d;

        // whisker probes: if blocked ahead, veer
        _a.set(this.position.x, this.position.y + 0.9, this.position.z);
        _b.set(dirX, 0, dirZ);
        const ahead = cw.raycast(_a, _b, 2.2);
        if (ahead) {
            const perpX = -dirZ, perpZ = dirX;
            _b.set(perpX, 0, perpZ);
            const right = cw.raycast(_a, _b, 1.8);
            const sign = right ? -1 : 1;
            dirX = dirX * 0.35 + perpX * sign * 0.95;
            dirZ = dirZ * 0.35 + perpZ * sign * 0.95;
            const n = Math.hypot(dirX, dirZ) || 1;
            dirX /= n; dirZ /= n;
        }

        this.velocity.x += (dirX * speed - this.velocity.x) * Math.min(1, dt * 9);
        this.velocity.z += (dirZ * speed - this.velocity.z) * Math.min(1, dt * 9);
        if (faceTarget) {
            const fx = faceTarget.x - this.position.x, fz = faceTarget.z - this.position.z;
            if (fx || fz) this.targetYaw = Math.atan2(-fx, -fz);
        } else {
            this.targetYaw = Math.atan2(-dirX, -dirZ);
        }
        return d;
    }

    // ── perception ──────────────────────────────────────────────────────────
    findEnemy(entities, cw) {
        let best = null, bestScore = -1e9;
        this.eyePos(_a);
        const fwdX = -Math.sin(this.yaw), fwdZ = -Math.cos(this.yaw);
        for (const e of entities) {
            if (!this.isHostile(e) || e === this) continue;
            const dx = e.position.x - this.position.x, dz = e.position.z - this.position.z;
            const d = Math.hypot(dx, dz);
            if (d > VIEW_RANGE || d < 0.25) continue;   // stacked on / inside you is not a target
            if (!Number.isFinite(d)) continue;
            const dot = (dx * fwdX + dz * fwdZ) / (d || 1);
            const alerted = this.suppressed > 0 || (this.enemy === e && this.lastSeenTime > -1);
            if (dot < FOV_DOT && !alerted && d > 5) continue;
            _b.set(e.position.x, e.position.y + (e.isCrouching ? 0.95 : 1.35), e.position.z);
            if (!cw.isLineOfSight(_a, _b)) continue;
            const score = 60 - d + (this.enemy === e ? 14 : 0) + dot * 12;
            if (score > bestScore) { bestScore = score; best = e; }
        }
        return best;
    }

    // ── update ──────────────────────────────────────────────────────────────
    /**
     * True once physics has gone non-finite. A NaN position never repairs itself —
     * every later frame only adds to it — so the soldier is invisible, unhittable
     * and unable to shoot for the rest of the match, which is what a lone divide by
     * zero used to cost.
     */
    needsHeal() {
        return !Number.isFinite(this.position.x) || !Number.isFinite(this.position.z)
            || !Number.isFinite(this.velocity.x) || !Number.isFinite(this.velocity.z);
    }

    /** Put a poisoned soldier back on the map. A hiccup, not a broken mode. */
    selfHeal() {
        const sp = randElement(this.spawnPoints && this.spawnPoints.length
            ? this.spawnPoints : (this.team === TEAM_A ? SPAWN_A : SPAWN_B));
        const off = spawnOffset(pickRingSlot(sp, this._cw, takeRingSlot(sp)));
        this.position.set(sp.x + off.dx, 0, sp.z + off.dz);
        this.velocity.set(0, 0, 0);
        this.goal = null;
        this.enemy = null;
        this.pickGoal();
    }

    update(dt, now, entities, cw, viewer) {
        this.events.length = 0;
        // Kept so the first call after a death can pick a spawn that is not inside
        // a wall: spawn() happens before this bot is ticked again.
        if (cw) this._cw = cw;

        if (this.needsHeal()) this.selfHeal();

        if (!this.alive) {
            this.rig.update(dt, {});
            this.respawnTimer -= dt;
            if (this.respawnTimer <= 4.2) this.rig.root.visible = this.rig.deadT < 5.0;
            // Round-based modes own the respawn cycle and revive everyone
            // themselves when the round flips, so a bot must not come back on
            // its own timer or a one-life round would never end.
            if (this.respawnTimer <= 0 && !this.respawnBlocked) this.spawn();
            return this.events;
        }
        if (this.frozen) {
            // frozen setup at the head of a round: hold position, no shooting
            this.velocity.set(0, 0, 0);
            this.rig.root.position.copy(this.position);
            this.rig.root.rotation.y = this.yaw;
            this.rig.update(dt, { speed: 0, aiming: false, crouching: false, aimPitch: 0, lookYaw: 0 });
            return this.events;
        }

        if (this.spawnProtect > 0) this.spawnProtect -= dt;
        this.suppressed = Math.max(0, this.suppressed - dt);
        // flashbanged: cannot see, cannot shoot until it wears off
        if (this.blindT > 0) { this.blindT -= dt; this.suppressed = Math.max(this.suppressed, 0.6); }
        this.goalTimer -= dt;
        this.strafeTimer -= dt;

        const seen = this.blindT > 0 ? null : this.findEnemy(entities, cw);
        if (seen) {
            this.enemy = seen;
            this.lastSeen = _c.copy(seen.position).clone();
            this.lastSeenTime = now;
            if (this.state === ST.PATROL || this.state === ST.HOLD || this.state === ST.HUNT) {
                if (this.state !== ST.ENGAGE) this.reaction = rand(0.14, 0.42) * (1.4 - this.skill) * this.reactionScale;
                this.state = ST.ENGAGE;
            }
        } else if (this.state === ST.ENGAGE && now - this.lastSeenTime > 1400) {
            this.state = this.lastSeen ? ST.HUNT : ST.PATROL;
        }

        if (this.ammo <= 0 && this.state !== ST.RELOAD) {
            this.state = ST.RELOAD;
            this.reloadTimer = this.weapon.reloadTime * (this.weapon.shellReload ? 4 : 1);
        }
        if (this.health < 26 && this.state === ST.ENGAGE && Math.random() < dt * 1.6) {
            this.state = ST.FALLBACK;
            this.holdTimer = rand(2.5, 4.0);
        }

        let speed = 0;
        const RUN = 5.6 + this.skill * 0.8, WALK = 3.4, CREEP = 1.9;

        switch (this.state) {
            case ST.PATROL: {
                if (!this.goal || this.goalTimer <= 0) this.pickGoal();
                const d = this.steerTo(this.goal, WALK + 1.0, dt, cw);
                speed = WALK + 1.0;
                if (d < 2.0) {
                    if (this.goal.perch && Math.random() < 0.6) { this.state = ST.HOLD; this.holdTimer = rand(3, 7); }
                    else this.pickGoal();
                }
                this.isCrouching = false;
                break;
            }
            case ST.HOLD: {
                this.holdTimer -= dt;
                this.velocity.multiplyScalar(Math.pow(0.02, dt));
                speed = 0;
                this.isCrouching = Math.random() < 0.5 ? this.isCrouching : this.isCrouching;
                // sweep the muzzle across the likely approach
                this.targetYaw = (this.team === TEAM_A ? -Math.PI / 2 : Math.PI / 2) + Math.sin(now * 0.0007 + this.name.length) * 0.7;
                if (this.holdTimer <= 0) { this.state = ST.PATROL; this.pickGoal(); }
                break;
            }
            case ST.HUNT: {
                const tgt = this.lastSeen || this.goal;
                if (!tgt) { this.state = ST.PATROL; break; }
                const d = this.steerTo(tgt, RUN, dt, cw);
                speed = RUN;
                this.isCrouching = false;
                if (d < 2.2) { this.lastSeen = null; this.state = ST.PATROL; this.pickGoal(); }
                break;
            }
            case ST.ENGAGE: {
                const e = this.enemy;
                if (!e || !e.alive) { this.state = ST.PATROL; break; }
                const dx = e.position.x - this.position.x, dz = e.position.z - this.position.z;
                const d = Math.hypot(dx, dz);
                this.targetYaw = Math.atan2(-dx, -dz);

                const idealRange = this.weapon.type === 'shotgun' ? 5 :
                                   this.weapon.type === 'sniper' ? 24 : 12;
                if (this.strafeTimer <= 0) { this.strafeDir *= -1; this.strafeTimer = rand(0.9, 2.2); }

                // Every movement branch below keeps the body — and therefore the
                // weapon — pointed at the target. A soldier repositions with his
                // muzzle on you, he does not turn his back and fire blind.
                if (d > idealRange + 5) {
                    this.steerTo(e.position, RUN, dt, cw, e.position);
                    speed = RUN;
                    this.isCrouching = false;
                } else if (d < idealRange - 4 && this.weapon.type !== 'shotgun') {
                    _a.set(this.position.x - dx / d * 3, 0, this.position.z - dz / d * 3);
                    this.steerTo(_a, WALK, dt, cw, e.position);
                    speed = WALK;
                } else {
                    // strafe across the target
                    const px = -dz / (d || 1) * this.strafeDir, pz = dx / (d || 1) * this.strafeDir;
                    this.velocity.x += (px * CREEP * 1.4 - this.velocity.x) * Math.min(1, dt * 7);
                    this.velocity.z += (pz * CREEP * 1.4 - this.velocity.z) * Math.min(1, dt * 7);
                    speed = CREEP * 1.4;
                    this.isCrouching = d < 14 && (this.weapon.type === 'sniper' || this.suppressed > 0.4);
                }

                // aim pitch toward the target's chest
                const ey = e.position.y + (e.isCrouching ? 0.95 : 1.35);
                this.aimPitch = Math.atan2(ey - (this.position.y + this.eyeY), Math.max(0.4, d));

                if (this.reaction > 0) { this.reaction -= dt; break; }
                this._tryFire(dt, now, e, d, cw);
                break;
            }
            case ST.RELOAD: {
                this.reloadTimer -= dt;
                this.velocity.multiplyScalar(Math.pow(0.35, dt));
                speed = 0.4;
                if (this.enemy && this.enemy.alive) {
                    // back off while reloading
                    const dx = this.position.x - this.enemy.position.x, dz = this.position.z - this.enemy.position.z;
                    const n = Math.hypot(dx, dz) || 1;
                    _a.set(this.position.x + dx / n * 4, 0, this.position.z + dz / n * 4);
                    this.steerTo(_a, WALK, dt, cw, this.enemy.position);
                    speed = WALK;
                }
                if (this.reloadTimer <= 0) {
                    this.ammo = this.weapon.magSize;
                    this.state = this.enemy && this.enemy.alive ? ST.ENGAGE : ST.PATROL;
                }
                break;
            }
            case ST.FALLBACK: {
                this.holdTimer -= dt;
                const src = this.enemy ? this.enemy.position : { x: 0, z: 0 };
                const dx = this.position.x - src.x, dz = this.position.z - src.z;
                const n = Math.hypot(dx, dz) || 1;
                _a.set(this.position.x + dx / n * 8, 0, this.position.z + dz / n * 8);
                this.steerTo(_a, RUN, dt, cw);
                speed = RUN;
                this.isCrouching = false;
                if (this.holdTimer <= 0) {
                    this.health = Math.max(this.health, 55);
                    this.state = ST.PATROL;
                    this.pickGoal();
                }
                break;
            }
        }

        // ── integrate + collide ────────────────────────────────────────────
        this.position.x += this.velocity.x * dt;
        this.position.z += this.velocity.z * dt;
        cw.resolveAxis(this.position, 0.34, 1.75, 'x');
        cw.resolveAxis(this.position, 0.34, 1.75, 'z');
        // The fence line is the last word. The chain-link and its invisible wall
        // usually do the job, but a bot shoved by a squadmate or walked off a roof
        // can end up in the two-metre strip outside the last cover line — and to
        // anyone playing, an enemy standing against the perimeter is an enemy who
        // spawned outside the map. So the perimeter is a number, not a suggestion.
        if (clampToMap(this.position, 2.0)) { this.velocity.x *= 0.2; this.velocity.z *= 0.2; }

        this.velocity.y -= 22 * dt;
        this.position.y += this.velocity.y * dt;
        const gy = cw.groundHeight(this.position.x, this.position.z, this.position.y, 0.34);
        if (this.position.y <= gy) { this.position.y = gy; this.velocity.y = 0; this.onGround = true; }
        else this.onGround = false;

        // ── unstick ────────────────────────────────────────────────────────
        // A soldier wedged on a doorframe used to jitter against it with a
        // random nudge, which mostly kept him wedged. Now he turns around,
        // walks out the way he came, and only then picks a new destination —
        // and if that still does not free him, he takes a bigger step back.
        const moved = dist2D(this.position, this.lastPos);
        if (moved < 0.02 && speed > 1) {
            this.stuck += dt;
            if (this.stuck > 0.7) {
                this.stuck = 0;
                this.stuckCount = (this.stuckCount || 0) + 1;

                // face back the way we came and commit to reversing for a beat
                this.targetYaw = this.yaw + Math.PI + rand(-0.5, 0.5);
                this.yaw = this.targetYaw;                     // snap, do not ease
                const backX = -Math.sin(this.yaw), backZ = -Math.cos(this.yaw);
                const shove = 3.5 + this.stuckCount * 1.5;
                this.velocity.set(backX * shove, 0, backZ * shove);
                this.unstickTimer = 0.55;

                // repeatedly stuck means this goal is unreachable from here
                this.goal = null;
                this.pickGoal();
                if (this.stuckCount >= 3) {
                    // last resort: teleport clear of whatever is holding us
                    this.position.x += backX * 1.2;
                    this.position.z += backZ * 1.2;
                    this.stuckCount = 0;
                }
            }
        } else {
            this.stuck = 0;
            if (moved > 0.15) this.stuckCount = 0;
        }
        // while reversing, ignore steering so the bot actually clears the snag
        if (this.unstickTimer > 0) this.unstickTimer -= dt;
        this.lastPos.copy(this.position);

        // ── orientation + rig ──────────────────────────────────────────────
        let dyaw = this.targetYaw - this.yaw;
        while (dyaw > Math.PI) dyaw -= Math.PI * 2;
        while (dyaw < -Math.PI) dyaw += Math.PI * 2;
        const turnRate = this.state === ST.ENGAGE ? 9.5 : 5.5;
        this.yaw += dyaw * Math.min(1, dt * turnRate);

        this.rig.root.position.copy(this.position);
        this.rig.root.rotation.y = this.yaw;
        if (this.rig.setShadows && viewer) {
            const dx = this.position.x - viewer.x, dz = this.position.z - viewer.z;
            this.rig.setShadows(dx * dx + dz * dz < SHADOW_RANGE_SQ);
        }
        this.rig.update(dt, {
            speed: Math.hypot(this.velocity.x, this.velocity.z),
            aiming: this.state === ST.ENGAGE && this.reaction <= 0,
            crouching: this.isCrouching,
            aimPitch: this.aimPitch,
            lookYaw: clamp(dyaw, -0.6, 0.6)
        });

        return this.events;
    }

    _tryFire(dt, now, enemy, dist, cw) {
        const w = this.weapon;
        if (this.blindT > 0) return;
        if (this.burstPause > 0) { this.burstPause -= dt; return; }
        const interval = 60000 / w.rpm;
        if (now - this.nextShot < interval) return;
        this.nextShot = now;

        // line of fire must actually be clear from the muzzle
        this.eyePos(_a);
        _b.set(enemy.position.x, enemy.position.y + (enemy.isCrouching ? 0.95 : 1.3), enemy.position.z);
        if (!cw.isLineOfSight(_a, _b)) return;

        this.ammo--;
        this.rig.fireFlash();
        this.burst++;

        // burst discipline
        const burstLen = w.type === 'sniper' ? 1 : w.type === 'shotgun' ? 1 : (3 + ((Math.random() * 4) | 0));
        if (this.burst >= burstLen) {
            this.burst = 0;
            this.burstPause = w.type === 'sniper' ? rand(0.9, 1.8) :
                              w.type === 'shotgun' ? rand(0.6, 1.1) : rand(0.22, 0.55);
        }

        // hit chance: skill, range, target motion, own motion, suppression
        const rangeFactor = clamp(1 - (dist - w.falloffStart * 0.5) / w.range, 0.18, 1);
        const moving = Math.hypot(this.velocity.x, this.velocity.z) > 2 ? 0.72 : 1;
        const crouchBonus = this.isCrouching ? 1.15 : 1;
        let chance = (0.16 + this.skill * 0.42) * rangeFactor * moving * crouchBonus * this.aimScale;
        if (this.suppressed > 0) chance *= 0.8;
        // The cap belongs to the difficulty: on Easy a bot has off days it cannot
        // recover from, on Hard it does not.
        chance = clamp(chance, 0.03, this.chanceCap);

        const hit = Math.random() < chance;
        const muzzle = new THREE.Vector3();
        this.rig.muzzle.updateWorldMatrix(true, false);
        muzzle.setFromMatrixPosition(this.rig.muzzle.matrixWorld);

        if (hit) {
            const head = Math.random() < 0.08;
            let dmg = w.damage * (w.pellets ? w.pellets * 0.34 : 1) * rand(0.85, 1.05);
            if (dist > w.falloffStart) dmg *= Math.max(w.falloffMin, 1 - (dist - w.falloffStart) / w.range);
            if (head) dmg *= w.headMult;
            this.events.push({ type: 'hit', target: enemy, damage: dmg, from: muzzle, to: _b.clone(), head, shooter: this });
        } else {
            // spray a near miss so the player hears/sees rounds going past
            const miss = _b.clone();
            // Scaled by the difficulty too, so a miss on Easy is visibly wild —
            // dirt kicking up beside you — instead of a near miss you cannot tell
            // apart from a hit you survived.
            const sp = this.spreadScale;
            miss.x += rand(-1.6, 1.6) * sp; miss.y += rand(-0.7, 1.1) * sp; miss.z += rand(-1.6, 1.6) * sp;
            const dir = miss.clone().sub(muzzle).normalize();
            const h = cw.raycast(muzzle, dir, w.range, SOFT_COVER);
            this.events.push({
                type: 'miss', from: muzzle, to: h ? h.point : muzzle.clone().addScaledVector(dir, w.range),
                normal: h ? h.normal : null, shooter: this, near: enemy
            });
        }
        // A muzzle sampled before the rig has written its world matrices can come
        // back non-finite (it is read straight out of matrixWorld). Rebuild it from
        // the eye — the point the shot was traced from — rather than hand the frame
        // a NaN that takes the audio path down with it.
        if (!Number.isFinite(muzzle.x) || !Number.isFinite(muzzle.y) || !Number.isFinite(muzzle.z)) {
            this.eyePos(muzzle);
        }
        this.events.push({ type: 'shot', audio: w.audioType, position: muzzle.clone() });
    }

    dispose() {
        this.scene.remove(this.rig.root);
        this.rig.dispose();
    }
}
