// ============================================================================
// airdrop.js — random supply drops. Plane -> crate + parachute -> smoke marker
// -> impact -> bots/player race to it -> hold to open -> reward -> crate gone.
// Self-contained: main.js only constructs it, calls update(dt, live), reset().
// Bots only learn of the crate by distance (per-bot awareness radius).
// ============================================================================
import * as THREE from 'three';
import { WAYPOINTS } from './map.js';
import { MAP_RECT, clamp, rand, randElement } from './utils.js';
import { playJetPass, playLand, playKillConfirm } from './audio.js';
import * as shop from './shop.js';

const FIRST = [30, 30], EVERY = [30, 30];      // a wave every 30s
const DROPS = 3;                               // crates per wave
const PLANE_Y = 62, PLANE_V = 55, FALL_V = 7.5;
const OPEN_P = 2.0, OPEN_B = 2.8, REACH = 2.8; // hold seconds, interact radius
const SEE_R = 55;                              // bots may notice within this
const MAX_CHASERS = 5;
const BUFF_T = 20;

const mat = (c, o = {}) => new THREE.MeshBasicMaterial({ color: c, ...o });
const SHADE = (c, k) => new THREE.Color(c).multiplyScalar(k).getHex();

function plane() {
    const g = new THREE.Group(), m = mat(0x4a5238), d = mat(0x2a2f22);
    const f = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.0, 16, 8), m);
    f.rotation.z = Math.PI / 2; g.add(f);
    const w = new THREE.Mesh(new THREE.BoxGeometry(3, 0.3, 24), m); g.add(w);
    const t = new THREE.Mesh(new THREE.BoxGeometry(2, 0.25, 8), d); t.position.x = -7; g.add(t);
    const fin = new THREE.Mesh(new THREE.BoxGeometry(2.4, 3, 0.25), d); fin.position.set(-7, 1.6, 0); g.add(fin);
    for (const z of [-6, 6]) {
        const e = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 2, 8), d);
        e.rotation.z = Math.PI / 2; e.position.set(1, -0.5, z); g.add(e);
    }
    return g;
}
function crate() {
    const g = new THREE.Group();
    const body = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1, 1.4), mat(0x6b7a3a));
    const band = new THREE.Mesh(new THREE.BoxGeometry(1.44, 0.18, 1.44), mat(0xf0c030));
    band.position.y = 0.2;
    const lid = new THREE.Group(); lid.position.set(-0.7, 0.5, 0);
    const lm = new THREE.Mesh(new THREE.BoxGeometry(1.44, 0.1, 1.44), mat(SHADE(0x6b7a3a, 0.8)));
    lm.position.x = 0.7; lid.add(lm);
    g.add(body, band, lid); g.userData.lid = lid;
    return g;
}
function chute() {
    const g = new THREE.Group();
    const cap = new THREE.Mesh(new THREE.SphereGeometry(2.6, 14, 7, 0, Math.PI * 2, 0, Math.PI / 2),
        mat(0xe8e2cf, { side: THREE.DoubleSide }));
    cap.position.y = 3.6; g.add(cap);
    const L = mat(0xcccccc);
    for (let i = 0; i < 4; i++) {
        const a = i * Math.PI / 2 + 0.78;
        const l = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 3.9, 3), L);
        l.position.set(Math.cos(a) * 1.3, 1.8, Math.sin(a) * 1.3);
        l.rotation.set(Math.sin(a) * 0.5, 0, -Math.cos(a) * 0.5); g.add(l);
    }
    return g;
}
function beam(color) {
    const g = new THREE.Group();
    const b = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 1.3, 45, 10, 1, true),
        mat(color, { transparent: true, opacity: 0.32, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide }));
    b.position.y = 22.5; g.add(b);
    const r = new THREE.Mesh(new THREE.RingGeometry(2.2, 2.7, 24),
        mat(color, { transparent: true, opacity: 0.6, side: THREE.DoubleSide, depthWrite: false }));
    r.rotation.x = -Math.PI / 2; r.position.y = 0.05; g.add(r);
    return g;
}

export class Airdrop {
    constructor(ctx) {
        this.ctx = ctx;           // {scene, effects, hud, player, getBots, grenades, streaks, shake}
        this.fx = [];             // detaching chutes, etc.
        this.drops = []; this.d = null;   // active drops; this.d = the one being processed
        this.buffs = {};          // id -> seconds left
        this.hold = false; this.prog = {};
        this._ui(); this._input();
        this.reset();
    }

    reset() {
        this._endBuffs(true);
        for (const o of this.fx) this.ctx.scene.remove(o.obj);
        this.fx.length = 0;
        for (const d of this.drops) { this.d = d; this._clearBots(); for (const k of ['plane', 'crate', 'chute', 'beam']) if (d[k]) this.ctx.scene.remove(d[k]); }
        this.drops = []; this.d = null;
        this.next = rand(...FIRST);
        this.el.style.display = 'none';
    }

    // ── input / ui ──────────────────────────────────────────────────────────
    _input() {
        addEventListener('keydown', e => { if (e.code === 'KeyE' && !e.repeat) this.hold = true; });
        addEventListener('keyup', e => { if (e.code === 'KeyE') this.hold = false; });
        addEventListener('blur', () => { this.hold = false; });
    }
    _ui() {
        const el = document.createElement('div');
        el.style.cssText = 'position:fixed;left:50%;bottom:22%;transform:translateX(-50%);display:none;z-index:30;' +
            'font:600 15px Rajdhani,sans-serif;letter-spacing:2px;color:#fff;text-align:center;text-shadow:0 1px 4px #000;' +
            'touch-action:none;user-select:none;cursor:pointer';
        el.innerHTML = '<div class="t"></div><div style="width:190px;height:6px;margin:6px auto 0;background:#0008;border:1px solid #fff6">' +
            '<i style="display:block;height:100%;width:0;background:#f0c030"></i></div>';
        document.body.appendChild(el);
        el.addEventListener('pointerdown', () => { this.hold = true; });
        for (const t of ['pointerup', 'pointerleave', 'pointercancel']) el.addEventListener(t, () => { this.hold = false; });
        const bf = document.createElement('div');
        bf.style.cssText = 'position:fixed;left:14px;top:46%;z-index:30;font:600 14px Rajdhani,sans-serif;color:#ffd24a;text-shadow:0 1px 3px #000;pointer-events:none;white-space:pre';
        document.body.appendChild(bf);
        this.el = el; this.bar = el.querySelector('i'); this.txt = el.querySelector('.t'); this.bf = bf;
    }
    _show(on) { if (on) this._any = true; }

    // ── main tick ───────────────────────────────────────────────────────────
    update(dt, live) {
        this._buffs(dt);
        for (let i = this.fx.length - 1; i >= 0; i--) {         // detached parachutes
            const f = this.fx[i]; f.t += dt;
            f.obj.position.y += (f.t < 0.5 ? 2.5 : -0.6) * dt; f.obj.position.x += 1.8 * dt;
            f.obj.scale.multiplyScalar(1 - dt * 0.9);
            if (f.t > 1.8) { this.ctx.scene.remove(f.obj); this.fx.splice(i, 1); }
        }
        if (!live) return;
        if ((this.next -= dt) <= 0) { if (this.drops.length) this.next = 5; else this._start(); }
        this._any = false;
        for (const d of this.drops.slice()) { this.d = d; this._tick(dt, d); }
        this.d = null;
        this.el.style.display = this._any ? 'block' : 'none';
    }
    _tick(dt, d) {
        if (d.plane) this._plane(dt);
        if (d.crate && !d.landed) this._fall(dt);
        if (d.beam) d.beam.children[0].material.opacity = 0.26 + Math.sin(performance.now() / 260) * 0.08;
        if (d.landed) { this._bots(dt); this._player(dt); }
        if (d.done) {                                           // lid open, shrink away
            d.doneT += dt; d.crate.userData.lid.rotation.z = Math.min(1.9, d.doneT * 5);
            if (d.doneT > 2.5) d.crate.scale.setScalar(Math.max(0.01, 1 - (d.doneT - 2.5) * 2));
            if (d.doneT > 3.3) this._remove();
        }
    }

    _start() {
        this.next = rand(...EVERY);
        const used = [];
        for (let i = 0; i < DROPS; i++) {
            let w, x, z, tries = 0;
            do {
                w = randElement(WAYPOINTS);
                x = clamp(w.x, MAP_RECT.minX + 6, MAP_RECT.maxX - 6); z = clamp(w.z, MAP_RECT.minZ + 6, MAP_RECT.maxZ - 6);
            } while (used.some(u => Math.hypot(u.x - x, u.z - z) < 30) && ++tries < 30);
            used.push({ x, z });
            this._spawn(x, z, i);
        }
        this.ctx.hud.banner('SUPPLY DROPS INBOUND', '#f0c030', '3 crates incoming');
        playJetPass();
    }
    _spawn(x, z, i) {
        const dir = Math.random() < 0.5 ? 1 : -1;
        const p = plane(); p.rotation.y = dir > 0 ? 0 : Math.PI;
        p.position.set(MAP_RECT.minX - 100 + (dir > 0 ? 0 : MAP_RECT.maxX - MAP_RECT.minX + 200), PLANE_Y, z);
        this.ctx.scene.add(p);
        p.position.x -= dir * i * 25;                      // stagger the planes
        this.drops.push({ x, z, dir, plane: p, dropped: false, landed: false, done: false, doneT: 0, bots: new Map(), prog: {}, scan: 0 });
    }
    _plane(dt) {
        const d = this.d, p = d.plane;
        p.position.x += d.dir * PLANE_V * dt;
        if (!d.dropped && (p.position.x - d.x) * d.dir >= 0) {
            d.dropped = true;
            const c = crate(), ch = chute();
            c.position.set(d.x, PLANE_Y - 3, d.z); ch.position.copy(c.position);
            d.crate = c; d.chute = ch;
            d.beam = beam(0xffc830); d.beam.position.set(d.x, 0, d.z);   // marker shows from the moment it drops
            this.ctx.scene.add(c, ch, d.beam);
        }
        if (Math.abs(p.position.x - d.x) > MAP_RECT.maxX - MAP_RECT.minX + 130) { this.ctx.scene.remove(p); d.plane = null; }
    }
    _fall(dt) {
        const d = this.d, c = d.crate;
        c.position.y -= FALL_V * dt;
        c.rotation.y += dt * 0.25; c.rotation.z = Math.sin(performance.now() / 600) * 0.08;
        d.chute.position.set(c.position.x, c.position.y, c.position.z);
        if (c.position.y <= 0.5) {
            c.position.y = 0.5; c.rotation.z = 0; d.landed = true;
            const pos = new THREE.Vector3(d.x, 0.4, d.z);
            this.ctx.effects.explosion(pos, 0.55, 0xd8c9a0);       // dust burst
            playLand();
            const pl = this.ctx.player, dist = Math.hypot(pl.position.x - d.x, pl.position.z - d.z);
            if (this.ctx.shake) this.ctx.shake(clamp(1 - dist / 70, 0, 1) * 0.9);
            this.fx.push({ obj: d.chute, t: 0 });                   // chute lets go
            d.chute = null;
            for (const b of this.ctx.getBots()) b.dropR = rand(SEE_R * 0.5, SEE_R);   // each bot's own sight range
        }
    }

    // ── bots: notice by distance, decide, race, open ────────────────────────
    _bots(dt) {
        const d = this.d;
        if (d.done) return;
        d.scan -= dt;
        const scanNow = d.scan <= 0; if (scanNow) d.scan = 0.6;
        let chasers = 0; for (const b of d.bots.keys()) if (b.alive && b.dropGoal) chasers++;
        for (const b of this.ctx.getBots()) {
            if (!b.alive) { b.dropGoal = null; d.prog[b.name] = 0; continue; }
            const dist = Math.hypot(b.position.x - d.x, b.position.z - d.z);
            if (scanNow && !d.bots.has(b) && !b.dropGoal && dist < (b.dropR || SEE_R) && chasers < MAX_CHASERS && Math.random() < 0.35) {
                const go = Math.random() < 0.7;                       // some bots just ignore it
                d.bots.set(b, go);
                if (go) { b.dropGoal = { x: d.x, z: d.z }; b.goalTimer = 0; b.holdTimer = 0; chasers++; }
            }
            if (!b.dropGoal) continue;
            if (dist < REACH && b.state !== 2) {                      // 2 = ENGAGE: busy shooting, no looting
                d.prog[b.name] = (d.prog[b.name] || 0) + dt;
                if (d.prog[b.name] >= OPEN_B) return this._open(b);
            } else d.prog[b.name] = Math.max(0, (d.prog[b.name] || 0) - dt);
        }
    }

    // ── player ──────────────────────────────────────────────────────────────
    _player(dt) {
        const d = this.d, p = this.ctx.player;
        if (d.done || !p.alive) { this._show(false); return; }
        const dist = Math.hypot(p.position.x - d.x, p.position.z - d.z);
        if (dist > 90) { this._show(false); return; }
        this._show(true);
        const near = dist < REACH;
        if (near && this.hold && p.health >= (this._hp ?? p.health)) d.prog.P = (d.prog.P || 0) + dt;
        else d.prog.P = 0;
        this._hp = p.health;
        this.txt.textContent = near ? (IS_HOLD_HINT) : `SUPPLY DROP  ${Math.round(dist)}m`;
        this.bar.style.width = (near ? clamp((d.prog.P || 0) / OPEN_P, 0, 1) * 100 : 0) + '%';
        if (near && d.prog.P >= OPEN_P) this._open(null);
    }

    _open(bot) {
        const d = this.d; if (d.done) return;
        d.done = true; this._clearBots(); this._show(false);
        const r = Math.random(), tier = r < 0.06 ? 3 : r < 0.30 ? 2 : 1;
        bot ? this._botReward(bot, tier) : this._reward(tier);
    }
    _clearBots() { if (this.d) for (const b of this.d.bots.keys()) b.dropGoal = null; }
    _remove() {
        const d = this.d;
        for (const k of ['plane', 'crate', 'chute', 'beam']) if (d[k]) this.ctx.scene.remove(d[k]);
        this.drops.splice(this.drops.indexOf(d), 1); this.d = null;
    }

    _botReward(b, tier) {
        b.health = Math.max(b.health, 100) + (tier > 1 ? 40 * tier : 0); b.suppressed = 0;
        this.ctx.hud.banner(`${b.name} TOOK THE DROP`, '#ff6b4a', ['', 'supplies', 'rare loot', 'jackpot'][tier]);
    }

    // ── rewards ─────────────────────────────────────────────────────────────
    _reward(tier) {
        const P = this.ctx.player, hud = this.ctx.hud, pick = a => randElement(a);
        playKillConfirm();
        const gunLocked = P.noSwap;
        const table = {
            1: ['COMMON', '#9fd0ff', [
                ['+40 COINS', () => shop.addCoins(40)],
                ['AMMO RESUPPLY', () => P.weapons.forEach((w, i) => { w.ammo = P.defs[i].magSize; w.reserve = P.defs[i].reserve; })],
                ['HEALTH RESTORED', () => { P.health = P.maxHealth; }]]],
            2: ['RARE', '#b57bff', [
                ['TEMPORARY ARMOR', () => { P.armor = Math.max(P.armor, 75); }],
                ['SPEED BOOST', () => this._buff('speed')],
                ['EXTRA GRENADE', () => { const g = this.ctx.grenades; if (g) g.counts.frag++; }],
                ['DAMAGE BOOST', () => this._buff('damage')]]],
            3: ['VERY RARE', '#ff5a3c', [
                ['AIRSTRIKE', () => this.ctx.streaks._airstrike()],
                gunLocked ? ['JACKPOT +250 COINS', () => shop.addCoins(250)] : ['SPECIAL WEAPON', () => this._buff('weapon')],
                ['JACKPOT +250 COINS', () => shop.addCoins(250)]]]
        }[tier];
        const [label, fn] = pick(table[2]);
        fn();
        hud.banner(`${table[0]} — ${label}`, table[1], 'Supply drop');
    }

    _buff(id) {
        const P = this.ctx.player;
        if (this.buffs[id] > 0) { this.buffs[id] = BUFF_T; return; }
        this.buffs[id] = id === 'weapon' ? 25 : BUFF_T;
        if (id === 'speed') { P.walkSpeed *= 1.28; P.sprintSpeed *= 1.28; }
        if (id === 'damage') P.damageMul = 1.6;
        if (id === 'weapon') {
            this._prev = { lo: P.loadout, cur: P.current };
            const idx = randElement([2, 3].filter(i => i !== P.current));
            P.setLoadout(P.loadout ? [...P.loadout, idx] : null);
            P.switchTo(idx);
            P.weapons[idx].ammo = P.defs[idx].magSize; P.weapons[idx].reserve = P.defs[idx].reserve;
        }
    }
    _endBuff(id) {
        const P = this.ctx.player; if (!(this.buffs[id] > 0)) return;
        this.buffs[id] = 0;
        if (id === 'speed') { P.walkSpeed /= 1.28; P.sprintSpeed /= 1.28; }
        if (id === 'damage') P.damageMul = 1;
        if (id === 'weapon' && this._prev) { P.setLoadout(this._prev.lo); P.switchTo(this._prev.cur); this._prev = null; }
    }
    _endBuffs() { for (const k of Object.keys(this.buffs)) this._endBuff(k); this.bf && (this.bf.textContent = ''); }
    _buffs(dt) {
        const names = { speed: '⚡ SPEED', damage: '🔥 DAMAGE', weapon: '★ SPECIAL GUN' }, out = [];
        for (const k of Object.keys(this.buffs)) {
            if (this.buffs[k] <= 0) continue;
            if (!this.ctx.player.alive) { this._endBuff(k); continue; }       // death clears buffs
            if ((this.buffs[k] -= dt) <= 0) this._endBuff(k); else out.push(`${names[k]} ${Math.ceil(this.buffs[k])}s`);
        }
        this.bf.textContent = out.join('\n');
    }
}
const IS_HOLD_HINT = 'HOLD E — OPEN SUPPLY DROP';
