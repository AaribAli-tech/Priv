// shop.js - coin wallet, shop (skins + upgrades), achievements, HUD coin panel.
// Everything is saved in localStorage ('nuketown.shop').
import { ACH } from './achdata.js';

export const COINS_PER_KILL = 10;
const KEY = 'nuketown.shop';

export const SKINS = [
    { id: 'default', name: 'Factory', hex: null, price: 0 },
    { id: 'sand', name: 'Desert Sand', hex: 0xd8b878, price: 113 },
    { id: 'crimson', name: 'Crimson', hex: 0xd0261c, price: 188 },
    { id: 'arctic', name: 'Arctic White', hex: 0xe8f0f8, price: 188 },
    { id: 'cobalt', name: 'Cobalt Blue', hex: 0x2f6bff, price: 225 },
    { id: 'toxic', name: 'Toxic Green', hex: 0x5dff3a, price: 300, glow: 1 },
    { id: 'violet', name: 'Void Violet', hex: 0x9a3cff, price: 375, glow: 1 },
    { id: 'gold', name: 'Solid Gold', hex: 0xffc72c, price: 750, glow: 1 }
];
export const UPGRADES = [
    { id: 'ammo', name: 'Extra Ammo', desc: '+50% / +100% reserve ammo', prices: [225, 525], val: [1.5, 2] },
    { id: 'mag', name: 'Bigger Magazine', desc: '+30% / +60% magazine size', prices: [300, 675], val: [1.3, 1.6] },
    { id: 'reload', name: 'Fast Reload', desc: '20% / 40% faster reload', prices: [225, 525], val: [0.8, 0.6] },
    { id: 'speed', name: 'Quick Legs', desc: '+7% / +14% move speed', prices: [263, 600], val: [1.07, 1.14] },
    { id: 'hp', name: 'Extra Health', desc: '+25 / +50 max health', prices: [300, 675], val: [25, 50] },
    { id: 'armor', name: 'Body Armor', desc: '25 / 50 armor, soaks 60% of damage', prices: [375, 825], val: [25, 50] }
];

let S = { coins: 0, lifetime: 0, skin: 'default', skins: ['default'], lv: {}, st: {}, ach: {} };
try { Object.assign(S, JSON.parse(localStorage.getItem(KEY) || '{}')); } catch { /* ignore */ }
S.st = S.st || {}; S.ach = S.ach || {};
const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch { /* private mode */ } };

let ctx = null, matchCoins = 0, pv = { nuke: false, air: false, uav: false }, hudKey = '';
const $ = (id) => document.getElementById(id);
const fmt = (n) => n.toLocaleString('en-US');
const bump = (k, n = 1) => { S.st[k] = (S.st[k] || 0) + n; };
const best = (k, v) => { if (v > (S.st[k] || 0)) S.st[k] = v; };

export function stats() {
    const lv = (id) => S.lv[id] || 0;
    const v = (id, base) => (lv(id) ? UPGRADES.find(u => u.id === id).val[lv(id) - 1] : base);
    return { ammo: v('ammo', 1), mag: v('mag', 1), reload: v('reload', 1), speed: v('speed', 1), hp: v('hp', 0), armor: v('armor', 0) };
}
const skin = () => SKINS.find(s => s.id === S.skin && s.hex !== null) || null;
const apply = () => { if (ctx) { ctx.player.applyShop(stats()); ctx.vm.setSkin(skin()); } };

/** Unlock anything whose stat reached its goal; the coins are paid out at once. */
function check() {
    for (const a of ACH) {
        if (S.ach[a.id] || (S.st[a.stat] || 0) < a.goal) continue;
        S.ach[a.id] = 1; S.coins += a.reward; toast(a);
    }
    save();
}
function toast(a) {
    let box = $('ntToasts');
    if (!box) { box = document.createElement('div'); box.id = 'ntToasts'; document.body.appendChild(box); }
    const d = document.createElement('div');
    d.innerHTML = `<small>ACHIEVEMENT UNLOCKED</small><b>${a.text}</b><span>&#129689; +${fmt(a.reward)}</span>`;
    box.appendChild(d); setTimeout(() => d.classList.add('out'), 3600); setTimeout(() => d.remove(), 4200);
}

export function beginMatch(c) {
    ctx = c; matchCoins = 0; pv = { nuke: false, air: false, uav: false }; apply();
}

/** Coins from a supply drop (same books as a kill reward). */
export function addCoins(n) { matchCoins += n; S.coins += n; S.lifetime += n; check(); }

/** One call per player kill. k: {head, type, label, streak, matchKills}. */
export function onKill(k = {}) {
    matchCoins += COINS_PER_KILL; S.coins += COINS_PER_KILL; S.lifetime += COINS_PER_KILL;
    bump('kills');
    if (k.head) bump('heads');
    if (k.type) bump(k.type);
    if (k.label === 'AIRSTRIKE') bump('airKills');
    best('bestStreak', k.streak || 0); best('bestMatch', k.matchKills || 0);
    check();
}

/** Called every frame: counts a streak the moment it is called in. */
export function poll(s) {
    if (!s) return;
    const u = s.used || {}, now = { nuke: !!s.nukeActive, air: !!u.air, uav: !!u.uav };
    let hit = false;
    for (const k of ['nuke', 'air', 'uav']) { if (now[k] && !pv[k]) { bump(k); hit = true; } pv[k] = now[k]; }
    if (hit) check();
}

export function endMatch(won, p) {
    bump('matches'); if (won) bump('wins');
    if (won && p && p.deaths === 0) bump('flawless');
    check();
    let el = $('ntEndCoins');
    if (!el) { el = document.createElement('div'); el.id = 'ntEndCoins'; const s = $('endStats'); s.parentNode.insertBefore(el, s); }
    el.innerHTML = `Coins earned <b>+${fmt(matchCoins)}</b> &nbsp;|&nbsp; Total saved <b>${fmt(S.coins)}</b>`;
}

function hudLoop() {
    requestAnimationFrame(hudLoop);
    const h = $('ntHud'); if (!h) return;
    const on = ctx && $('menu').style.display === 'none' && !$('end').classList.contains('on');
    if (!on) { h.style.display = 'none'; return; }
    const p = ctx.player;
    const key = `${S.coins}|${matchCoins}|${Math.ceil(p.armor || 0)}`;
    h.style.display = 'block';
    if (key === hudKey) return;
    hudKey = key;
    h.innerHTML = `<div>COINS <b>${fmt(S.coins)}</b> <span style="color:#7dff8a">+${fmt(matchCoins)}</span></div>` +
        (p.maxArmor ? `<div>ARMOR <b>${Math.ceil(p.armor || 0)}</b>/${p.maxArmor}</div>` : '');
}

// ---- UI ----
let tab = 'skins';
const row = (name, desc, price, btn) => `<div class="nsr"><div><b>${name}</b><small>${desc}</small></div><span>${price}</span>${btn}</div>`;
function render() {
    $('nsCoins').textContent = fmt(S.coins);
    document.querySelectorAll('#ntShop .nst').forEach(b => b.classList.toggle('on', b.dataset.tab === tab));
    let h = '';
    if (tab === 'skins') {
        for (const s of SKINS) {
            const own = S.skins.includes(s.id), eq = S.skin === s.id;
            const sw = `<i class="sw" style="background:${s.hex === null ? '#43484c' : '#' + s.hex.toString(16).padStart(6, '0')}"></i>`;
            h += row(sw + s.name, 'Weapon color', own ? 'OWNED' : fmt(s.price),
                eq ? '<button disabled>Equipped</button>' : own ? `<button data-a="eqs" data-i="${s.id}">Equip</button>` : `<button data-a="buys" data-i="${s.id}">Buy</button>`);
        }
    } else if (tab === 'up') {
        for (const u of UPGRADES) {
            const l = S.lv[u.id] || 0;
            h += row(u.name + ` <em>Lv ${l}/2</em>`, u.desc, l >= 2 ? 'MAX' : fmt(u.prices[l]),
                l >= 2 ? '<button disabled>Maxed</button>' : `<button data-a="up" data-i="${u.id}">Upgrade</button>`);
        }
    } else {
        const done = ACH.filter(a => S.ach[a.id]).length;
        h += `<div class="nsh">UNLOCKED ${done} / ${ACH.length}</div>`;
        for (const a of ACH) {
            const v = Math.min(S.st[a.stat] || 0, a.goal), d = !!S.ach[a.id];
            h += `<div class="nsr${d ? ' dn' : ''}"><div><b>${a.text}</b><small>${fmt(v)} / ${fmt(a.goal)}</small><i class="pb"><u style="width:${v / a.goal * 100}%"></u></i></div><span>&#129689; ${fmt(a.reward)}</span><em class="ck">${d ? '&#10003;' : ''}</em></div>`;
        }
    }
    $('nsList').innerHTML = h;
}
function act(a, i) {
    const msg = $('nsMsg');
    const spend = (n) => { if (S.coins < n) { msg.textContent = 'Not enough coins - go get some kills!'; return false; } S.coins -= n; msg.textContent = ''; bump('buys'); return true; };
    if (a === 'buys') { const s = SKINS.find(x => x.id === i); if (spend(s.price)) { S.skins.push(i); S.skin = i; } }
    else if (a === 'eqs') S.skin = i;
    else if (a === 'up') { const u = UPGRADES.find(x => x.id === i), l = S.lv[i] || 0; if (l < 2 && spend(u.prices[l])) S.lv[i] = l + 1; }
    check(); apply(); render();
}
function build() {
    const st = document.createElement('style');
    st.textContent = `#ntShop{position:fixed;inset:0;z-index:99999;display:none;background:rgba(6,8,10,.94);color:#fff;font-family:Rajdhani,sans-serif;align-items:center;justify-content:center}
#ntShop.on{display:flex}#ntShop .box{width:min(560px,94vw);max-height:92vh;display:flex;flex-direction:column;gap:10px;padding:18px}
#ntShop h2{margin:0;font:600 40px Teko,sans-serif;letter-spacing:.2em}#ntShop h2 b{color:#ffd23a}
#ntShop .tabs{display:flex;gap:6px}.nst{flex:1}#ntShop button{background:#1d2227;color:#fff;border:1px solid #3a434b;padding:8px 12px;font:600 16px Rajdhani,sans-serif;cursor:pointer;letter-spacing:.06em}
#ntShop button.on{background:#ffd23a;color:#000}#ntShop button:disabled{opacity:.5;cursor:default}
#nsList{overflow-y:auto;display:flex;flex-direction:column;gap:6px}.nsr{display:flex;align-items:center;gap:10px;background:#12161a;padding:8px 10px;border:1px solid #262d33}
.nsr>div{flex:1}.nsr small{display:block;color:#98a4ad}.nsr em{color:#ffd23a;font-style:normal;font-size:13px}.nsr>span{color:#ffd23a;font-weight:700;min-width:62px;text-align:right}
.nsr.dn{opacity:.55;border-color:#2c5a34}.ck{color:#7dff8a!important;font-size:20px!important;width:20px}.nsh{color:#ffd23a;font-weight:700;letter-spacing:.12em}
.pb{display:block;height:4px;background:#262d33;margin-top:4px}.pb u{display:block;height:100%;background:#ffd23a}
.sw{display:inline-block;width:12px;height:12px;margin-right:8px;border:1px solid #fff6}#nsMsg{color:#ff6a6a;min-height:20px}
#ntHud{position:fixed;left:14px;top:38%;z-index:50;display:none;font:600 17px Rajdhani,sans-serif;color:#fff;text-shadow:0 1px 3px #000;pointer-events:none;line-height:1.3}
#ntHud b{color:#ffd23a}#ntEndCoins{font:600 22px Rajdhani,sans-serif;margin:6px 0 10px;color:#ddd}#ntEndCoins b{color:#ffd23a}
#ntToasts{position:fixed;top:16px;left:50%;transform:translateX(-50%);z-index:100000;display:flex;flex-direction:column;gap:8px;pointer-events:none}
#ntToasts div{background:rgba(12,16,20,.94);border:1px solid #ffd23a;border-left:5px solid #ffd23a;padding:8px 18px;text-align:center;font-family:Rajdhani,sans-serif;animation:ntIn .4s ease-out;transition:opacity .5s}
#ntToasts div.out{opacity:0}#ntToasts small{display:block;color:#ffd23a;letter-spacing:.25em;font-size:12px}#ntToasts b{display:block;font:600 24px Teko,sans-serif;color:#fff;letter-spacing:.08em}#ntToasts span{color:#ffd23a;font-weight:700}
@media (max-width:700px),(max-height:520px){#ntShop .box{width:96vw;max-height:calc(100dvh - 12px);padding:max(8px,env(safe-area-inset-top)) 8px max(8px,env(safe-area-inset-bottom));gap:6px}
#ntShop h2{font-size:28px}#ntShop button{min-height:44px;font-size:15px;padding:8px 6px;touch-action:manipulation}.nst{font-size:13px!important}
#nsList{-webkit-overflow-scrolling:touch;overscroll-behavior:contain}.nsr{flex-wrap:wrap;gap:6px}.nsr>span{min-width:48px}.nsr small{font-size:13px}
#ntHud{top:30%;left:max(8px,env(safe-area-inset-left));font-size:14px}#ntToasts{top:max(8px,env(safe-area-inset-top));max-width:92vw}#ntToasts b{font-size:20px}}
@keyframes ntIn{from{transform:translateY(-30px);opacity:0}to{transform:none;opacity:1}}`;
    document.head.appendChild(st);
    const d = document.createElement('div'); d.id = 'ntShop';
    d.innerHTML = `<div class="box"><h2>SHOP <b>&#129689; <span id="nsCoins">0</span></b></h2>
<div class="tabs"><button class="nst" data-tab="skins">Weapon Skins</button><button class="nst" data-tab="up">Upgrades</button><button class="nst" data-tab="ach">Achievements</button></div>
<div id="nsMsg"></div><div id="nsList"></div><button id="nsClose">Close</button></div>`;
    document.body.appendChild(d);
    const hud = document.createElement('div'); hud.id = 'ntHud'; document.body.appendChild(hud);
    d.addEventListener('click', (e) => {
        const b = e.target.closest('button'); if (!b) return;
        if (b.id === 'nsClose') d.classList.remove('on');
        else if (b.dataset.tab) { tab = b.dataset.tab; $('nsMsg').textContent = ''; render(); }
        else if (b.dataset.a) act(b.dataset.a, b.dataset.i);
    });
    const open = () => { render(); d.classList.add('on'); };
    const add = (host, before) => {
        if (!host) return;
        const b = document.createElement('button'); b.className = 'menuBtn'; b.type = 'button'; b.textContent = 'Shop & Achievements';
        b.addEventListener('click', open); host.insertBefore(b, before || null);
    };
    add($('menuBtns'), $('btnHowTo'));
    add($('end'), $('btnMenu'));
    requestAnimationFrame(hudLoop);
}
if (document.body) build(); else addEventListener('DOMContentLoaded', build);
