// ============================================================================
// grenades.js — frag grenade (key 0) and flashbang (key 9).
//
// Flow: press the slot key → the grenade is drawn. Press and hold fire → the
// trajectory line appears and the left hand pulls the pin. Release → overarm
// throw. The grenade flies on the SAME physics step the preview line uses, so
// the line is exactly where it lands, and it detonates on the first floor/roof
// impact (walls bounce it).
//   frag  : lethal blast, line-of-sight checked, falls off with distance
//   flash : blinds bots (they cannot see or shoot) and whites out the player
//           if it goes off in view
// ============================================================================
import * as THREE from 'three';
import * as M from './materials.js';
import { loadGLB } from './glb.js';
import { SOFT_COVER } from './physics.js';
import { playWeaponSwap, playJump, playExplosion, playFlashbang, duckAudio } from './audio.js';

const G = 16, STEP = 1 / 30, SPEED = 32, PITCH_BIAS = 0.2, MAX_T = 6.5, MAX_PTS = Math.ceil(MAX_T / STEP) + 2;
const UP = new THREE.Vector3(0, 1, 0);
const HIP = new THREE.Vector3(0.14, -0.14, -0.40);
const DRAW_T = 0.35, PIN_T = 0.8, REL_T = 0.26, THROW_T = 0.55;

// yaw turns the model so the lever sits in the right palm; pinHome/spoonPivot are
// in model metres (read off the converted GLBs by scripts/obj2glb.mjs).
const KINDS = {
    frag: {
        key: 'Digit0', label: 'FRAG', slot: '0', file: 'nade_frag.glb', yaw: Math.PI / 2,
        pinHome: [0.001, 0.040, 0.0205], spoonPivot: [0, 0.047, 0.02], spoonDir: -1, color: 0xff7a3a
    },
    flash: {
        key: 'Digit9', label: 'FLASH', slot: '9', file: 'nade_flash.glb', yaw: -Math.PI / 2,
        pinHome: [0.0005, 0.0615, -0.0245], spoonPivot: [0, 0.07, -0.016], spoonDir: 1, color: 0xbfe0ff
    }
};
const START = { frag: 2, flash: 2 };

const ease = t => { t = Math.min(1, Math.max(0, t)); return t * t * (3 - 2 * t); };
const seg = (k, a, b) => ease((k - a) / (b - a));
const _v = new THREE.Vector3(), _w = new THREE.Vector3(), _d = new THREE.Vector3(), _dir = new THREE.Vector3();

// throw keyframes: [t, x, y, z, rotX] — relative to the hip pose, camera space
const THROW_KF = [
    [0.00, 0.00, 0.00, 0.00, 0.0],
    [0.14, 0.06, 0.10, 0.16, 0.55],
    [0.26, -0.02, 0.00, -0.32, -0.70],
    [0.40, -0.10, -0.20, -0.20, -1.0],
    [0.55, -0.05, -0.42, 0.00, -1.0]
];

export class Grenades {
    constructor({ vm, cw, camera, scene, effects, hud, player, getBots, onHit }) {
        Object.assign(this, { vm, cw, camera, scene, effects, hud, player, getBots, onHit });
        this.arm = null;                 // loadout's two utility picks (array of kinds); null = stock (both)
        this.counts = this._start();
        this.active = false; this.kind = null; this.state = 'none'; this.t = 0;
        this.assets = {}; this.rigs = {};
        this.projectiles = []; this.bursts = [];
        this.queued = false; this._wasDown = false; this.released = false;
        this.blind = 0; this.blindMax = 1; this._seen = 0;
        this._buildLine(); this._buildDom();
        for (const k in KINDS) loadGLB('assets/models/' + KINDS[k].file, true).then(g => { this.assets[k] = g; });
        // the HUD / overlay hide themselves if the game loop stops calling update()
        setInterval(() => { if (performance.now() - this._seen > 400) this._setDom(false); }, 250);
    }

    // ── public API ──────────────────────────────────────────────────────────
    /** Key handler: number key for a kind. Pressing it again puts the grenade away. */
    equip(kind) {
        const p = this.player;
        if (!p.alive || p.paused) return;
        if (this.active && this.kind === kind && (this.state === 'idle' || this.state === 'draw')) return this.unequip();
        if (this.active && this.state !== 'idle' && this.state !== 'draw') return;     // mid-throw
        if (this.arm && !this.arm.includes(kind)) { this._note(KINDS[kind].label + ' NOT IN LOADOUT'); return; }
        if (this.counts[kind] <= 0) { this._note('NO ' + KINDS[kind].label + ' LEFT'); return; }
        const ml = p.ctx && p.ctx.melee; if (ml && ml.active) ml.unequip();
        if (this.active) this._rig().root.visible = false;
        this.kind = kind; this.active = true; this._startDraw();
        this.vm.holder.visible = false;
        p.mouseRight = false; p.isADS = false;
    }

    unequip() {
        if (!this.active) return;
        if (this.state === 'throw') return;
        const r = this.rigs[this.kind]; if (r) r.root.visible = false;
        this.active = false; this.state = 'none'; this.queued = false;
        this.vm.holder.visible = true;
        this.line.visible = this.dots.visible = this.ring.visible = false;
    }

    /** Loadout UTILITY slots: one or two kinds (same kind twice = double stock). null = stock. */
    setArm(kinds) {
        const a = [].concat(kinds).filter(k => KINDS[k]);
        this.arm = a.length ? a : null; this.reset();
    }
    _start() {
        if (!this.arm) return { ...START };
        const c = {}; for (const k in KINDS) c[k] = this.arm.filter(x => x === k).length * START[k];
        return c;
    }

    reset() { this.counts = this._start(); this.unequip(); for (const p of this.projectiles) this.scene.remove(p.mesh); this.projectiles.length = 0; this.blind = 0; }

    // ── per frame ───────────────────────────────────────────────────────────
    update(dt) {
        this._seen = performance.now();
        const p = this.player;
        this._setDom(true);
        this._projectiles(dt); this._bursts(dt); this._overlay(dt);
        if (!p.alive) { if (this.active) this.unequip(); this._hideLine(); return; }
        if (!this.active) return;
        if (p.paused) { this._wasDown = p.mouseDown || p.touch.fire; return; }

        const down = p.mouseDown || p.touch.fire;
        const edge = down && !this._wasDown; this._wasDown = down;
        this.t += dt;
        const rig = this._rig();

        switch (this.state) {
            case 'draw':
                if (this.t >= DRAW_T) { this.state = 'idle'; this.t = 0; }
                break;
            case 'idle':
                if (edge) { this.state = 'pin'; this.t = 0; this.queued = false; playWeaponSwap(); }
                break;
            case 'pin':
                if (!down) this.queued = true;
                if (this.t >= PIN_T) { this.state = this.queued ? 'throw' : 'aim'; this.t = 0; this.released = false; if (this.state === 'throw') playJump(); }
                break;
            case 'aim':
                if (!down) { this.state = 'throw'; this.t = 0; this.released = false; playJump(); }
                break;
            case 'throw':
                if (!this.released && this.t >= REL_T) { this.released = true; this._launch(); }
                if (this.t >= THROW_T) {
                    if (this.counts[this.kind] > 0) this._startDraw();
                    else { this.state = 'idle'; this.unequip(); }
                }
                break;
        }

        // trajectory line from the moment the button goes down until the throw
        if (this.state === 'pin' || this.state === 'aim') this._preview(); else this._hideLine();
        this._pose(rig, dt);
    }

    // ── rig (viewmodel) ─────────────────────────────────────────────────────
    _startDraw() {
        this.state = 'draw'; this.t = 0; this.queued = false;
        const r = this._rig();
        r.root.visible = true; r.model.visible = true; r.pin.visible = true; r.pin.position.set(0, 0, 0);
        r.spoonPivot.rotation.set(0, 0, 0);
        r.root.visible = true;
    }

    _rig() {
        let r = this.rigs[this.kind];
        // a rig built before its GLB arrived used the stand-in: rebuild once the real model is here
        if (r && r.fallback && this.assets[this.kind]) { this.vm.scene.remove(r.root); r = null; }
        if (!r) r = this.rigs[this.kind] = this._buildRig(this.kind);
        return r;
    }

    _buildRig(kind) {
        const K = KINDS[kind];
        const root = new THREE.Group(); root.position.copy(HIP);
        const model = new THREE.Group(); model.rotation.y = K.yaw; root.add(model);

        const src = this.assets[kind] && this.assets[kind].scene.clone(true);
        let pin, spoon, body;
        if (src) { body = src.getObjectByName('Body'); pin = src.getObjectByName('Pin'); spoon = src.getObjectByName('Spoon'); }
        const usedFallback = !body || !pin || !spoon;
        if (usedFallback) ({ body, pin, spoon } = fallbackParts(kind));   // GLB missing: simple stand-in
        const spoonPivot = new THREE.Group(); spoonPivot.position.fromArray(K.spoonPivot);
        spoon.position.sub(spoonPivot.position);
        spoonPivot.add(spoon);
        model.add(body, pin, spoonPivot);

        // hands & sleeves
        const glove = M.glove(), sleeve = M.camoBlue();
        const hand = (g, w, h, d, x, y, z, rx = 0, rz = 0) => {
            const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), glove);
            m.position.set(x, y, z); m.rotation.set(rx, 0, rz); g.add(m); return m;
        };
        const arm = (g, to) => {
            const dir = new THREE.Vector3().fromArray(to), len = dir.length();
            const a = new THREE.Group();
            const cuff = new THREE.Mesh(new THREE.CylinderGeometry(0.034, 0.036, 0.05, 10), glove);
            const sl = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.056, len, 10), sleeve);
            cuff.position.y = 0.025; sl.position.y = len / 2 + 0.05; a.add(cuff, sl);
            a.quaternion.setFromUnitVectors(UP, dir.normalize());
            g.add(a);
        };
        // right: palm against the lever, fingers wrapped across the front, thumb on top
        const handR = new THREE.Group(); root.add(handR);
        hand(handR, 0.030, 0.075, 0.056, 0.040, -0.014, 0.004);
        for (let i = 0; i < 4; i++) hand(handR, 0.050, 0.016, 0.020, 0.012, 0.022 - i * 0.017, -0.034);
        hand(handR, 0.040, 0.016, 0.022, 0.026, 0.046, 0.000, 0, 0.2);
        arm(handR, [0.13, -0.36, 0.46]); handR.children[handR.children.length - 1].position.set(0.05, -0.05, 0.03);
        // left: pinch grip, origin sits on the finger tips
        const handL = new THREE.Group(); root.add(handL);
        hand(handL, 0.050, 0.030, 0.060, -0.020, -0.020, 0.040);
        hand(handL, 0.014, 0.014, 0.034, 0.000, 0.006, 0.000);
        hand(handL, 0.014, 0.014, 0.034, 0.000, -0.012, 0.000);
        arm(handL, [-0.10, -0.30, 0.40]); handL.children[handL.children.length - 1].position.set(-0.03, -0.04, 0.06);
        handL.visible = false;

        const pinHomeRoot = new THREE.Vector3().fromArray(K.pinHome).applyEuler(model.rotation);
        root.visible = false;
        this.vm.scene.add(root);
        return { fallback: usedFallback, root, model, pin, spoon, spoonPivot, handR, handL, pinHomeRoot, invQ: model.quaternion.clone().invert(), body };
    }

    _pose(r, dt) {
        const K = KINDS[this.kind], t = this.t;
        let px = 0, py = 0, pz = 0, rx = 0, rz = 0;
        const bob = Math.sin(performance.now() / 700) * 0.003;
        r.handL.visible = false;

        if (this.state === 'draw') { const e = 1 - ease(t / DRAW_T); py -= 0.42 * e; rx += 0.6 * e; }
        else if (this.state === 'pin') {
            const k = t / PIN_T;
            const reach = seg(k, 0, 0.30), pull = seg(k, 0.42, 0.66), away = seg(k, 0.70, 1.0);
            // displacement of the pin (and the hand holding it) in camera space
            _v.set(-0.09 * pull - 0.22 * away, -0.02 * pull - 0.20 * away, 0.11 * pull);
            r.handL.visible = true;
            _w.copy(r.pinHomeRoot).add(_d.set(-0.004, -0.004, 0.006));      // fingertips on the pin
            r.handL.position.lerpVectors(_dir.set(-0.30, -0.30, 0.06), _w, reach).add(_v);
            r.pin.position.copy(_v).applyQuaternion(r.invQ);
            r.pin.visible = k < 0.92;
            rz += -0.05 * seg(k, 0.4, 0.7);                       // right hand tightens on the lever
        } else if (this.state === 'aim') {
            r.pin.visible = false;
            // arm raises a touch, ready to throw
            py += 0.012; pz += 0.02; rx += 0.18;
        } else if (this.state === 'throw') {
            r.pin.visible = false;
            let a = THROW_KF[0], b = THROW_KF[1];
            for (let i = 0; i < THROW_KF.length - 1; i++) if (t >= THROW_KF[i][0]) { a = THROW_KF[i]; b = THROW_KF[i + 1]; }
            const e = ease((t - a[0]) / (b[0] - a[0]));
            px = a[1] + (b[1] - a[1]) * e; py = a[2] + (b[2] - a[2]) * e;
            pz = a[3] + (b[3] - a[3]) * e; rx = a[4] + (b[4] - a[4]) * e;
            if (this.released) {                                   // lever pops off, grenade has left the hand
                r.model.visible = false;
            } else {
                r.spoonPivot.rotation.x = 0;
            }
        } else if (this.state === 'idle') { r.pin.visible = true; }

        r.root.position.set(HIP.x + px, HIP.y + py + bob, HIP.z + pz);
        r.root.rotation.set(rx, 0, rz);
        void K; void dt;
    }

    // ── trajectory ──────────────────────────────────────────────────────────
    _buildLine() {
        const geo = new THREE.BufferGeometry();
        this._pts = new Float32Array(MAX_PTS * 3);
        geo.setAttribute('position', new THREE.BufferAttribute(this._pts, 3));
        const mk = (obj) => { obj.frustumCulled = false; obj.renderOrder = 998; obj.visible = false; this.scene.add(obj); return obj; };
        this._lineMat = new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.9, depthTest: false });
        this.line = mk(new THREE.Line(geo, this._lineMat));
        this._dotMat = new THREE.PointsMaterial({ color: 0xffffff, size: 6, sizeAttenuation: false, transparent: true, opacity: 0.95, depthTest: false });
        this.dots = mk(new THREE.Points(geo, this._dotMat));
        this._ringMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.85, depthTest: false, side: THREE.DoubleSide });
        this.ring = mk(new THREE.Mesh(new THREE.RingGeometry(0.28, 0.36, 28), this._ringMat));
    }

    _hideLine() { this.line.visible = this.dots.visible = this.ring.visible = false; }

    /** Where the grenade starts and how fast it leaves — shared by the line and the throw. */
    _launchState(pos, vel) {
        const c = this.camera, p = this.player;
        const fwd = _v.set(0, 0, -1).applyQuaternion(c.quaternion);
        const right = _w.set(1, 0, 0).applyQuaternion(c.quaternion);
        vel.copy(fwd).applyAxisAngle(right, PITCH_BIAS).multiplyScalar(SPEED);
        vel.x += p.velocity.x * 0.5; vel.z += p.velocity.z * 0.5;
        const eye = c.position;
        pos.copy(eye).addScaledVector(fwd, 0.40).addScaledVector(right, 0.14);
        pos.y -= 0.10;
        // never start the grenade on the far side of a wall
        _d.copy(pos).sub(eye); const len = _d.length(); _d.divideScalar(len || 1);
        const h = this.cw.raycast(eye, _d, len, SOFT_COVER);
        if (h) pos.copy(eye).addScaledVector(_d, Math.max(0, h.distance - 0.12));
    }

    /** One fixed physics step. Returns a detonation hit, or null. */
    _step(pos, vel) {
        vel.y -= G * STEP;
        _d.copy(vel).multiplyScalar(STEP);
        const len = _d.length();
        if (len > 1e-6) {
            _dir.copy(_d).divideScalar(len);
            const h = this.cw.raycast(pos, _dir, len + 0.04, SOFT_COVER);
            if (h) {
                pos.copy(h.point).addScaledVector(h.normal, 0.05);
                if (h.normal.y > 0.5) return h.normal;                       // floor / roof → boom
                const vn = vel.dot(h.normal);                                 // wall → bounce
                vel.addScaledVector(h.normal, -2 * vn).multiplyScalar(0.45);
                return null;
            }
            pos.add(_d);
        }
        const gy = this.cw.groundHeight(pos.x, pos.z, pos.y + 0.3, 0.05);
        if (pos.y <= gy + 0.05) { pos.y = gy + 0.05; return UP; }
        return null;
    }

    _preview() {
        const K = KINDS[this.kind];
        const pos = new THREE.Vector3(), vel = new THREE.Vector3();
        this._launchState(pos, vel);
        let n = 0, hit = null;
        const a = this._pts;
        a[0] = pos.x; a[1] = pos.y; a[2] = pos.z; n = 1;
        for (let i = 0; i < MAX_PTS - 2; i++) {
            hit = this._step(pos, vel);
            a[n * 3] = pos.x; a[n * 3 + 1] = pos.y; a[n * 3 + 2] = pos.z; n++;
            if (hit) break;
        }
        this.line.geometry.setDrawRange(0, n);
        this.line.geometry.attributes.position.needsUpdate = true;
        this._lineMat.color.setHex(K.color); this._dotMat.color.setHex(K.color); this._ringMat.color.setHex(K.color);
        this.line.visible = this.dots.visible = true;
        this.ring.visible = !!hit;
        if (hit) {
            this.ring.position.copy(pos).addScaledVector(hit, 0.02);
            this.ring.quaternion.setFromUnitVectors(_v.set(0, 0, 1), hit);
        }
    }

    // ── projectile ──────────────────────────────────────────────────────────
    _launch() {
        const r = this._rig(), kind = this.kind;
        const pos = new THREE.Vector3(), vel = new THREE.Vector3();
        this._launchState(pos, vel);
        const mesh = new THREE.Group();
        const c = r.model.clone(true);
        c.rotation.set(0, 0, 0);
        c.traverse(o => { if (o.isMesh) o.castShadow = true; });
        // the clone keeps the animated pose: pin gone, lever flipped off its hinge
        const pin = c.children.find(o => o !== undefined && o.name === 'Pin'); if (pin) pin.visible = false;
        const sp = c.children.find(o => o.isGroup && o.children[0] && o.children[0].name === 'Spoon');
        if (sp) sp.rotation.x = KINDS[kind].spoonDir * 1.1;
        mesh.add(c); mesh.position.copy(pos); this.scene.add(mesh);
        this.counts[kind]--;
        this.projectiles.push({
            kind, mesh, pos, vel, prev: pos.clone(), acc: 0, age: 0,
            spin: new THREE.Vector3(Math.random() * 8 - 4, Math.random() * 3, 9 + Math.random() * 5)
        });
    }

    _projectiles(dt) {
        for (let i = this.projectiles.length - 1; i >= 0; i--) {
            const g = this.projectiles[i];
            g.age += dt; g.acc += dt;
            let boom = null;
            while (g.acc >= STEP && !boom) {
                g.prev.copy(g.pos);
                const hit = this._step(g.pos, g.vel);
                g.acc -= STEP;
                if (hit) boom = hit;
            }
            if (boom || g.age > 10 || g.pos.y < -20) {
                this.scene.remove(g.mesh); this.projectiles.splice(i, 1);
                if (boom) this._explode(g.kind, g.pos.clone());
                continue;
            }
            g.mesh.position.lerpVectors(g.prev, g.pos, g.acc / STEP);
            g.mesh.rotation.x += g.spin.x * dt; g.mesh.rotation.y += g.spin.y * dt; g.mesh.rotation.z += g.spin.z * dt;
        }
    }

    // ── detonation ──────────────────────────────────────────────────────────
    _explode(kind, pos) {
        if (this.onBoom) this.onBoom(kind, pos);
        const p = this.player, cw = this.cw;
        const eye = this.camera.position, dEye = eye.distanceTo(pos);
        const lift = pos.clone(); lift.y += 0.3;

        if (kind === 'frag') {
            this.effects.explosion(pos, 2.85);
            this._burst(pos, 0xffa040, 4.8, 0.35);
            playExplosion();
            p.addShake(Math.max(0, 1 - dEye / 48) * 0.7);
            const R = 15, LETHAL = 7.5, PEAK = 250;
            const dmgAt = d => d < LETHAL ? PEAK : PEAK * (1 - (d - LETHAL) / (R - LETHAL));
            for (const bot of this.getBots()) {
                if (!bot.alive || !p.canShoot(bot)) continue;
                _v.set(bot.position.x, bot.position.y + 1.0, bot.position.z);
                const d = _v.distanceTo(pos);
                if (d > R || (d > 1.6 && !cw.isLineOfSight(lift, _v))) continue;
                const killed = bot.takeDamage(dmgAt(d), p.name);
                this.onHit(bot, killed, 'FRAG');
            }
            if (p.alive && dEye < R && (dEye < 1.6 || cw.isLineOfSight(lift, eye)))
                p.takeDamage(dmgAt(dEye) * 0.6, p.name, pos);
        } else {
            this.effects._flash(pos, 0xffffff, 70, 0.3, 60);
            this._burst(pos, 0xffffff, 6.75, 0.28);
            playFlashbang();
            const R = 48; let blinded = 0;
            for (const bot of this.getBots()) {
                if (!bot.alive || !p.canShoot(bot)) continue;
                _v.set(bot.position.x, bot.position.y + 1.5, bot.position.z);
                const d = _v.distanceTo(pos);
                if (d > R || (d > 1.6 && !cw.isLineOfSight(lift, _v))) continue;
                // facing the bang matters: eyes toward it = full blind, back turned = a flicker
                const fx = -Math.sin(bot.yaw), fz = -Math.cos(bot.yaw);
                const dot = fx * (pos.x - bot.position.x) / (d || 1) + fz * (pos.z - bot.position.z) / (d || 1);
                const dur = (0.9 + 5.2 * Math.max(0, dot)) * (1 - 0.6 * d / R) + (d < 4 ? 1.5 : 0);
                bot.blindT = Math.max(bot.blindT || 0, dur);
                blinded++;
            }
            if (blinded) this.hud.banner('ENEMY FLASHED' + (blinded > 1 ? ' ×' + blinded : ''), '#ffffff', '');
            // the player is caught too if it goes off near / in view
            if (p.alive && dEye < R && (dEye < 2 || cw.isLineOfSight(lift, eye))) {
                const f = _v.set(0, 0, -1).applyQuaternion(this.camera.quaternion);
                const dot = f.dot(_w.copy(pos).sub(eye).normalize());
                const s = (0.3 + 0.7 * Math.max(0, dot)) * (1 - dEye / R);
                const dur = Math.min(6, 0.8 + 5 * s + (dEye < 3 ? 1.5 : 0));
                if (dur > this.blind) { this.blind = this.blindMax = dur; duckAudio(0.12, dur); }
            }
        }
    }

    _burst(pos, color, size, dur) {
        const m = new THREE.Mesh(new THREE.SphereGeometry(1, 14, 10),
            new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 1, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }));
        m.position.copy(pos); m.scale.setScalar(0.3); this.scene.add(m);
        this.bursts.push({ m, size, dur, t: 0 });
    }

    _bursts(dt) {
        for (let i = this.bursts.length - 1; i >= 0; i--) {
            const b = this.bursts[i]; b.t += dt;
            const k = b.t / b.dur;
            if (k >= 1) { this.scene.remove(b.m); b.m.geometry.dispose(); b.m.material.dispose(); this.bursts.splice(i, 1); continue; }
            b.m.scale.setScalar(0.3 + b.size * ease(k * 1.6));
            b.m.material.opacity = 1 - k * k;
        }
    }

    // ── DOM: ammo readout + white-out ───────────────────────────────────────
    _buildDom() {
        const hud = document.createElement('div');
        hud.style.cssText = 'position:fixed;right:28px;bottom:150px;z-index:20;pointer-events:none;display:none;' +
            "font:600 18px/1.35 'Rajdhani',system-ui,sans-serif;letter-spacing:.08em;text-align:right;text-shadow:0 1px 4px #000";
        const ov = document.createElement('div');
        ov.style.cssText = 'position:fixed;inset:0;z-index:30;pointer-events:none;background:#fff;opacity:0;display:none';
        const note = document.createElement('div');
        note.style.cssText = 'position:fixed;left:50%;bottom:200px;transform:translateX(-50%);z-index:20;pointer-events:none;color:#ffb833;' +
            "font:600 20px 'Rajdhani',system-ui,sans-serif;letter-spacing:.12em;text-shadow:0 1px 4px #000;display:none";
        document.body.append(hud, ov, note);
        this.dom = { hud, ov, note }; this._noteT = 0;
    }

    _setDom(on) {
        const d = on ? '' : 'none';
        if (this.dom.hud.style.display !== d) this.dom.hud.style.display = d;
        if (!on) { this.dom.ov.style.display = 'none'; this.dom.note.style.display = 'none'; }
    }

    _note(txt) { this.dom.note.textContent = txt; this.dom.note.style.display = ''; this._noteT = 1.2; }

    _hudText() {
        return Object.keys(KINDS).filter(k => !this.arm || this.arm.includes(k)).map(k => {
            const K = KINDS[k], on = this.active && this.kind === k, n = this.counts[k];
            return `<div style="opacity:${on ? 1 : n ? 0.6 : 0.3};color:${on ? '#ffd45a' : '#fff'}">[${K.slot}] ${K.label} ×${n}</div>`;
        }).join('');
    }

    _overlay(dt) {
        const html = this._hudText();
        if (html !== this._lastHtml) { this._lastHtml = html; this.dom.hud.innerHTML = html; }
        if (this._noteT > 0) { this._noteT -= dt; if (this._noteT <= 0) this.dom.note.style.display = 'none'; }
        if (this.blind > 0) {
            this.blind = Math.max(0, this.blind - dt);
            const left = this.blind / this.blindMax;
            this.dom.ov.style.display = '';
            this.dom.ov.style.opacity = left > 0.55 ? '1' : String(Math.max(0, left / 0.55));
        } else if (this.dom.ov.style.display !== 'none') this.dom.ov.style.display = 'none';
    }
}

/** Plain stand-in used only if a GLB fails to load, so the feature still works. */
function fallbackParts(kind) {
    const green = new THREE.MeshStandardMaterial({ color: kind === 'frag' ? 0x2f3d22 : 0x222428, roughness: 0.55 });
    const metal = new THREE.MeshStandardMaterial({ color: 0x777777, metalness: 0.8, roughness: 0.4 });
    const h = kind === 'frag' ? 0.095 : 0.14, r = kind === 'frag' ? 0.022 : 0.017;
    const body = new THREE.Mesh(kind === 'frag' ? new THREE.SphereGeometry(r, 14, 10).scale(1, 2.1, 1) : new THREE.CylinderGeometry(r, r, h, 14), green);
    body.name = 'Body';
    const K = KINDS[kind];
    const pin = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.004, 0.004), metal); pin.position.fromArray(K.pinHome); pin.name = 'Pin';
    const spoon = new THREE.Mesh(new THREE.BoxGeometry(0.01, 0.06, 0.004), metal);
    spoon.position.set(0, K.spoonPivot[1] - 0.03, K.spoonPivot[2]); spoon.name = 'Spoon';
    return { body, pin, spoon };
}
