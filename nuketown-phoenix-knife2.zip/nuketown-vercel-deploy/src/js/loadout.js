// loadout.js - LOADOUT page: 3 saved loadouts, each = PRIMARY + SECONDARY + 2 UTILITIES + MELEE (knife, key 3).
// Saved in localStorage ('nuketown.loadout'). Uses the game's own weapon defs and
// grenade system; adds no stats, XP or upgrades. Applied from startMatch().
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { WEAPON_DEFS, createWorldWeapon } from './weapons.js';
import { vmAssets, vmAssetsReady } from './vmassets.js';
import { loadGLB } from './glb.js';

const KEY = 'nuketown.loadout';
// Indices into WEAPON_DEFS. 0-3 are the carried guns, 4-5 the sidearms.
export const PRIMARIES = [0, 1, 2, 3];
export const SECONDARIES = [4, 5];
export const ARMS = [
    { id: 'frag', name: 'FRAG GRENADE', tag: 'LETHAL', desc: 'Lethal blast, line of sight checked. Hurts you too. x2' },
    { id: 'flash', name: 'FLASHBANG', tag: 'TACTICAL', desc: 'Blinds enemies in view so they cannot see or shoot. x2' }
];
export const MELEES = [
    { id: 'knife', name: 'COMBAT KNIFE', tag: 'MELEE', desc: 'One-hit kill up close. Press 3 in any mode, any loadout.' }
];
const TYPE = { rifle: 'ASSAULT RIFLE', smg: 'SUBMACHINE GUN', sniper: 'SNIPER RIFLE', shotgun: 'SHOTGUN', pistol: 'PISTOL' };
const DEFAULT = () => ({ p: 0, s: 4, a: 'frag', b: 'flash', m: 'knife' });

let S = { sel: 0, sets: [DEFAULT(), DEFAULT(), DEFAULT()] };
try {
    const j = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (j && Array.isArray(j.sets)) {
        S.sel = j.sel >= 0 && j.sel < 3 ? j.sel | 0 : 0;
        for (let i = 0; i < 3; i++) {
            const x = j.sets[i] || {};
            S.sets[i] = {
                p: PRIMARIES.includes(x.p) ? x.p : 0,
                s: SECONDARIES.includes(x.s) ? x.s : 4,
                a: ARMS.some(a => a.id === x.a) ? x.a : 'frag',
                b: ARMS.some(a => a.id === x.b) ? x.b : 'flash',
                m: 'knife'
            };
        }
    }
} catch { /* ignore */ }
const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch { /* private mode */ } };

export const active = () => S.sets[S.sel];

/**
 * Called once per match after the player is spawned. `weapons:false` leaves the
 * guns alone (Gun Game owns your weapon); the ARM always applies.
 */
let _player = null;
export function applyToMatch(player, { weapons = true } = {}) {
    _player = player;
    const L = active();
    const g = player.ctx && player.ctx.grenades;
    if (g && g.setArm) g.setArm([L.a, L.b]);
    if (weapons && player.setLoadout) {
        player.setLoadout([L.p, L.s]);
        player.switchTo(L.p);
    }
}


// ── previews: the game's own models, drawn once to small images ─────────────
const ICON = {};            // 'w:rifle' | 'g:frag' -> data URL
let _busy = false;
const iconKey = (k, v) => k === 'm' ? 'k:' + v : (k === 'a' || k === 'b') ? 'g:' + v : 'w:' + WEAPON_DEFS[v].type;

function snap(r, scene, cam, obj, wide) {
    const box = new THREE.Box3().setFromObject(obj), c = box.getCenter(new THREE.Vector3());
    const sz = box.getSize(new THREE.Vector3()), rad = sz.length() / 2;
    const d = (wide ? new THREE.Vector3(1, 0.2, 0.3) : new THREE.Vector3(0.35, 0.25, 1)).normalize();
    // Start from the bounding sphere, then tighten until the box fills ~90% of the frame.
    let dist = rad * 3;
    const pts = []; for (const x of [box.min.x, box.max.x]) for (const y of [box.min.y, box.max.y]) for (const z of [box.min.z, box.max.z]) pts.push(new THREE.Vector3(x, y, z));
    for (let n = 0; n < 4; n++) {
        cam.position.copy(c).addScaledVector(d, dist); cam.near = dist / 50; cam.far = dist * 4;
        cam.updateProjectionMatrix(); cam.lookAt(c); cam.updateMatrixWorld(true);
        let mx = 0, my = 0;
        for (const q of pts) { const v = q.clone().project(cam); mx = Math.max(mx, Math.abs(v.x)); my = Math.max(my, Math.abs(v.y)); }
        dist *= Math.max(mx / 0.92, my / 0.9);
    }
    cam.position.copy(c).addScaledVector(d, dist); cam.near = dist / 50; cam.far = dist * 4; cam.updateProjectionMatrix(); cam.lookAt(c);
    scene.add(obj); r.render(scene, cam); scene.remove(obj);
    return r.domElement.toDataURL('image/png');
}

async function makeIcons() {
    if (_busy) return; _busy = true;
    let r = null;
    try {
        const need = [];
        for (const i of PRIMARIES.concat(SECONDARIES)) { const k = iconKey('p', i); if (!ICON[k] && !need.includes(k)) need.push(k); }
        for (const a of ARMS) if (!ICON['g:' + a.id]) need.push('g:' + a.id);
        if (!ICON['k:knife']) need.push('k:knife');
        if (!need.length) return;
        const gl = {};
        for (const a of ARMS) if (need.includes('g:' + a.id)) gl[a.id] = await loadGLB('assets/models/nade_' + a.id + '.glb', true);
        let knifeGlb = null;
        if (need.includes('k:knife')) knifeGlb = await loadGLB('assets/models/wpn_knife.glb', true);
        r = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
        r.setPixelRatio(1); r.setSize(560, 280); r.setClearColor(0x000000, 0);
        r.toneMapping = THREE.ACESFilmicToneMapping; r.toneMappingExposure = 1.7;
        const scene = new THREE.Scene(), pm = new THREE.PMREMGenerator(r);
        scene.environment = pm.fromScene(new RoomEnvironment(), 0.04).texture; scene.environmentIntensity = 1.5;
        const key = new THREE.DirectionalLight(0xfff2dd, 3); key.position.set(1, 2, 1.5); scene.add(key, new THREE.AmbientLight(0xa8bccd, 1.0));
        const cam = new THREE.PerspectiveCamera(28, 2, 0.01, 10);
        for (const k of need) {
            let obj = null, wide = true;
            if (k[0] === 'w') {
                const type = k.slice(2);
                obj = vmAssetsReady() ? vmAssets.weapon(type) : null;
                if (!obj) obj = createWorldWeapon(type);          // procedural stand-in
            } else if (k[0] === 'k') {
                obj = knifeGlb && knifeGlb.scene.clone(true);
            } else {
                wide = false;
                const g = gl[k.slice(2)]; obj = g && g.scene.clone(true);
            }
            if (obj) ICON[k] = snap(r, scene, cam, obj, wide);
        }
        pm.dispose();
    } catch (e) { console.warn('[loadout] previews unavailable', e && e.message); }
    finally { if (r) { r.dispose(); r.forceContextLoss && r.forceContextLoss(); } _busy = false; }
}
const pic = (k, v) => { const u = ICON[iconKey(k, v)]; return `<u class="loi"${u ? ` style="background-image:url(${u})"` : ''}></u>`; };

// ── UI ──────────────────────────────────────────────────────────────────────
let slot = 'p';
const $ = id => document.getElementById(id);
const def = i => WEAPON_DEFS[i];
const arm = id => ARMS.find(a => a.id === id);
const stat = d => `DMG ${d.damage}${d.pellets ? 'x' + d.pellets : ''} &middot; ${d.rpm} RPM &middot; MAG ${d.magSize}`;

function slotInfo(k) {
    const L = active();
    if (k === 'm') return { label: 'MELEE', name: MELEES[0].name, sub: MELEES[0].tag, line: MELEES[0].desc, img: pic('m', 'knife') };
    if (k === 'a' || k === 'b') { const a = arm(L[k]); return { label: k === 'a' ? 'UTILITY 1' : 'UTILITY 2', name: a.name, sub: a.tag, line: a.desc, img: pic('a', L[k]) }; }
    const v = k === 'p' ? L.p : L.s, d = def(v);
    return { label: k === 'p' ? 'PRIMARY' : 'SECONDARY', name: d.name, sub: TYPE[d.type] || d.type.toUpperCase(), line: stat(d), img: pic('w', v) };
}

function options(k) {
    const L = active();
    if (k === 'm') return MELEES.map(m => ({ id: m.id, name: m.name, sub: m.tag, line: m.desc, on: true, img: pic('m', m.id) }));
    if (k === 'a' || k === 'b') return ARMS.map(a => ({ id: a.id, name: a.name, sub: a.tag, line: a.desc, on: L[k] === a.id, img: pic('a', a.id) }));
    return (k === 'p' ? PRIMARIES : SECONDARIES).map(i => {
        const d = def(i);
        return { id: i, name: d.name, sub: (TYPE[d.type] || d.type) + ' / ' + d.fireMode, line: stat(d), on: (k === 'p' ? L.p : L.s) === i, img: pic('w', i) };
    });
}

function render() {
    document.querySelectorAll('#ntLo .lot').forEach((b, i) => b.classList.toggle('on', i === S.sel));
    $('loSlots').innerHTML = ['p', 's', 'a', 'b', 'm'].map(k => {
        const x = slotInfo(k);
        return `<button type="button" class="los${k === slot ? ' on' : ''}" data-slot="${k}">${x.img}<small>${x.label}</small><b>${x.name}</b><em>${x.sub}</em><span>${x.line}</span></button>`;
    }).join('');
    const title = { p: 'SELECT PRIMARY', s: 'SELECT SECONDARY', a: 'SELECT UTILITY 1', b: 'SELECT UTILITY 2', m: 'SELECT MELEE (KEY 3)' }[slot];
    $('loOptsT').textContent = title;
    $('loOpts').innerHTML = options(slot).map(o =>
        `<button type="button" class="loo${o.on ? ' on' : ''}" data-id="${o.id}">${o.img}<div><b>${o.name}</b><small>${o.sub}</small><span>${o.line}</span></div><i>${o.on ? 'EQUIPPED' : 'EQUIP'}</i></button>`).join('');
}

function pick(id) {
    const L = active();
    if (slot === 'a' || slot === 'b') L[slot] = id; else if (slot === 'm') L.m = 'knife'; else if (slot === 'p') L.p = +id; else L.s = +id;
    save(); render();
}

function build() {
    const st = document.createElement('style');
    st.textContent = `#ntLo{position:fixed;inset:0;z-index:99999;display:none;background:rgba(6,8,10,.96);color:#fff;font-family:Rajdhani,sans-serif;align-items:center;justify-content:center}
#ntLo.on{display:flex}#ntLo .box{width:min(820px,94vw);max-height:94vh;display:flex;flex-direction:column;gap:12px;padding:18px}
#ntLo h2{margin:0;font:600 44px Teko,sans-serif;letter-spacing:.2em;line-height:1}#ntLo h2 b{color:#ffd23a}
#ntLo button{background:#1d2227;color:#fff;border:1px solid #3a434b;font-family:Rajdhani,sans-serif;cursor:pointer;touch-action:manipulation;text-align:left}
#ntLo .tabs{display:flex;gap:6px}#ntLo .lot{flex:1;text-align:center;padding:9px 6px;font:600 18px Rajdhani,sans-serif;letter-spacing:.1em}
#ntLo .lot.on{background:#ffd23a;color:#000;border-color:#ffd23a}
#loSlots{display:grid;grid-template-columns:repeat(5,1fr);gap:8px}
#ntLo .los{display:flex;flex-direction:column;gap:2px;padding:12px;background:#12161a;border:1px solid #262d33;min-height:128px}
#ntLo .los.on{border-color:#ffd23a;box-shadow:inset 0 0 0 1px #ffd23a}
#ntLo .los small{color:#ffd23a;letter-spacing:.25em;font-weight:700;font-size:13px}#ntLo .los b{font:600 19px Teko,sans-serif;letter-spacing:.06em;line-height:1.1}
#ntLo .los em{font-style:normal;color:#98a4ad;font-size:14px;letter-spacing:.08em}#ntLo .los span{color:#c8d0d6;font-size:14px;margin-top:auto}
#ntLo .loi{display:block;background:center/contain no-repeat;height:96px;width:100%;margin-bottom:4px;text-decoration:none}
#ntLo .loo .loi{width:132px;height:66px;margin:0;flex:none}
#loOptsT{color:#ffd23a;font-weight:700;letter-spacing:.14em}
#loOpts{overflow-y:auto;display:flex;flex-direction:column;gap:6px;min-height:80px;-webkit-overflow-scrolling:touch;overscroll-behavior:contain}
#ntLo .loo{display:flex;align-items:center;gap:10px;padding:9px 12px;background:#12161a;border:1px solid #262d33}
#ntLo .loo>div{flex:1}#ntLo .loo b{display:block;font:600 22px Teko,sans-serif;letter-spacing:.06em}
#ntLo .loo small{color:#98a4ad;font-size:13px;letter-spacing:.08em;margin-right:10px}#ntLo .loo span{color:#c8d0d6;font-size:14px}
#ntLo .loo i{font-style:normal;color:#ffd23a;font-weight:700;letter-spacing:.1em;min-width:84px;text-align:right}
#ntLo .loo.on{border-color:#2c5a34;background:#14201a}#ntLo .loo.on i{color:#7dff8a}
#ntLo .loBack{padding:11px;text-align:center;font:600 18px Rajdhani,sans-serif;letter-spacing:.12em}
#loNote{color:#98a4ad;font-size:13px;letter-spacing:.06em}
#tNade{position:absolute;display:none}
#ntLo .loo{flex:none}
@media (max-width:700px),(max-height:520px){#ntLo .box{width:96vw;max-height:calc(100dvh - 12px);padding:max(8px,env(safe-area-inset-top)) 8px max(8px,env(safe-area-inset-bottom));gap:6px}
#ntLo h2{font-size:30px}#ntLo button{min-height:44px}#ntLo .lot{font-size:15px;padding:8px 2px}
#loSlots{gap:5px}#loNote{display:none}
#ntLo .loo{padding:6px 10px;gap:8px}#ntLo .loo b{font-size:20px}#ntLo .loo small{display:block;margin:0}#ntLo .loo i{min-width:64px;font-size:13px}
#ntLo .loo .loi{width:84px;height:44px}}
@media (max-width:700px) and (min-height:521px){#loSlots{grid-template-columns:1fr}
#ntLo .los{min-height:0;display:grid;grid-template-columns:112px 1fr;column-gap:10px;padding:6px 10px;align-items:center}
#ntLo .los .loi{grid-row:1/5;height:62px;margin:0}#ntLo .los b{font-size:22px}#ntLo .los span{margin-top:0;font-size:13px}}
@media (max-height:520px){#ntLo .box{gap:4px}#ntLo h2{font-size:22px}#ntLo button{min-height:38px}#ntLo .los{min-height:0;padding:6px 8px}#ntLo .los .loi{height:50px;margin-bottom:2px}#ntLo .los b{font-size:20px}#ntLo .los span{font-size:12px}#ntLo .loo .loi{width:76px;height:38px}}`;
    document.head.appendChild(st);

    const d = document.createElement('div'); d.id = 'ntLo';
    d.innerHTML = `<div class="box"><h2>LOAD<b>OUT</b></h2>
<div class="tabs"><button class="lot" data-l="0" type="button">LOADOUT 1</button><button class="lot" data-l="1" type="button">LOADOUT 2</button><button class="lot" data-l="2" type="button">LOADOUT 3</button></div>
<div id="loSlots"></div><div id="loOptsT"></div><div id="loOpts"></div>
<div id="loNote">The selected loadout is used when you press Deploy. Gun Game hands you its own weapons; your UTILITIES still apply.</div>
<button class="loBack" id="loClose" type="button">Back</button></div>`;
    document.body.appendChild(d);

    const close = () => d.classList.remove('on');
    d.addEventListener('click', e => {
        const b = e.target.closest('button'); if (!b) return;
        if (b.id === 'loClose') close();
        else if (b.dataset.l !== undefined) { S.sel = +b.dataset.l; save(); render(); }
        else if (b.dataset.slot) { slot = b.dataset.slot; render(); }
        else if (b.dataset.id !== undefined) pick(b.dataset.id);
    });
    addEventListener('keydown', e => { if (e.code === 'Escape' && d.classList.contains('on')) { close(); e.stopPropagation(); } }, true);

    const host = $('menuBtns');
    if (host) {
        const b = document.createElement('button');
        b.className = 'menuBtn'; b.type = 'button'; b.id = 'btnLoadout'; b.textContent = 'Loadout';
        b.addEventListener('click', () => { render(); d.classList.add('on'); setTimeout(() => makeIcons().then(() => d.classList.contains('on') && render()), 30); });
        const start = $('btnStart');
        host.insertBefore(b, start ? start.nextSibling : host.firstChild);
    }
    initNadeButton();
}

// ── mobile: throw button for the equipped ARM (touch had no grenade control) ──
function initNadeButton() {
    const root = $('touchUI'); if (!root) return;
    const b = document.createElement('button');
    b.className = 'tbtn'; b.id = 'tNade'; b.type = 'button';
    b.innerHTML = '<span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="14" r="7"/><path d="M9 7h6M12 7V3l3 1"/></svg></span><b id="tNadeLb" style="font-size:10px;letter-spacing:.06em">FRAG</b>';
    root.appendChild(b);
    b.addEventListener('pointerdown', e => {
        e.preventDefault(); e.stopPropagation();
        const g = _player && _player.ctx && _player.ctx.grenades;
        if (g) {
            const { a, b } = active();
            g.equip(a !== b && g.active && g.kind === a ? b : a);     // tap again to swap to utility 2
            if (navigator.vibrate) navigator.vibrate(12);
        }
    });
    const kb = document.createElement('button');
    kb.className = 'tbtn'; kb.id = 'tKnife'; kb.type = 'button'; kb.style.position = 'absolute'; kb.style.display = 'none';
    kb.innerHTML = '<span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20 15 9l4-5 1 1-5 4L4 20z"/><path d="M7 17l2 2"/></svg></span><b style="font-size:10px;letter-spacing:.06em">KNIFE</b>';
    root.appendChild(kb);
    kb.addEventListener('pointerdown', e => {
        e.preventDefault(); e.stopPropagation();
        const m = _player && _player.ctx && _player.ctx.melee;
        if (m) { m.equip(); if (navigator.vibrate) navigator.vibrate(12); }
    });
    // Sit beside the Swap button, whatever the current layout / size slider is.
    setInterval(() => {
        const sw = $('tSwap');
        if (!document.body.classList.contains('touch') || !sw || !_player) { b.style.display = 'none'; kb.style.display = 'none'; return; }
        const r = sw.getBoundingClientRect(), pr = root.getBoundingClientRect();
        const menuUp = $('menu') && $('menu').style.display !== 'none';
        if (!r.width || menuUp) { b.style.display = 'none'; kb.style.display = 'none'; return; }
        b.style.display = ''; b.style.right = b.style.bottom = 'auto';
        b.style.width = r.width + 'px'; b.style.height = r.height + 'px';
        const gap = Math.max(6, r.width * 0.18);
        const portrait = innerHeight > innerWidth;
        b.style.left = (portrait ? r.left - pr.left - r.width - gap : r.left - pr.left) + 'px';
        b.style.top = (portrait ? r.top - pr.top : r.top - pr.top - r.height - gap) + 'px';
        kb.style.display = ''; kb.style.right = kb.style.bottom = 'auto';
        kb.style.width = b.style.width; kb.style.height = b.style.height;
        kb.style.left = (portrait ? parseFloat(b.style.left) - r.width - gap : parseFloat(b.style.left)) + 'px';
        kb.style.top = (portrait ? parseFloat(b.style.top) : parseFloat(b.style.top) - r.height - gap) + 'px';
        const lb = $('tNadeLb'), L = active(), t = L.a === L.b ? (L.a === 'frag' ? 'FRAG' : 'FLASH') : 'UTIL';
        if (lb.textContent !== t) lb.textContent = t;
    }, 300);
}

if (document.body) build(); else addEventListener('DOMContentLoaded', build);
