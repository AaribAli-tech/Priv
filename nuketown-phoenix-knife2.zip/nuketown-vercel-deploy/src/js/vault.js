// ============================================================================
// vault.js — SECRET VAULT. Hidden hatch (on the map) + 4 clue signs -> keypad ->
// tunnel (locked door) -> boss arena -> vault door -> diamond chest -> 150k coins.
// The underground lives high in the sky (y=AY) behind solid walls, so no map code
// is touched. Self-contained: main.js constructs it, calls update(dt, live),
// reset(), reads .foes (extra shootable targets) and checks isVaultFoe in onHit.
// ============================================================================
import * as THREE from 'three';
import { SPAWN_B } from './map.js';
import { MAP_RECT, clamp, rand } from './utils.js';
import * as shop from './shop.js';

const AY = 300, REWARD = 150000, HOLD_T = 1.6;
const BOSS_HP = 2200, FAR = 1e6;
const OX = MAP_RECT.minX + 8, OZ = (MAP_RECT.minZ + MAP_RECT.maxZ) / 2;
const mat = (c, o = {}) => new THREE.MeshBasicMaterial({ color: c, ...o });
const tex = (w, h, f) => { const c = document.createElement('canvas'); c.width = w; c.height = h; f(c.getContext('2d'), w, h); return new THREE.CanvasTexture(c); };
const css = (el, s) => { el.style.cssText = s; document.body.appendChild(el); return el; };
const rad = '\u2622';

// ── tiny synth (own AudioContext, created on first key press) ───────────────
let AC = null, noiseSrc = null;
const ac = () => AC || (AC = new (window.AudioContext || window.webkitAudioContext)());
function tone(f, d = 0.15, type = 'square', v = 0.06, f2 = f) {
    try { const a = ac(), o = a.createOscillator(), g = a.createGain(), t = a.currentTime;
        o.type = type; o.frequency.setValueAtTime(f, t); o.frequency.linearRampToValueAtTime(f2, t + d);
        g.gain.setValueAtTime(v, t); g.gain.linearRampToValueAtTime(0, t + d);
        o.connect(g).connect(a.destination); o.start(t); o.stop(t + d); } catch (e) {}
}
const alarm = () => { for (let i = 0; i < 6; i++) setTimeout(() => tone(520, 0.2, 'sawtooth', 0.07, 900), i * 380); };
const rumble = (d = 2.5) => tone(55, d, 'sawtooth', 0.12, 30);
function staticOn(on) {
    try { if (noiseSrc) { noiseSrc.stop(); noiseSrc = null; } if (!on) return;
        const a = ac(), b = a.createBuffer(1, a.sampleRate * 2, a.sampleRate), d = b.getChannelData(0);
        for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (Math.random() < 0.02 ? 1 : 0.25);
        const s = a.createBufferSource(), g = a.createGain(), f = a.createBiquadFilter();
        s.buffer = b; s.loop = true; g.gain.value = 0.035; f.type = 'bandpass'; f.frequency.value = 1800;
        s.connect(f).connect(g).connect(a.destination); s.start(); noiseSrc = s; } catch (e) {}
}

// ── enemies: one blocky robot class for boss + minions ──────────────────────
function robot(s, body, glow) {
    const g = new THREE.Group(), m = mat(body), e = mat(glow);
    const add = (geo, mm, x, y, z) => { const o = new THREE.Mesh(geo, mm); o.position.set(x * s, y * s, z * s); g.add(o); return o; };
    add(new THREE.BoxGeometry(.28 * s, .8 * s, .3 * s), m, -.17, .4, 0); add(new THREE.BoxGeometry(.28 * s, .8 * s, .3 * s), m, .17, .4, 0);
    add(new THREE.BoxGeometry(.8 * s, .75 * s, .45 * s), m, 0, 1.15, 0);
    add(new THREE.BoxGeometry(.3 * s, .3 * s, .3 * s), m, 0, 1.75, 0);
    add(new THREE.BoxGeometry(.32 * s, .07 * s, .05 * s), e, 0, 1.77, .16);
    add(new THREE.BoxGeometry(.2 * s, .2 * s, .05 * s), e, 0, 1.2, .24);              // core
    add(new THREE.BoxGeometry(.2 * s, .65 * s, .2 * s), m, -.52, 1.15, 0);
    add(new THREE.BoxGeometry(.2 * s, .2 * s, .8 * s), m, .52, 1.2, .35);              // gun arm
    add(new THREE.BoxGeometry(.1 * s, .1 * s, .2 * s), e, .52, 1.2, .8);
    return g;
}
class Foe {
    constructor(boss, x, z, scene) {
        this.isVaultFoe = true; this.boss = boss; this.team = -1; this.name = boss ? 'OVERSEER' : 'SENTRY';
        this.alive = true; this.isCrouching = false; this.spawnProtect = 0;
        const s = boss ? 2.4 : 1.05;
        this.s = s; this.maxHealth = this.health = boss ? BOSS_HP : 70;
        this.position = new THREE.Vector3(x, AY, z);
        this.mesh = robot(s, boss ? 0x2a1214 : 0x303a40, boss ? 0xff2a1a : 0xffb020);
        scene.add(this.mesh); this.scene = scene;
        this.hitSpots = [[.6, .3, false], [1.15, .4, false], [1.75, .2, true]].map(([y, r, h]) => [y * s, r * s * 1.3, h]);
        this.fire = rand(1, 2); this.burst = 0; this.slam = 7; this.tele = 0; this.phase = 0; this.dyingT = 0;
    }
    takeDamage(a) {
        if (!this.alive) return false;
        this.health -= a;
        if (this.health <= 0) { this.health = 0; this.alive = false; return true; }
        return false;
    }
}

export class Vault {
    constructor(ctx) {
        this.ctx = ctx; this.foes = []; this.bolts = []; this.sfx = [];
        this.hold = false; this.pressed = false; this.kp = false; this.ent = '';
        this.G = new THREE.Group(); this.G.visible = false; ctx.scene.add(this.G);
        this._arena(); this._chest(); this._surface(); this._ui(); this._input();
        this.reset();
        // DEBUG (F12 console): __vault.tp() = go next to the secret bush, __vault.reveal() = skip the grenades
        window.__vault = { tp: () => { const p = this.ctx.player; p.position.set(this.hatchPos.x + 6, 0, this.hatchPos.z); return 'at bush'; },
            reveal: () => { if (this.sb && !this.revealed) this._reveal(); return 'revealed'; } };
    }

    // ── arena geometry ──────────────────────────────────────────────────────
    _box(x0, x1, y0, y1, z0, z1, c, solid = true, o = {}) {
        const m = new THREE.Mesh(new THREE.BoxGeometry(x1 - x0, y1 - y0, z1 - z0), mat(c, o));
        m.position.set(OX + (x0 + x1) / 2, AY + (y0 + y1) / 2, OZ + (z0 + z1) / 2); this.G.add(m);
        const b = solid ? this.ctx.cw.addAABB(OX + x0, AY + y0, OZ + z0, OX + x1, AY + y1, OZ + z1, 'solid') : null;
        return { m, b, y0: AY + y0, y1: AY + y1 };
    }
    _setSolid(d, on) { if (on) { d.b.minY = d.y0; d.b.maxY = d.y1; } else { d.b.minY = d.b.maxY = FAR; } }
    _arena() {
        const W = 0x1c2024, F = 0x15171a, C = 0x101215, T = 0x2b3036, bx = (...a) => this._box(...a);
        bx(-3, 32, -1, 0, -3, 3, F); bx(-3, 32, 4.2, 5.2, -3, 3, C);                       // tunnel floor/ceiling
        bx(-3, 30, 0, 4.2, -3.5, -2.5, W); bx(-3, 30, 0, 4.2, 2.5, 3.5, W); bx(-4, -3, 0, 4.2, -3, 3, W);
        bx(30, 68, -1, 0, -18, 18, F); bx(30, 68, 12, 13, -18, 18, C);                       // boss room
        bx(68, 93, -1, 0, -10, 10, 0x2a2616); bx(68, 93, 9, 10, -10, 10, C);                 // vault room
        bx(30, 31, 0, 12, -18.5, -2.5, W); bx(30, 31, 0, 12, 2.5, 18.5, W); bx(30, 31, 4.2, 12, -2.5, 2.5, W);
        bx(30, 68, 0, 12, -19, -18, W); bx(30, 68, 0, 12, 18, 19, W);
        bx(67, 69, 0, 12, -18.5, -4.5, W); bx(67, 69, 0, 12, 4.5, 18.5, W); bx(67, 69, 7.5, 12, -4.5, 4.5, W);
        bx(69, 93, 0, 9, -11, -10, 0x2e2a18); bx(69, 93, 0, 9, 10, 11, 0x2e2a18); bx(93, 94, 0, 9, -10, 10, 0x2e2a18);
        this.pillars = [];
        for (const [px, pz] of [[42, -8], [42, 8], [56, -8], [56, 8]]) { bx(px - 1.2, px + 1.2, 0, 12, pz - 1.2, pz + 1.2, T); this.pillars.push([OX + px, OZ + pz]); }
        // doors: tunnel door, boss-room door, two vault-door halves
        this.d1 = bx(15.5, 16.5, 0, 4.2, -2.5, 2.5, 0x3a4048);
        this.d2 = bx(30, 31, 0, 4.2, -2.5, 2.5, 0x3a4048);
        this.vL = bx(68, 69, 0, 7.5, -4.5, 0, 0x555b63); this.vR = bx(68, 69, 0, 7.5, 0, 4.5, 0x555b63);
        this.wheel = new THREE.Mesh(new THREE.TorusGeometry(1.6, .25, 6, 16), mat(0xb08a2a));
        this.wheel.rotation.y = Math.PI / 2; this.wheel.position.set(OX + 67.9, AY + 3.7, OZ); this.G.add(this.wheel);
        // lamps: emergency strips (flicker) + door status lights
        this.lamps = [];
        for (let x = 4; x < 30; x += 7) for (const z of [-2.2, 2.2]) this.lamps.push(this._box(x, x + 1.4, 3.9, 4.2, z - .15, z + .15, 0xff2010, false).m);
        for (const [x, z] of [[36, -17.5], [48, -17.5], [60, -17.5], [36, 17.5], [48, 17.5], [60, 17.5]]) this.lamps.push(this._box(x, x + 1.6, 11, 11.4, z - .3, z + .3, 0xff2010, false).m);
        this.lampD1 = this._box(15.2, 15.5, 3, 3.6, -.3, .3, 0xff2010, false).m;
        this.lampV = this._box(66.8, 67.2, 6.2, 6.8, -.4, .4, 0xff2010, false).m;
        this.ladder = this._box(-2.6, -2.2, 0, 3.8, -.5, .5, 0x6a5a30, false).m;
        this.ladderLamp = this._box(-2.7, -2.5, 3.9, 4.2, -.3, .3, 0x30ff60, false).m;
        this.pos = { exit: [OX - 1.5, OZ], d1: [OX + 14.5, OZ], chest: [OX + 84, OZ] };
    }
    _chest() {
        const g = this.chest = new THREE.Group(); g.position.set(OX + 84, AY, OZ); this.G.add(g);
        const ped = new THREE.Mesh(new THREE.BoxGeometry(2.6, .9, 2), mat(0x3a3220)); ped.position.y = .45; g.add(ped);
        const cy = mat(0x55e8ff, { transparent: true, opacity: .55 }), wh = mat(0xffffff);
        const body = new THREE.Mesh(new THREE.BoxGeometry(1.8, .9, 1.2), cy); body.position.y = 1.35; g.add(body);
        const edge = (geo, m, p) => { const l = new THREE.LineSegments(new THREE.EdgesGeometry(geo), m); l.position.copy(p); return l; };
        g.add(edge(body.geometry, new THREE.LineBasicMaterial({ color: 0xffffff }), body.position));
        const lid = this.lid = new THREE.Group(); lid.position.set(0, 1.8, -.6); g.add(lid);
        const lm = new THREE.Mesh(new THREE.BoxGeometry(1.84, .35, 1.24), cy); lm.position.set(0, .17, .6); lid.add(lm);
        lid.add(edge(lm.geometry, new THREE.LineBasicMaterial({ color: 0xffffff }), lm.position));
        for (let i = 0; i < 5; i++) {                                                          // crystal spikes
            const c = new THREE.Mesh(new THREE.ConeGeometry(.16 + Math.random() * .1, .6 + Math.random() * .6, 4), i % 2 ? wh : mat(0x9ff4ff));
            c.position.set((i - 2) * .32, .5 + .1 * (i % 2), .6 + (i % 3 - 1) * .2); c.rotation.z = (i - 2) * .12; lid.add(c);
        }
        const lock = this.lock = new THREE.Group(); lock.position.set(0, 1.62, .66); g.add(lock);
        lock.add(new THREE.Mesh(new THREE.BoxGeometry(.3, .26, .16), mat(0xe8b830)));
        const sh = new THREE.Mesh(new THREE.TorusGeometry(.12, .035, 6, 10, Math.PI), mat(0xe8b830)); sh.position.y = .17; lock.add(sh);
        const glowT = tex(64, 64, (c) => { const gr = c.createRadialGradient(32, 32, 0, 32, 32, 32); gr.addColorStop(0, '#fff'); gr.addColorStop(.35, '#6ff'); gr.addColorStop(1, '#0000'); c.fillStyle = gr; c.fillRect(0, 0, 64, 64); });
        this.glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowT, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, opacity: .6 }));
        this.glow.position.y = 1.6; this.glow.scale.setScalar(5); g.add(this.glow);
        this.cbeam = new THREE.Mesh(new THREE.CylinderGeometry(.5, 1.4, 8, 12, 1, true),
            mat(0x66f0ff, { transparent: true, opacity: .25, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide }));
        this.cbeam.position.y = 5; g.add(this.cbeam);
        this.motes = [];
        for (let i = 0; i < 36; i++) { const m = new THREE.Mesh(new THREE.OctahedronGeometry(.07), mat(i % 3 ? 0x9ff4ff : 0xffffff)); m.userData = { a: rand(0, 6.28), r: rand(.6, 1.8), y: rand(0, 5), v: rand(.3, .9) }; g.add(m); this.motes.push(m); }
    }
    // ── surface: hatch + clue signs ─────────────────────────────────────────
    _surface() {
        const S = this.S = new THREE.Group(); this.ctx.scene.add(S);
        this.hatch = new THREE.Group(); S.add(this.hatch);
        const ring = new THREE.Mesh(new THREE.CylinderGeometry(1.05, 1.05, .05, 18), mat(0x3a3a38)); ring.position.y = .025; this.hatch.add(ring);
        this.hole = new THREE.Mesh(new THREE.CircleGeometry(.85, 16), mat(0x000000)); this.hole.rotation.x = -Math.PI / 2; this.hole.position.y = .06; this.hole.visible = false; this.hatch.add(this.hole);
        this.hLid = new THREE.Group(); this.hatch.add(this.hLid);
        const lid = new THREE.Mesh(new THREE.CylinderGeometry(.9, .9, .08, 18), mat(0x4a4a46)); lid.position.y = .09; this.hLid.add(lid);
        const dec = new THREE.Mesh(new THREE.CircleGeometry(.6, 16), new THREE.MeshBasicMaterial({ transparent: true, opacity: .55, depthWrite: false, map: tex(128, 128, (c) => { c.fillStyle = '#b89a2a'; c.font = '110px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(rad, 64, 70); }) }));
        dec.rotation.x = -Math.PI / 2; dec.position.y = .135; this.hLid.add(dec);
        this.hLight = new THREE.Mesh(new THREE.BoxGeometry(.18, .12, .18), mat(0xff2010)); this.hLight.position.set(.95, .1, 0); this.hatch.add(this.hLight);
        this.signs = [];
        for (let i = 0; i < 4; i++) {
            const g = new THREE.Group(), post = new THREE.Mesh(new THREE.BoxGeometry(.07, 1.25, .07), mat(0x4a3a26)); post.position.y = .62; g.add(post);
            const board = new THREE.Mesh(new THREE.PlaneGeometry(.75, .75), new THREE.MeshBasicMaterial({ side: THREE.DoubleSide })); board.position.y = 1.4; g.add(board);
            g.userData.board = board; S.add(g); this.signs.push(g);
        }
    }
    _paint(i, digit) {
        const b = this.signs[i].userData.board;
        if (b.material.map) b.material.map.dispose();
        b.material.map = tex(128, 128, (c) => {
            c.fillStyle = '#2b2a1c'; c.fillRect(0, 0, 128, 128); c.strokeStyle = '#8a7424'; c.lineWidth = 5; c.strokeRect(4, 4, 120, 120);
            c.fillStyle = '#b89a2a'; c.textAlign = 'center'; c.font = '36px sans-serif'; c.fillText(rad + ' KEY ' + (i + 1), 64, 36);
            c.font = '700 74px Rajdhani, sans-serif'; c.fillText(String(digit), 64, 108);
        });
        b.material.needsUpdate = true;
    }

    // ── ui / input ──────────────────────────────────────────────────────────
    _ui() {
        const el = this.el = css(document.createElement('div'), 'position:fixed;left:50%;bottom:24%;transform:translateX(-50%);display:none;z-index:31;font:600 15px Rajdhani,sans-serif;letter-spacing:2px;color:#fff;text-align:center;text-shadow:0 1px 4px #000;touch-action:none;user-select:none;cursor:pointer');
        el.innerHTML = '<div class="t"></div><div style="width:190px;height:6px;margin:6px auto 0;background:#0008;border:1px solid #fff6"><i style="display:block;height:100%;width:0;background:#55e8ff"></i></div>';
        this.txt = el.querySelector('.t'); this.bar = el.querySelector('i');
        el.addEventListener('pointerdown', () => { this.hold = true; this.pressed = true; });
        for (const t of ['pointerup', 'pointerleave', 'pointercancel']) el.addEventListener(t, () => { this.hold = false; });
        this.dark = css(document.createElement('div'), 'position:fixed;inset:0;z-index:20;pointer-events:none;display:none;background:radial-gradient(ellipse at center,#0000 35%,#000d 100%)');
        this.fade = css(document.createElement('div'), 'position:fixed;inset:0;z-index:60;pointer-events:none;background:#000;opacity:0;transition:opacity .35s');
        this.flash = css(document.createElement('div'), 'position:fixed;inset:0;z-index:55;pointer-events:none;background:#f00;opacity:0;transition:opacity .25s');
        this.bossBar = css(document.createElement('div'), 'position:fixed;left:50%;top:9%;transform:translateX(-50%);width:min(520px,70vw);display:none;z-index:30;font:700 16px Teko,Rajdhani,sans-serif;letter-spacing:4px;color:#ff6a50;text-align:center;text-shadow:0 1px 4px #000');
        this.bossBar.innerHTML = 'OVERSEER<div style="height:12px;margin-top:3px;background:#0009;border:1px solid #fff6"><i style="display:block;height:100%;width:100%;background:linear-gradient(#ff4a30,#a01408)"></i></div>';
        this.bossFill = this.bossBar.querySelector('i');
        this.coin = css(document.createElement('div'), 'position:fixed;right:18px;top:16px;z-index:61;display:none;font:700 26px Teko,Rajdhani,sans-serif;color:#ffd24a;text-shadow:0 2px 6px #000');
        const k = this.kpEl = css(document.createElement('div'), 'position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:62;display:none;padding:18px 22px;background:#0b0e10ee;border:2px solid #55e8ff88;border-radius:6px;font:600 18px Rajdhani,sans-serif;color:#9ff4ff;text-align:center;letter-spacing:3px;user-select:none');
        k.innerHTML = `<div>${rad} VAULT ACCESS</div><div class="d" style="font-size:34px;margin:10px 0;letter-spacing:12px;color:#fff">----</div><div class="g" style="display:grid;grid-template-columns:repeat(3,56px);gap:6px;justify-content:center"></div><div style="font-size:12px;margin-top:8px;opacity:.7">TYPE CODE · ENTER · ESC</div>`;
        this.kpD = k.querySelector('.d');
        const g = k.querySelector('.g');
        for (const t of ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', 'OK']) {
            const b = document.createElement('button'); b.textContent = t;
            b.style.cssText = 'height:44px;font:700 20px Rajdhani,sans-serif;background:#1b2428;color:#9ff4ff;border:1px solid #55e8ff66;border-radius:4px;cursor:pointer';
            b.addEventListener('pointerdown', (e) => { e.stopPropagation(); this._key(t); }); g.appendChild(b);
        }
    }
    _input() {
        addEventListener('keydown', (e) => {
            if (this.kp) {                                                                       // keypad swallows keys
                const k = e.key; let used = true;
                if (/^[0-9]$/.test(k)) this._key(k); else if (k === 'Backspace') this._key('C'); else if (k === 'Enter') this._key('OK'); else if (k === 'Escape') this._kpShow(false); else used = false;
                if (used) { e.stopImmediatePropagation(); e.preventDefault(); }
                return;
            }
            if (e.code === 'KeyE' && !e.repeat) { this.hold = true; this.pressed = true; }
        }, true);
        addEventListener('keyup', (e) => { if (e.code === 'KeyE') this.hold = false; });
        addEventListener('blur', () => { this.hold = false; });
    }
    _kpShow(on) {
        this.kp = on; this.ent = ''; this._kpDraw(); this.kpEl.style.display = on ? 'block' : 'none';
        if (on && document.pointerLockElement) try { document.exitPointerLock(); } catch (e) {}
    }
    _kpDraw() { this.kpD.textContent = (this.ent + '----').slice(0, 4); }
    _key(k) {
        if (this.lock_t > 0) return;
        tone(900, .05, 'square', .04);
        if (k === 'C') this.ent = this.ent.slice(0, -1);
        else if (k === 'OK') { if (this.ent.length === 4) this._submit(); }
        else if (this.ent.length < 4) { this.ent += k; if (this.ent.length === 4) setTimeout(() => this.kp && this._submit(), 150); }
        this._kpDraw();
    }
    _submit() {
        if (this.ent === this.code) {
            this._kpShow(false); tone(660, .12, 'sine', .08); setTimeout(() => tone(990, .25, 'sine', .08), 130);
            this.st = 'open'; rumble(2); this.ctx.hud.banner('HATCH UNLOCKED', '#55e8ff', 'Something is down there');
        } else {
            this._kpShow(false); this.lock_t = 3; alarm();
            this.flash.style.opacity = '.45'; this.flashT = 2.4;
            this.ctx.hud.banner('ALARM — WRONG CODE', '#ff3b2a', 'Keypad locked');
        }
    }

    // ── lifecycle ───────────────────────────────────────────────────────────
    reset() {
        const was = this.under; this.under = false;
        for (const f of this.foes) this.ctx.scene.remove(f.mesh), this.G.remove(f.mesh);
        for (const b of this.bolts) this.G.remove(b.m);
        this.foes = []; this.bolts = []; this.boss = null;
        for (const s of this.sfx) this.G.remove(s.m); this.sfx = [];
        this.st = 'locked'; this.fight = 'idle'; this.vopen = 0; this.chestT = 0; this.opened = false; this.prog = 0;
        this.lock_t = 0; this.flashT = 0; this.kp && this._kpShow(false);
        this.code = String(Math.floor(rand(1000, 10000)));
        this.signs.forEach((s, i) => { s.visible = false; this._paint(i, this.code[i]); });
        this._bushes(); this.armT = 0; this.pend = 0; this.revealed = false; this.hatch.visible = false;
        this.hLid.position.set(0, 0, 0); this.hole.visible = false; this.hLight.material.color.setHex(0xff2010);
        this._setSolid(this.d1, true); this._setSolid(this.d2, false); this._doorVis(); this._vaultVis(0);
        this.lid.rotation.x = 0; this.lock.visible = true; this.lock.position.set(0, 1.62, .66); this.lock.rotation.set(0, 0, 0);
        this.glow.material.opacity = .6; this.cbeam.material.opacity = .25;
        this.lampD1.material.color.setHex(0xff2010); this.lampV.material.color.setHex(0xff2010);
        this.G.visible = false; this.dark.style.display = 'none'; this.bossBar.style.display = 'none'; this.el.style.display = 'none';
        if (was) staticOn(false);
    }
    // ── secret trigger: frag blast, then flashbang, at the hidden bush ───────
    _bushes() {
        if (this.sb && this.sb.mesh) { this.sb.mesh.visible = true; if (this.sb.box) { this.sb.box.minY = this.sb.y0; this.sb.box.maxY = this.sb.y1; } }
        const found = []; this.ctx.scene.updateMatrixWorld(true);
        this.ctx.scene.traverse(o => {
            const g = o.isMesh && o.geometry;
            if (g && g.type === 'IcosahedronGeometry' && g.parameters.radius < 1 && o.getWorldPosition(new THREE.Vector3()).y < 1.5) found.push(o);
        });
        const ref = SPAWN_B[2] || SPAWN_B[0], pw = (o) => o.getWorldPosition(new THREE.Vector3());
        found.sort((a, b) => Math.hypot(pw(a).x - ref.x, pw(a).z - ref.z) - Math.hypot(pw(b).x - ref.x, pw(b).z - ref.z));
        const two = found.slice(0, 2).sort((a, b) => pw(a).z - pw(b).z), m = two[0];       // secret = lower-z of the two nearest spawn
        if (!m) { this.sb = null; this.hatchPos = { x: ref.x, z: ref.z }; return; }
        const p = pw(m); let box = null, bd = 3;
        for (const b of this.ctx.cw.boxes) if (b.tag === 'bush') { const d = Math.hypot((b.minX + b.maxX) / 2 - p.x, (b.minZ + b.maxZ) / 2 - p.z); if (d < bd) { bd = d; box = b; } }
        this.sb = { mesh: m, box, y0: box && box.minY, y1: box && box.maxY, x: p.x, z: p.z };
        this.hatchPos = { x: p.x, z: p.z }; this.hatch.position.set(p.x, 0, p.z);
    }
    onBoom(kind, pos) {
        if (!this.sb || this.revealed || this.under) return;
        const d = Math.hypot(pos.x - this.sb.x, pos.z - this.sb.z);
        if (kind === 'frag' && d < 4.5) { this.armT = 4; }
        else if (kind === 'flash' && d < 5 && this.armT > 0) { this.pend = 1; this.pT = 0; }
    }
    _reveal() {
        this.revealed = true; this.pend = 0; this.sb.mesh.visible = false;
        if (this.sb.box) this.sb.box.minY = this.sb.box.maxY = FAR;
        this.hatch.visible = true; this.hLid.position.x = 0; this.st = 'open';
        this.ctx.effects.explosion(new THREE.Vector3(this.sb.x, .4, this.sb.z), .5, 0xd8c9a0);
        rumble(2); this.ctx.hud.banner('SECRET FOUND', '#55e8ff', 'A hatch was hidden under the bush');
    }
    _doorVis() { this.d1.m.visible = this.d1.b.maxY !== FAR; this.d2.m.visible = this.d2.b.maxY !== FAR; }
    _vaultVis(k) {                                                                            // 0 closed .. 1 open
        this.vL.m.position.z = OZ - 2.25 - k * 4.4; this.vR.m.position.z = OZ + 2.25 + k * 4.4;
        const on = k < 1; this._setSolid(this.vL, on); this._setSolid(this.vR, on);
    }
    _tp(x, y, z, yaw) {
        const p = this.ctx.player;
        this.fade.style.opacity = '1';
        setTimeout(() => { p.position.set(x, y, z); p.velocity.set(0, 0, 0); p.yaw = yaw; p.pitch = 0; this.fade.style.opacity = '0'; }, 380);
    }
    _enter() {
        this.under = true; this.G.visible = true; this.dark.style.display = 'block'; staticOn(true);
        this._tp(OX + 1.5, AY, OZ, -Math.PI / 2);
        this.ctx.hud.banner('RESTRICTED AREA', '#ff4a30', 'Emergency power only');
    }
    _leave() {
        this._wipeFight(); this.under = false; this.G.visible = false; this.dark.style.display = 'none'; staticOn(false);
        this._tp(this.hatchPos.x + 2, 0, this.hatchPos.z, -Math.PI / 2);
    }
    _wipeFight() {
        for (const f of this.foes) this.G.remove(f.mesh); this.foes = []; this.boss = null;
        for (const b of this.bolts) this.G.remove(b.m); this.bolts = [];
        for (const s of this.sfx) this.G.remove(s.m); this.sfx = [];
        this.bossBar.style.display = 'none';
        if (this.fight === 'boss') { this.fight = 'idle'; this._setSolid(this.d2, false); this._doorVis(); }
    }

    // ── tick ────────────────────────────────────────────────────────────────
    update(dt, live) {
        const t = performance.now() / 1000, P = this.ctx.player;
        if (this.flashT > 0 && (this.flashT -= dt) <= 0) this.flash.style.opacity = '0';
        if (this.lock_t > 0) this.lock_t -= dt;
        if (!live || !P) { this.pressed = false; return; }
        if (this.under && (!P.alive || P.position.y < AY - 30)) { this._wipeFight(); this.under = false; this.G.visible = false; this.dark.style.display = 'none'; staticOn(false); }
        if (!this.under) {
            if (this.armT > 0) this.armT -= dt;
            if (this.pend) { this.pT += dt; const g = this.ctx.grenades; if (this.pT > 1 && !(g && g.blind > 0)) this._reveal(); }
            if (!this.revealed) { this.pressed = false; this.el.style.display = 'none'; return; }
            if (this.hole.visible = this.st === 'open') { this.hLid.position.x = Math.min(1.3, this.hLid.position.x + dt * .8); this.hLight.material.color.setHex(0x30ff60); }
            this._interact(dt, P); this.pressed = false; return;
        }
        const k = .75 + .25 * Math.sin(t * 9 + 1) * Math.sin(t * 3.3) + (Math.random() < .03 ? -.5 : 0);
        for (const l of this.lamps) l.material.color.setRGB(Math.max(.15, k), .06 * k, .04 * k);
        this.wheel.rotation.x += dt * (this.vopen > 0 && this.vopen < 1 ? 1.5 : 0.05);
        this._fight(dt, P); this._vault(dt, P, t); this._bolts(dt, P); this._sfx(dt);
        this._interact(dt, P); this.pressed = false;
    }

    // ── interactions (hold-E or tap-E prompts) ──────────────────────────────
    _interact(dt, P) {
        const px = P.position.x, pz = P.position.z, list = [];
        if (!this.under) {
            const h = this.hatchPos;
            if (this.st === 'open' && this.revealed) list.push({ x: h.x, z: h.z, r: 2.4, txt: 'E — DESCEND', go: () => this._enter() });
        } else {
            list.push({ x: this.pos.exit[0], z: this.pos.exit[1], r: 2.6, txt: 'E — CLIMB OUT', go: () => this._leave() });
            if (this.d1.b.maxY !== FAR) list.push({ x: this.pos.d1[0], z: this.pos.d1[1], r: 3, hold: HOLD_T, txt: 'HOLD E — HACK LOCK', go: () => this._unlockD1() });
            if (this.vopen >= 1 && !this.opened) list.push({ x: this.pos.chest[0], z: this.pos.chest[1], r: 3, hold: HOLD_T, txt: 'HOLD E — OPEN DIAMOND CHEST', go: () => this._openChest() });
        }
        let it = null, best = 1e9;
        for (const i of list) { const d = Math.hypot(px - i.x, pz - i.z); if (d < i.r && d < best) { it = i; best = d; } }
        if (!it || !P.alive || this.kp) { this.el.style.display = 'none'; this.prog = 0; return; }
        this.el.style.display = 'block'; this.txt.textContent = it.txt;
        if (it.hold) {
            this.prog = this.hold ? this.prog + dt : 0; this.bar.style.width = clamp(this.prog / it.hold, 0, 1) * 100 + '%';
            if (this.prog >= it.hold) { this.prog = 0; it.go(); }
        } else { this.bar.style.width = '0'; if (this.pressed) it.go(); }
    }
    _unlockD1() { this._setSolid(this.d1, false); this._doorVis(); this.lampD1.material.color.setHex(0x30ff60); tone(500, .1, 'sine', .08); tone(800, .3, 'sine', .08); rumble(1.2); this.ctx.hud.banner('DOOR UNLOCKED', '#30ff60', ''); }

    // ── boss fight ──────────────────────────────────────────────────────────
    _fight(dt, P) {
        const lx = P.position.x - OX;
        if (this.fight === 'idle' && lx > 36 && P.alive) {                                       // player is in the room: seal + spawn
            this.fight = 'boss'; this._setSolid(this.d2, true); this._doorVis(); rumble(1.5);
            const b = this.boss = new Foe(true, OX + 60, OZ, this.G); this.foes.push(b);
            this.bossBar.style.display = 'block'; this.ctx.hud.banner('BOSS — OVERSEER', '#ff4a30', 'Kill it to open the vault');
            tone(90, 1.2, 'sawtooth', .12, 60);
        }
        if (this.fight !== 'boss') return;
        const b = this.boss, ex = P.position.x, ez = P.position.z;
        for (const f of this.foes.slice()) {
            if (!f.alive) { this._foeDie(f); continue; }
            const dx = ex - f.position.x, dz = ez - f.position.z, d = Math.hypot(dx, dz) || 1, want = f.boss ? 15 : 9;
            f.mesh.rotation.y = Math.atan2(dx, dz);
            const sp = (f.boss ? 2.2 : 3.4) * dt, dir = d > want + 2 ? 1 : d < want - 3 ? -1 : 0, st = Math.sin(performance.now() / 900 + f.s * 7) * .8 * dt;
            f.position.x += (dx / d * dir + -dz / d * st / (sp || 1)) * sp; f.position.z += (dz / d * dir + dx / d * st / (sp || 1)) * sp;
            f.position.x = clamp(f.position.x, OX + 33, OX + 65.5); f.position.z = clamp(f.position.z, OZ - 16.5, OZ + 16.5);
            for (const [px, pz] of this.pillars) {
                const ox = f.position.x - px, oz = f.position.z - pz, lim = 1.2 + .7 * f.s;
                if (Math.abs(ox) < lim && Math.abs(oz) < lim) { if (Math.abs(ox) > Math.abs(oz)) f.position.x = px + Math.sign(ox || 1) * lim; else f.position.z = pz + Math.sign(oz || 1) * lim; }
            }
            f.mesh.position.copy(f.position);
            if (!P.alive) continue;
            if ((f.fire -= dt) <= 0) {
                if (f.boss) { f.burst = 3; f.fire = 1.5; } else { f.burst = 1; f.fire = rand(1.4, 2.4); }
            }
            if (f.burst > 0 && (f.bt = (f.bt || 0) - dt) <= 0) { f.burst--; f.bt = .13; this._shoot(f, P); }
        }
        if (b && b.alive) {
            this.bossFill.style.width = b.health / b.maxHealth * 100 + '%';
            const pct = b.health / b.maxHealth;
            if (b.phase === 0 && pct < .7 || b.phase === 1 && pct < .35) { b.phase++; this._minions(3); }
            if (b.tele > 0) {                                                                       // slam telegraph -> shockwave
                b.tele -= dt; const k = 1 - b.tele / 1.2; this.ring.scale.setScalar(Math.max(.1, k * 13)); this.ring.material.opacity = .25 + k * .5;
                if (b.tele <= 0) {
                    this.G.remove(this.ring); this.ctx.effects.explosion(new THREE.Vector3(b.position.x, AY + .3, b.position.z), 1, 0xff7040);
                    if (this.ctx.shake) this.ctx.shake(.8); tone(70, .6, 'sawtooth', .14, 40);
                    if (Math.hypot(ex - b.position.x, ez - b.position.z) < 13 && P.position.y < AY + 1) P.takeDamage(28, b.name, b.position);
                }
            } else if ((b.slam -= dt) <= 0) {
                b.slam = 8; b.tele = 1.2; this.ring = new THREE.Mesh(new THREE.RingGeometry(.92, 1, 40), mat(0xff3a20, { transparent: true, opacity: .3, side: THREE.DoubleSide, depthWrite: false }));
                this.ring.rotation.x = -Math.PI / 2; this.ring.position.set(b.position.x, AY + .06, b.position.z); this.G.add(this.ring);
                this.ctx.hud.banner('SHOCKWAVE — JUMP!', '#ff6a30', '');
            }
        }
    }
    _minions(n) {
        this.ctx.hud.banner('REINFORCEMENTS', '#ffb020', 'Sentries deployed');
        for (let i = 0; i < n && this.foes.length < 6; i++) { const f = new Foe(false, OX + rand(34, 64), OZ + rand(-14, 14), this.G); f.mesh.position.copy(f.position); this.foes.push(f); }
    }
    _shoot(f, P) {
        const o = new THREE.Vector3(f.position.x, AY + 1.3 * f.s, f.position.z), tg = new THREE.Vector3(P.position.x, P.position.y + 1.0, P.position.z);
        const dir = tg.sub(o).normalize(); dir.x += rand(-.03, .03); dir.y += rand(-.02, .02); dir.z += rand(-.03, .03); dir.normalize();
        const m = new THREE.Mesh(new THREE.BoxGeometry(.14, .14, .5), mat(f.boss ? 0xff3a20 : 0xffc030)); m.position.copy(o); m.lookAt(o.clone().add(dir)); this.G.add(m);
        this.bolts.push({ m, v: dir.multiplyScalar(f.boss ? 24 : 18), life: 4, dmg: f.boss ? 11 : 6, from: f });
        tone(f.boss ? 180 : 320, .1, 'sawtooth', .03, 90);
    }
    _bolts(dt, P) {
        for (let i = this.bolts.length - 1; i >= 0; i--) {
            const b = this.bolts[i]; b.m.position.addScaledVector(b.v, dt); b.life -= dt;
            const p = b.m.position; let dead = b.life <= 0 || p.y < AY || p.y > AY + 12;
            for (const [px, pz] of this.pillars) if (Math.abs(p.x - px) < 1.2 && Math.abs(p.z - pz) < 1.2) dead = true;
            if (P.alive && Math.hypot(P.position.x - p.x, P.position.z - p.z) < .6 && p.y > P.position.y && p.y < P.position.y + 1.9) { P.takeDamage(b.dmg, b.from.name, b.from.position); dead = true; }
            if (dead) { this.G.remove(b.m); this.bolts.splice(i, 1); }
        }
    }
    _foeDie(f) {
        this.foes.splice(this.foes.indexOf(f), 1);
        this.ctx.effects.explosion(new THREE.Vector3(f.position.x, AY + 1.5 * f.s, f.position.z), f.boss ? 1.4 : .5, 0xffa040);
        this.sfx.push({ m: f.mesh, t: 0, k: f.boss ? 3 : .6 });
        if (!f.boss) return;
        this.fight = 'won'; this.bossBar.style.display = 'none'; this.boss = null;
        for (const o of this.foes) { o.alive = false; this.ctx.effects.explosion(o.position.clone().setY(AY + 1), .5, 0xffa040); this.sfx.push({ m: o.mesh, t: 0, k: .6 }); }
        this.foes = []; for (const b of this.bolts) this.G.remove(b.m); this.bolts = [];
        if (this.ctx.shake) this.ctx.shake(1); tone(110, 1.5, 'sawtooth', .12, 40);
        this.ctx.hud.banner('BOSS DEFEATED', '#55e8ff', ''); this.vopen = .0001; this.vT = 2.5;
        this._setSolid(this.d2, false); this._doorVis();
    }
    _sfx(dt) {                                                                                  // dying robots sink away
        for (let i = this.sfx.length - 1; i >= 0; i--) {
            const s = this.sfx[i]; s.t += dt; s.m.position.y -= dt * s.k * .4; s.m.rotation.z += dt * .6;
            if (s.t > 2.5) { this.G.remove(s.m); this.sfx.splice(i, 1); }
        }
    }

    // ── vault door + chest ──────────────────────────────────────────────────
    _vault(dt, P, t) {
        if (this.vopen > 0 && this.vopen < 1) {
            if (this.vT > 0) { if ((this.vT -= dt) <= 0) { this.ctx.hud.banner('ACCESS GRANTED', '#30ff60', 'Vault door opening'); rumble(3.5); this.lampV.material.color.setHex(0x30ff60); } }
            else { this.vopen = Math.min(1, this.vopen + dt / 3.5); this._vaultVis(this.vopen); }
        }
        const open = this.vopen >= 1;
        for (const m of this.motes) {
            const u = m.userData; u.y += dt * u.v * (this.opened ? 3 : 1); if (u.y > 5) u.y = 0; u.a += dt * (this.opened ? 3 : .8);
            m.position.set(Math.cos(u.a) * u.r, 1.2 + u.y, Math.sin(u.a) * u.r); m.rotation.y += dt * 3; m.visible = open;
        }
        this.glow.scale.setScalar(5 + Math.sin(t * 3) * .5 + (this.opened ? 3 : 0));
        this.cbeam.material.opacity = (open ? .22 : 0) + Math.sin(t * 4) * .05 + (this.opened ? .2 : 0);
        this.glow.visible = open;
        if (this.opened) {
            this.chestT += dt;
            this.lid.rotation.x = -Math.min(1.9, this.chestT * 3);
            if (this.chestT < 2) { this.lock.position.y -= dt * 4 * this.chestT; this.lock.rotation.z += dt * 8; } else this.lock.visible = false;
        }
    }
    _openChest() {
        this.opened = true; this.chestT = 0; this.st = 'done';
        const c = new THREE.Vector3(OX + 84, AY + 1.8, OZ);
        this.ctx.effects.explosion(c, 1.2, 0x66f0ff); this.ctx.effects.explosion(c.clone().setY(AY + 3), .8, 0xffffff);
        if (this.ctx.shake) this.ctx.shake(.5);
        tone(700, .3, 'sine', .08, 1400); setTimeout(() => tone(1100, .5, 'sine', .08, 1800), 200);
        setTimeout(() => this._reward(), 900);
    }
    _reward() {
        this.ctx.hud.banner('SECRET COMPLETED', '#ffd24a', '+' + REWARD.toLocaleString() + ' COINS');
        shop.addCoins(REWARD);
        const c = this.coin; c.style.display = 'block'; c.textContent = '\uD83E\uDE99 +0';
        const n = 36, t0 = performance.now(), tx = innerWidth - 40, ty = 34, coins = [];
        for (let i = 0; i < n; i++) {
            const d = css(document.createElement('div'), 'position:fixed;z-index:61;font-size:28px;pointer-events:none;left:0;top:0'); d.textContent = '\uD83E\uDE99';
            coins.push({ d, x: innerWidth / 2 + rand(-60, 60), y: innerHeight / 2 + rand(-40, 40), delay: i * 45, ox: rand(-120, 120), oy: rand(-120, 60) });
        }
        const step = () => {
            const e = performance.now() - t0; let done = 0;
            for (const k of coins) {
                const a = clamp((e - k.delay) / 1100, 0, 1), q = a * a * (3 - 2 * a);
                const x = k.x + k.ox * Math.sin(a * Math.PI) + (tx - k.x) * q, y = k.y + k.oy * Math.sin(a * Math.PI) + (ty - k.y) * q;
                k.d.style.transform = `translate(${x}px,${y}px) scale(${1 - a * .4})`; k.d.style.opacity = e < k.delay ? 0 : 1;
                if (a >= 1) { done++; k.d.style.display = 'none'; }
            }
            c.textContent = '\uD83E\uDE99 +' + Math.floor(REWARD * done / n).toLocaleString();
            if (done < n) requestAnimationFrame(step);
            else { c.textContent = '\uD83E\uDE99 +' + REWARD.toLocaleString(); coins.forEach(k => k.d.remove()); setTimeout(() => { c.style.display = 'none'; }, 3500); }
        };
        requestAnimationFrame(step);
    }
}
