// ============================================================================
// viewmodel.js — first-person weapon rendering + animation
//
// The viewmodel lives in its own scene with its own camera and is drawn AFTER
// the world with a cleared depth buffer, so the gun and hands can never clip
// through walls — the classic FPS setup.
// ============================================================================
import * as THREE from 'three';
import * as M from './materials.js';
import { createViewModel, WEAPON_DEFS } from './weapons.js';
import { mergeRig } from './optimize.js';
import { applyPhotoreal } from './vmassets.js';

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
// How long the gun spends out of view during a swap, in seconds. The model is
// exchanged at the bottom of the dip. It used to be 0.22 s down and 0.22 s up,
// which on top of the build cost of the new model read as "the game stops, then
// the gun changes" — the dip is now short enough that the swap itself is what you
// see, and the model is already built and already drawn once (see prebuild()).
const SWAP_LOWER = 0.14;
const damp = (cur, tgt, lambda, dt) => cur + (tgt - cur) * (1 - Math.exp(-lambda * dt));

/**
 * Photoreal GLB weapons.
 *
 * The generated meshes look good in isolation but fail as gameplay weapons:
 * the auto-orientation guessed the muzzle end wrong on the MP5, SPAS and R700
 * (measured: their sight anchors landed BEHIND the receiver, i.e. the gun was
 * held backwards), and none of them carry a usable sight picture — no reticle,
 * no aperture, no scope glass — so aiming down them shows nothing to aim with.
 * They also cost ~21k triangles in the viewmodel against ~3k procedural.
 *
 * The procedural weapons are correct by construction: muzzle down -Z always, a
 * real holographic reticle on the rifle, an open aperture on the SMG, a scope
 * with an overlay on the sniper, ghost rings on the shotgun, and moving
 * magazines and charging handles during reloads.
 *
 * The GLB path is kept intact behind this flag. To use it, the per-weapon
 * orientation needs pinning explicitly rather than inferred, and each model
 * needs a reticle added.
 */
const USE_PHOTOREAL_WEAPONS = true;

export class ViewModel {
    constructor(team = 0) {
        this.scene = new THREE.Scene();
        this.camera = new THREE.PerspectiveCamera(58, 1, 0.004, 6);
        this.scene.add(this.camera);

        // Dedicated three-point lighting. Kept deliberately low: the weapon
        // materials are metallic and also pick up the sky environment, so a
        // bright key blows the whole gun out to white.
        const key = new THREE.DirectionalLight(0xfff2dd, 1.9);
        key.position.set(-0.75, 1.0, 0.55);
        const fill = new THREE.DirectionalLight(0x9fc2e8, 0.45);
        fill.position.set(1.0, -0.15, 0.6);
        // Cool rim separates the weapon from the warm desert behind it, and
        // keeps the top rail reading as metal rather than wood.
        const rim = new THREE.DirectionalLight(0xcfdcea, 0.85);
        rim.position.set(0.55, 0.45, -1.0);
        // low bounce so the underside of the receiver does not go solid black
        const bounce = new THREE.DirectionalLight(0xb9a892, 0.30);
        bounce.position.set(-0.3, -1.0, 0.2);
        this.scene.add(key, fill, rim, bounce, new THREE.AmbientLight(0xa8bccd, 0.22));
        this.scene.environmentIntensity = 0.45;

        this.holder = new THREE.Group();
        this.scene.add(this.holder);
        // Indices waiting to be built, drained a little per frame from the main
        // loop. Empty until queueAll() is called (the constructor's own weapon is
        // built directly, because it has to exist before the first frame).
        this._queue = [];
        this._warmRT = null;

        // Viewmodels are built on first use. Eagerly constructing all fifteen
        // cost 2.7 s of startup, and in Gun Game you only ever hold one at a
        // time — most of that work was for weapons the player never sees.
        this.team = team;
        this.models = new Array(WEAPON_DEFS.length).fill(null);

        this.current = 0;
        this._ensure(0).group.visible = true;

        // animation state
        this.ads = 0;              // 0..1 aim blend
        this.sprint = 0;           // 0..1 sprint pose blend
        this.bobT = 0;
        this.swayX = 0; this.swayY = 0;
        this.swayVX = 0; this.swayVY = 0;
        this.recoilPos = new THREE.Vector3();
        this.recoilRot = new THREE.Vector3();
        this.recoilVelPos = new THREE.Vector3();
        this.recoilVelRot = new THREE.Vector3();
        this.breath = 0;
        this.landDip = 0;
        this.switchT = 0;          // >0 while swapping weapons
        this.pendingSwitch = -1;
        this.reload = null;        // {t, dur, type}
        this.flashT = 0;
        this.jumpOffset = 0;

        this._pos = new THREE.Vector3();
        this._rot = new THREE.Euler();
        this._v = new THREE.Vector3();
    }

    /** Build a viewmodel the first time it is asked for. */
    _ensure(i) {
        let vm = this.models[i];
        if (!vm) vm = this._build(i);
        return vm;
    }

    _build(i) {
        const vm = createViewModel(i, this.team);
        const swapped = USE_PHOTOREAL_WEAPONS && applyPhotoreal(vm);
        if (!swapped) mergeRig(vm.group);
        vm.group.visible = false;
        this.holder.add(vm.group);
        this.models[i] = vm;
        if (this._skin) this._tint(vm.group);
        const q = this._queue.indexOf(i);
        if (q >= 0) this._queue.splice(q, 1);      // built — nothing left to warm
        return vm;
    }

    /**
     * Put every weapon that has not been built yet in the queue, most likely to be
     * held first. Called when a match starts.
     */
    queueAll() {
        this._queue = [];
        for (let i = 0; i < this.models.length; i++) if (!this.models[i]) this._queue.push(i);
        // The current gun and the one a forward scroll would land on come first:
        // those are the two that get pressed within a second of spawning.
        const cur = this.current;
        this._queue.sort((a, b) => (a === cur ? -1 : b === cur ? 1 : 0)
            || (a === (cur + 1) % this.models.length ? -1 : b === (cur + 1) % this.models.length ? 1 : 0)
            || a - b);
        return this._queue.length;
    }

    /**
     * Queue exactly these weapons and forget the rest. A mode where the player can
     * only ever hold four of the fifteen should not spend its spare frames building
     * the other eleven, which is pure cost and zero benefit.
     */
    queueOnly(list) {
        if (!Array.isArray(list) || !list.length) return this.queueAll();
        const n = this.models.length;
        const keep = list.filter(i => Number.isInteger(i) && i >= 0 && i < n);
        if (!keep.length) return this.queueAll();
        const cur = this.current;
        this._queue = keep.filter(i => !this.models[i])
            .sort((a, b) => (a === cur ? -1 : b === cur ? 1 : 0) || a - b);
        return this._queue.length;
    }

    /**
     * Build (and, with a renderer, draw once) whatever is queued, for as long as the
     * frame can spare.
     *
     * Building a viewmodel is 3-17 ms of geometry and merging; drawing it for the
     * first time is more again, because that is where the shader program is
     * compiled and its buffers and textures are uploaded. Doing either of those on
     * the frame a key was pressed is exactly the stall this file exists to avoid:
     * the gun does not appear until the work is finished, so the whole thing reads
     * as the game pausing. So it happens here instead, one weapon per call, in
     * frames that were already cheap, and by the time a switch is requested the
     * model is made and already warm.
     *
     * `ms` is a wall-clock budget, not a frame fraction: the loop only calls this
     * when it knows the frame has room.
     */
    prebuild(renderer, ms = 6) {
        if (!this._queue.length) return 0;
        const t0 = performance.now();
        let built = 0;
        while (this._queue.length) {
            const i = this._queue[0];
            if (built && performance.now() - t0 > ms) break;
            this._queue.shift();
            if (this.models[i]) continue;
            this._build(i);
            built++;
        }
        if (built && renderer) this._warm(renderer);
        return built;
    }

    /** Show every built weapon once, to a 4x4 target, so their first real draw is
     *  not the frame that pays for compiling and uploading them. */
    _warm(renderer) {
        if (!renderer || typeof renderer.render !== 'function') return;
        if (!this._warmRT) this._warmRT = new THREE.WebGLRenderTarget(4, 4, { depthBuffer: true });
        const shown = [];
        for (let i = 0; i < this.models.length; i++) {
            const m = this.models[i];
            if (m && !m.group.visible) { m.group.visible = true; shown.push(m); }
        }
        const target = renderer.getRenderTarget(), autoClear = renderer.autoClear;
        try {
            renderer.setRenderTarget(this._warmRT);
            renderer.autoClear = true;
            renderer.render(this.scene, this.camera);
        } catch (e) {
            // A lost or half-built context is not worth dying over: the real pass
            // draws the same scene a frame later and will show any genuine problem.
        }
        renderer.setRenderTarget(target);
        renderer.autoClear = autoClear;
        for (const m of shown) m.group.visible = false;
    }

    /** Shop weapon color: tints gun metal/polymer on cloned materials, leaves arms alone. */
    setSkin(skin) { this._skin = skin || null; for (const m of this.models) if (m) this._tint(m.group); }
    _tint(group) {
        const s = this._skin, cache = new Map();
        const vm = this.models.find((m) => m && m.group === group), pr = vm && vm.parts, skip = new Set();
        if (pr) for (const k of ['handR', 'handL', 'muzzle']) if (pr[k]) pr[k].traverse((o) => skip.add(o));
        group.traverse((o) => {
            if (!o.isMesh || !o.material || skip.has(o)) return;
            if (!o.userData._om) o.userData._om = o.material;
            const om = o.userData._om, arr = Array.isArray(om) ? om : [om];
            const out = arr.map((m) => {
                if (!s || !m.color || m.transparent || m.depthTest === false) return m;   // keep glass, dots, flash
                if (!cache.has(m)) {
                    const c = m.clone(); c.color.setHex(s.hex); c.map = null;             // flat colour over the whole gun
                    if (s.glow && c.emissive) { c.emissive.setHex(s.hex); c.emissiveIntensity = 0.35; }
                    c.needsUpdate = true; cache.set(m, c);
                }
                return cache.get(m);
            });
            o.material = Array.isArray(om) ? out : out[0];
        });
    }
    get parts() { return this._ensure(this.current).parts; }
    get def() { return WEAPON_DEFS[this.current]; }

    setEnvironment(env) { this.scene.environment = env; }

    // ── events ──────────────────────────────────────────────────────────────
    requestSwitch(index) {
        if (index < 0 || index >= this.models.length) return false;
        if (index === this.current) return false;
        // Already swapping: retarget the dip instead of swallowing the key. The
        // old code returned false here, so a number pressed during a swap did
        // nothing at all while the ammo and the HUD had already moved on.
        if (this.switchT > 0) {
            if (this.pendingSwitch === index) return false;
            this.pendingSwitch = index;
            if (this.switchT > SWAP_LOWER) this.switchT = SWAP_LOWER * 0.4;   // dip again
            return true;
        }
        // Do NOT build here: on the press frame that is the stall players feel.
        // Ask for it and let the queue deliver it; if the queue has not got to it
        // by the bottom of the dip, the swap there builds it as it always could.
        if (!this.models[index] && this._queue.indexOf(index) < 0) this._queue.unshift(index);
        this.pendingSwitch = index;
        this.switchT = 0.001;
        return true;
    }

    startReload(def) {
        if (this.reload) return;
        this.reload = { t: 0, dur: def.reloadTime, type: def.type };
    }

    cancelReload() { this.reload = null; }

    onFire(def) {
        const r = def.recoil;
        // impulse into the spring
        this.recoilVelPos.z += r.kick * 9;
        this.recoilVelPos.y += r.kick * 2.4;
        this.recoilVelRot.x -= r.kick * 26;
        this.recoilVelRot.y += (Math.random() - 0.5) * r.kick * 16;
        this.recoilVelRot.z += (Math.random() - 0.5) * r.kick * 12;
        this.flashT = 0.045;

        const p = this.parts;
        if (def.type === 'sniper') this.boltT = 0.55;
        if (def.type === 'shotgun') this.pumpT = 0.42;
        void p;
    }

    addLook(dx, dy) {
        // mouse movement pushes the gun; springs pull it back
        this.swayVX += -dx * 0.00055;
        this.swayVY += -dy * 0.00045;
    }

    onLand(force) { this.landDip = clamp(force, 0, 1) * 0.06; }

    /** World-space muzzle position mapped into the main camera's space. */
    muzzleWorld(camera, out) {
        const p = this.parts;
        p.muzzle.updateWorldMatrix(true, false);
        out.setFromMatrixPosition(p.muzzle.matrixWorld);
        // viewmodel space is camera-local space
        out.applyMatrix4(camera.matrixWorld);
        return out;
    }

    ejectPointWorld(camera, out) {
        const p = this.parts;
        out.copy(p.ejectPort).applyMatrix4(p.gun.matrixWorld).applyMatrix4(camera.matrixWorld);
        return out;
    }

    // ── per-frame ───────────────────────────────────────────────────────────
    /**
     * state: { aiming, sprinting, speed, grounded, dt, firing }
     */
    update(dt, state) {
        const def = this.def;
        // NOTE: `model` is resolved AFTER the switch block below, not here.
        // Capturing it up front meant that when a swap completed mid-frame the
        // later `model.visible = ...` line re-showed the weapon we had just put
        // away, leaving two guns in your hands.

        // ── blends ──
        const adsTarget = (state.aiming && !state.sprinting && !this.reload && this.switchT === 0) ? 1 : 0;
        const adsSpeed = 1 / Math.max(0.06, def.adsTime);
        this.ads = damp(this.ads, adsTarget, adsSpeed * 4.2, dt);
        this.sprint = damp(this.sprint, state.sprinting && state.speed > 3 ? 1 : 0, 11, dt);
        this.breath += dt;

        // ── weapon switch: lower, swap, raise ──
        if (this.switchT > 0) {
            this.switchT += dt;
            const half = SWAP_LOWER;
            if (this.pendingSwitch >= 0 && this.switchT >= half) {
                this._ensure(this.current).group.visible = false;
                this.current = this.pendingSwitch;
                this._ensure(this.current).group.visible = true;
                if (this._skin) this._tint(this._ensure(this.current).group);
                this.pendingSwitch = -1;
                this.reload = null;
                // Drop aim state across a swap. Carrying it over left the
                // sniper's scopeAmount high enough to hide its own model, so
                // switching to it produced empty hands.
                this.ads = 0;
                this.scopeAmount = 0;
            }
            if (this.switchT >= half * 2) { this.switchT = 0; }
        }
        const swPhase = this.switchT > 0 ? Math.sin(clamp(this.switchT / (SWAP_LOWER * 2), 0, 1) * Math.PI) : 0;

        // resolved here so it always refers to the weapon actually in hand
        const p = this.parts;
        const model = this._ensure(this.current).group;
        // belt and braces: whatever happens above, exactly one weapon is shown
        for (let i = 0; i < this.models.length; i++) {
            const m = this.models[i];
            if (m && i !== this.current && m.group.visible) m.group.visible = false;
        }

        // ── sway springs ──
        this.swayVX -= this.swayX * 42 * dt; this.swayVX *= Math.pow(0.0009, dt);
        this.swayVY -= this.swayY * 42 * dt; this.swayVY *= Math.pow(0.0009, dt);
        this.swayX = clamp(this.swayX + this.swayVX * dt, -0.05, 0.05);
        this.swayY = clamp(this.swayY + this.swayVY * dt, -0.05, 0.05);

        // ── movement bob ──
        const moveAmt = clamp(state.speed / 5.2, 0, 1.4);
        if (state.grounded && state.speed > 0.4) this.bobT += dt * (6.5 + state.speed * 1.25);
        else this.bobT += dt * 0.9;
        const bobScale = (1 - this.ads * 0.78) * moveAmt;
        const bobX = Math.sin(this.bobT) * 0.0125 * bobScale;
        const bobY = (Math.abs(Math.cos(this.bobT)) - 0.5) * 0.014 * bobScale;
        const bobRZ = Math.sin(this.bobT) * 0.020 * bobScale;

        // ── idle breathing ──
        const brX = Math.sin(this.breath * 1.15) * 0.0022 * (1 - this.ads * 0.55);
        const brY = Math.sin(this.breath * 1.65 + 1) * 0.0028 * (1 - this.ads * 0.55);

        // ── recoil spring ──
        const rec = def.recoil;
        for (const [cur, vel, stiff] of [[this.recoilPos, this.recoilVelPos, 120], [this.recoilRot, this.recoilVelRot, 150]]) {
            vel.x -= cur.x * stiff * dt; vel.y -= cur.y * stiff * dt; vel.z -= cur.z * stiff * dt;
            const d = Math.pow(0.00025, dt * (rec.recover / 9));
            vel.multiplyScalar(d);
            cur.addScaledVector(vel, dt);
        }
        this.landDip = damp(this.landDip, 0, 9, dt);

        // ── reload animation ──
        let rlPos = this._v.set(0, 0, 0), rlRotX = 0, rlRotZ = 0;
        if (this.reload) {
            this.reload.t += dt;
            const k = clamp(this.reload.t / this.reload.dur, 0, 1);
            this._applyReload(p, def, k);
            // whole-gun motion during the reload
            const dip = Math.sin(k * Math.PI);
            rlPos.set(0.02 * dip, -0.075 * dip, 0.04 * dip);
            rlRotX = 0.34 * dip;
            rlRotZ = -0.28 * dip;
            if (k >= 1) { this.reload = null; this._resetParts(p); }
        } else {
            this._idleParts(p, def, dt);
        }

        // ── pose blend: hip → ads, plus sprint ──
        const hip = p.hipPos, adsP = p.adsPos;
        const a = this.ads;
        this._pos.set(
            hip.x + (adsP.x - hip.x) * a,
            hip.y + (adsP.y - hip.y) * a,
            hip.z + (adsP.z - hip.z) * a
        );
        const hr = p.hipRot;
        this._rot.set(hr.x * (1 - a), hr.y * (1 - a), hr.z * (1 - a));

        // sprint pose — gun canted across the body, muzzle down-left
        const s = this.sprint * (1 - a);
        this._pos.x += s * -0.055;
        this._pos.y += s * -0.075;
        this._pos.z += s * 0.075;
        this._rot.x += s * 0.30;
        this._rot.y += s * 0.62;
        this._rot.z += s * -0.55;

        // switch dip
        this._pos.y -= swPhase * 0.30;
        this._rot.x += swPhase * 0.85;

        // additive layers
        this._pos.x += bobX + this.swayX + brX + rlPos.x + this.recoilPos.x;
        this._pos.y += bobY + this.swayY + brY + rlPos.y + this.recoilPos.y - this.landDip;
        this._pos.z += rlPos.z + this.recoilPos.z * 0.35;

        this._rot.x += this.recoilRot.x * 0.02 + rlRotX + (-this.swayY * 2.2) + brY * 2;
        this._rot.y += this.recoilRot.y * 0.02 + (this.swayX * 2.6);
        this._rot.z += this.recoilRot.z * 0.02 + bobRZ + rlRotZ;

        model.position.copy(this._pos);
        model.rotation.copy(this._rot);

        // Reticle only once you are most of the way into the aim — at the hip a
        // floating dot over the gun reads as a bug, not a sight.
        //
        // Scoped weapons never show the mesh reticle at all: their sight IS the
        // full-screen scope overlay, and showing both meant that on the way into
        // a snipe you briefly saw a red-dot optic before the scope took over.
        if (p.reticleGroup) p.reticleGroup.visible = !def.scope && this.ads > 0.55;

        // ── sniper: hide the model and go to scope overlay when fully aimed ──
        this.scopeAmount = def.scope ? clamp((this.ads - 0.72) / 0.28, 0, 1) : 0;
        model.visible = this.scopeAmount < 0.98;

        // ── muzzle flash ──
        if (this.flashT > 0) {
            this.flashT -= dt;
            const o = clamp(this.flashT / 0.045, 0, 1);
            const scale = 0.75 + Math.random() * 0.8;
            for (const f of p.flash) {
                f.material.opacity = o * (0.55 + Math.random() * 0.45);
                f.scale.setScalar(scale);
            }
            p.flash[2].rotation.z = Math.random() * Math.PI;
            p.flashLight.intensity = o * 6.5;
            p.muzzle.visible = true;
        } else if (p.muzzle.visible) {
            for (const f of p.flash) f.material.opacity = 0;
            p.flashLight.intensity = 0;
            p.muzzle.visible = false;
        }

        // trigger finger
        if (p.trigger) p.trigger.rotation.x = state.firing ? -0.22 : 0;

        // fov: tighten a touch when aiming so sights feel closer
        const targetFov = 58 - this.ads * 8;
        if (Math.abs(this.camera.fov - targetFov) > 0.01) {
            this.camera.fov = damp(this.camera.fov, targetFov, 10, dt);
            this.camera.updateProjectionMatrix();
        }
    }

    _idleParts(p, def, dt) {
        // cycling actions return home when not reloading
        if (p.bolt && p.boltHome) {
            if (this.boltT > 0) {
                this.boltT -= dt;
                const k = 1 - clamp(this.boltT / 0.55, 0, 1);
                const s = Math.sin(k * Math.PI);
                p.bolt.position.z = p.boltHome.z + s * 0.10;
                p.bolt.rotation.z = -s * 1.0;
            } else {
                p.bolt.position.copy(p.boltHome);
                p.bolt.rotation.z = 0;
            }
        }
        if (p.pump && p.pumpHome) {
            if (this.pumpT > 0) {
                this.pumpT -= dt;
                const k = 1 - clamp(this.pumpT / 0.42, 0, 1);
                p.pump.position.z = p.pumpHome.z + Math.sin(k * Math.PI) * 0.085;
            } else {
                p.pump.position.copy(p.pumpHome);
            }
        }
        if (p.charge && p.chargeHome) p.charge.position.copy(p.chargeHome);
        if (p.mag && p.magHome) { p.mag.position.copy(p.magHome); p.mag.rotation.set(0, 0, 0); p.mag.visible = true; }
        if (p.handL) p.handL.visible = true;
        void def;
    }

    _applyReload(p, def, k) {
        if (def.type === 'sniper') {
            // bolt back, strip rounds, bolt forward
            const s = Math.sin(clamp(k * 1.6, 0, 1) * Math.PI);
            if (p.bolt && p.boltHome) {
                p.bolt.position.z = p.boltHome.z + s * 0.11;
                p.bolt.rotation.z = -s * 1.1;
            }
            if (p.handL) p.handL.visible = k < 0.15 || k > 0.85;
            return;
        }
        if (def.type === 'shotgun') {
            // shell-by-shell: hand leaves the pump, feeds, pump cycles at the end
            if (p.pump && p.pumpHome) {
                const c = k > 0.72 ? Math.sin(((k - 0.72) / 0.28) * Math.PI) : 0;
                p.pump.position.z = p.pumpHome.z + c * 0.085;
            }
            if (p.handL) p.handL.visible = k < 0.12 || k > 0.70;
            return;
        }
        // rifle / smg: mag out → mag in → charging handle
        if (p.mag && p.magHome) {
            if (k < 0.30) {
                const t = k / 0.30;
                p.mag.position.set(p.magHome.x, p.magHome.y - t * 0.42, p.magHome.z + t * 0.06);
                p.mag.rotation.x = t * 0.9;
                p.mag.visible = t < 0.92;
            } else if (k < 0.42) {
                p.mag.visible = false;
            } else if (k < 0.74) {
                const t = (k - 0.42) / 0.32;
                p.mag.visible = true;
                p.mag.position.set(p.magHome.x, p.magHome.y - (1 - t) * 0.34, p.magHome.z + (1 - t) * 0.05);
                p.mag.rotation.x = (1 - t) * 0.7;
            } else {
                p.mag.position.copy(p.magHome);
                p.mag.rotation.set(0, 0, 0);
                p.mag.visible = true;
            }
        }
        if (p.charge && p.chargeHome) {
            const c = k > 0.78 ? Math.sin(((k - 0.78) / 0.22) * Math.PI) : 0;
            p.charge.position.z = p.chargeHome.z + c * 0.075;
        }
        if (p.handL) p.handL.visible = k < 0.08 || k > 0.80;
    }

    _resetParts(p) {
        if (p.mag && p.magHome) { p.mag.position.copy(p.magHome); p.mag.rotation.set(0, 0, 0); p.mag.visible = true; }
        if (p.charge && p.chargeHome) p.charge.position.copy(p.chargeHome);
        if (p.bolt && p.boltHome) { p.bolt.position.copy(p.boltHome); p.bolt.rotation.z = 0; }
        if (p.pump && p.pumpHome) p.pump.position.copy(p.pumpHome);
        if (p.handL) p.handL.visible = true;
    }

    resize(aspect) {
        this.camera.aspect = aspect;
        this.camera.updateProjectionMatrix();
    }

    render(renderer) {
        renderer.autoClear = false;
        renderer.clearDepth();
        renderer.render(this.scene, this.camera);
        renderer.autoClear = true;
    }
}
