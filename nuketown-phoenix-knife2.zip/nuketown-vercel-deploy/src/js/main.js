// ============================================================================
// main.js — bootstrap, game loop and glue.
// ============================================================================
import { loadGign } from './gign.js';
import { loadPhoenix } from './phoenix.js';
import * as THREE from 'three';
import { buildNuketown, SPAWN_A, SPAWN_B, MAP_BOUNDS } from './map.js';
import { CollisionWorld } from './physics.js';
import { ViewModel } from './viewmodel.js';
import { Player } from './player.js';
import { Bot, claimPoint, deploySpread, resetDeploySpread } from './ai.js';
import { HUD } from './hud.js';
import { loadRebel, rebelInfo, setRebelMode } from './rebel.js';
import { Effects } from './effects.js';
import { Grenades } from './grenades.js';
import { Melee } from './melee.js';
import { Killstreaks, STREAKS } from './killstreaks.js';
import { Airdrop } from './airdrop.js';
import { Vault } from './vault.js';
import { KillChain, milestoneFor, milestoneProgress } from './medals.js';
import { createMode, MODES } from './modes.js';
import { selectedMode as pickedMode, onModeChange } from './hud.js';
import { createPostFX } from './shaders.js';
import { createFreeRoam } from './freeroam.js';
import * as shop from './shop.js';
import * as loadout from './loadout.js';
import * as cine from './cinematic.js';
import { DIFFICULTIES, difficultyById, isDifficulty, applyDifficulty, rollSkill, DEFAULT_DIFFICULTY } from './difficulty.js';
import { characterAssets } from './character.js';
import { vmAssets, vmAssetsReady } from './vmassets.js';
import { upgradeTextures, photoStatus } from './materials.js';
import { batchStaticScene, mergeStaticScene, mergeRig, pruneShadowCasters } from './optimize.js';
import { IS_TOUCH, initTouch, viewportSize, applyViewportVars } from './touch.js';
import { WEAPON_DEFS } from './weapons.js';
import { TEAM_A, TEAM_B, BOT_NAMES_A, BOT_NAMES_B, randElement, clamp, shuffle, MAP_SCALE } from './utils.js';
import * as A from './audio.js';

const canvas = document.getElementById('gameCanvas');
// A phone or a tablet: nothing to hover with, and a finger on glass. There used to
// be a notice here telling those players to go find a keyboard, because pointer
// lock and a held mouse button are the whole input model. touch.js replaces that:
// the same gates, driven by a thumbstick and a drag instead, and no pointer lock
// anywhere. `(hover: none) and (pointer: coarse)` is the test, not maxTouchPoints,
// because a touchscreen laptop has the latter and should keep its mouse.
const $ = id => document.getElementById(id);

let renderer, scene, camera, sun, composerFX, sky, dust;
let cw, effects, vm, player, hud, streaks, gamemode, grenades, melee, airdrop, vault;
let bots = [];
let state = 'loading';           // loading | menu | playing | paused | ended
let last = 0, elapsed = 0;
// How big a piece of the town one cullable object is, in world metres. Small
// tiles cull better and cost more draw calls; 72 m is where the measured curve
// bends — 50k vertices a frame instead of 167k, for about 180 draws instead of 100.
const TILE = 72;
// One whole frame's GPU work, for the F readout. three resets renderer.info on
// every render() call, and the post composer renders several passes per frame,
// so reading info directly reports the last pass only — it always looked like
// "1 draw". Accumulate instead and hand the finished frame to the HUD.
const frameStats = { calls: 0, triangles: 0 };
// adaptive resolution — targets 60 fps (16.7 ms)
const DEVICE_DPR = window.devicePixelRatio || 1;
let maxDpr = 1.15, curDpr = 1.0, frameAvg = 16, dprCooldown = 0;
const DPR_FLOOR = 0.85;
// The last size the renderer was actually built for, so a resize that changed
// nothing (a phone fires more of those than a desktop ever does) costs nothing.
let lastW = 0, lastH = 0, lastDpr = 0;
let charShadowsEnabled = true;
// The menu picker owns the choice; mirror it here so startMatch can read it.
let selectedMode = pickedMode() || MODES[0].id;
onModeChange(id => { selectedMode = id; });
// Auto quality: accumulates seconds of comfortably-fast frames before stepping
// the preset up. Locked once the player picks a preset by hand.
let qualityHeadroom = 0, autoQualityLocked = false;
const dprCooldownStep = 1.0;
let fpsAccum = 0, fpsFrames = 0;
let respawnTimer = 0;
let roamTicks = 0;                 // how many frames the roam camera has been asked for
let glLost = false;                // set by the canvas' webglcontextlost handler

// ── safe graphics ───────────────────────────────────────────────────────────
// Chrome takes a WebGL context away for a driver reset, a full GPU or a
// blacklisted driver — the same machine plays fine at reduced cost. So the FIRST
// loss in a session reloads the tab once by itself, with shadows, post and the
// resolution cap dropped; a second loss stops and explains. Both flags live in
// sessionStorage, so closing the tab restores full quality without anyone having
// to find a switch, and a machine that genuinely cannot run the game is told so
// instead of being quietly degraded forever.
const SAFE_GFX_KEY = 'nuke.safegfx';
const GFX_LOSS_KEY = 'nuke.gfxloss';
let safeGfx = false;
function readFlag(k) { try { return sessionStorage.getItem(k) === '1'; } catch (e) { return false; } }
function writeFlag(k, v) { try { sessionStorage.setItem(k, v ? '1' : '0'); } catch (e) {} }
// Chained kills (double/triple/multi) and the streak-name ladder. Kept out here
// rather than on Player so the death/respawn paths can clear them together.
const killChain = new KillChain();
let deadInfo = null;
let boardOpen = false;
let touchCtl = null;                   // the touch HUD, on phones only
let shadowTick = 0;
const RESPAWN_TIME = 4.0;

// The three levers that actually move frame time on a weak GPU are: how many
// lights every material has to evaluate per pixel, how expensive the shadow
// filter is, and how many full-screen post passes run. Resolution is a fourth,
// handled separately by the adaptive scaler.
const QUALITY = [
    {
        name: 'Low', shadow: 1024, shadowEvery: 3, dprCap: 1.00, post: 0,
        shadowType: THREE.BasicShadowMap, interiorLights: false, charShadows: false
    },
    {
        name: 'Medium', shadow: 1024, shadowEvery: 2, dprCap: 1.35, post: 1,
        shadowType: THREE.PCFShadowMap, interiorLights: false, charShadows: true
    },
    {
        name: 'High', shadow: 2048, shadowEvery: 2, dprCap: 1.50, post: 2,
        shadowType: THREE.PCFSoftShadowMap, interiorLights: true, charShadows: true
    }
];
// Start on Low. A first run that stutters is a much worse first impression than
// one that looks slightly plainer, and the auto-tuner raises the preset within
// a few seconds on any machine with headroom to spare.
// `difficulty: null` is the state "never asked yet" — the first Deploy screen
// answers it and it is saved from then on.
// touchSens is a separate number from `sens` on purpose: a finger on glass cannot
// make the small careful movements a mouse can, so the two are tuned apart.
const DEFAULTS = { sens: 1.0, fov: 78, quality: 0, difficulty: null, name: '',
    touchSens: 1.15, ctrlSize: 1.0, ctrlOpacity: 0.5, adsMode: 'tap' };
let settings = { ...DEFAULTS };

function loadSettings() {
    try {
        const raw = localStorage.getItem('nuketown.settings');
        if (raw) settings = { ...DEFAULTS, ...JSON.parse(raw) };
        // A hand-edited or stale profile must not put a bot on a setting that
        // does not exist; null means the menu will simply ask again.
        if (!isDifficulty(settings.difficulty)) settings.difficulty = null;
    } catch { settings = { ...DEFAULTS }; }
}
function saveSettings() {
    try { localStorage.setItem('nuketown.settings', JSON.stringify(settings)); } catch { /* private mode */ }
}

const diffEntry = () => difficultyById(settings.difficulty || DEFAULT_DIFFICULTY);

// ── callsign ────────────────────────────────────────────────────────────────
/**
 * Stripped, not trusted: this string lands inside innerHTML in the scoreboard
 * and the kill feed, so anything that is not a letter, a digit or one of
 * " ._-" is dropped before it is stored. 14 characters, because the row is a
 * fixed width and a long name pushes the kill counts off the board.
 */
function cleanCallsign(raw) {
    const t = String(raw == null ? '' : raw).replace(/[^\p{L}\p{N} ._\-]/gu, '').trim().slice(0, 14);
    return t || 'SOLDIER-01';
}
const callsign = () => cleanCallsign(settings.name);

/** One write for the whole UI: profile, player, bots' view of the player, and
 *  every field showing it. The name is what the scoreboard and the feed print. */
function applyCallsign(raw) {
    const name = cleanCallsign(raw);
    settings.name = name;
    saveSettings();
    if (player) player.name = name;
    if (playerProxy) playerProxy.name = name;
    for (const el of document.querySelectorAll('.callsignInput')) {
        if (document.activeElement !== el) el.value = name;
    }
    const chip = $('menuNameVal');
    if (chip) chip.textContent = name;
}

function buildNameUI() {
    const fields = document.querySelectorAll('.callsignInput');
    for (const el of fields) {
        el.value = settings.name || '';
        el.placeholder = callsign();
        el.maxLength = 14;
        // Typing is not gameplay. The field swallows the keystroke before it
        // reaches the window listeners, so WASD does not move a soldier and
        // Enter does not fire a weapon while someone is writing their name.
        el.addEventListener('keydown', e => {
            e.stopPropagation();
            if (e.code === 'Enter' || e.code === 'Escape') { e.preventDefault(); el.blur(); }
        });
        el.addEventListener('keyup', e => e.stopPropagation());
        el.addEventListener('input', () => {
            settings.name = cleanCallsign(el.value);
            if (player) player.name = settings.name;
            if (playerProxy) playerProxy.name = settings.name;
            const chip = $('menuNameVal');
            if (chip) chip.textContent = settings.name;
        });
        el.addEventListener('blur', () => applyCallsign(el.value));
    }
}

const _v = new THREE.Vector3();

// A missing GPU blocklist entry or a disabled "hardware acceleration" flag used to
// mean an eternal loading bar. Say what is wrong instead.
/**
 * One throwaway context, given straight back. Handing it back matters: on a GPU
 * that is already at Chrome's context limit, the probe is the second context and
 * the real renderer is the third — so the failure the player was told about was
 * caused by the test that was supposed to prevent it.
 */
function webglSupported() {
    try {
        const c = document.createElement('canvas');
        const gl = c.getContext('webgl2') || c.getContext('webgl') || c.getContext('experimental-webgl');
        if (!gl) return false;
        const lose = gl.getExtension('WEBGL_lose_context');
        if (lose) lose.loseContext();
        return true;
    } catch {
        return false;
    }
}

/** Replaces the loader with a readable message. Also used for boot exceptions. */
function showBootError(title, detail, retry = true) {
    const loader = $('loader');
    if (!loader) return;
    loader.style.opacity = '1';
    loader.style.display = 'flex';
    loader.innerHTML =
        '<div class="bootErr">' +
        '<h1>NUKETOWN</h1>' +
        '<h2>' + title + '</h2>' +
        '<p>' + detail + '</p>' +
        (retry ? '<button class="menuBtn primary" id="btnRetry">Reload</button>' : '') +
        '</div>';
    const btn = $('btnRetry');
    if (btn) btn.onclick = () => location.reload();
}

// ── boot ────────────────────────────────────────────────────────────────────
async function boot() {
    safeGfx = readFlag(SAFE_GFX_KEY);
    if (!webglSupported()) {
        showBootError(
            'WebGL is unavailable',
            'This browser cannot give the page a 3D context. Four things fix it, in the order '
            + 'they usually work: close the other tabs of this game (each one holds a graphics '
            + 'context), turn on hardware acceleration in settings and restart the browser, '
            + 'check that your driver did not just update, and try Chrome or Edge if you are on '
            + 'something else. Nothing you do to your computer is needed to play — reload and '
            + 'it will try again.',
            true
        );
        return;
    }

    // The GLB models are the one part of startup that waits on the network, so
    // they are requested HERE, before the steps below start spending 200-400 ms
    // of pure CPU on the map, the shadow setup and the environment probe. The
    // two asset layers memoise their promises, so the await further down simply
    // picks up the download that is already in flight.
    const modelsInFlight = loadCharacters();

    const steps = [
        ['Compiling renderer', setupRenderer],
        ['Generating surfaces', () => { /* materials build lazily on first use */ }],
        ['Constructing Nuketown', setupWorld],
        ['Lighting the test site', setupLighting],
        // Assets must land before the player rig is built: the viewmodel picks
        // its meshes at construction, and bots pick theirs at spawn.
        ['Deploying operators', () => modelsInFlight],
        ['Assembling weapons', setupPlayerRig],
        ['Calibrating optics', setupPost],
        ['Ready', finishBoot]
    ];
    for (let i = 0; i < steps.length; i++) {
        $('loadMsg').textContent = steps[i][0];
        $('loadBar').style.width = ((i / steps.length) * 100).toFixed(0) + '%';
        // setTimeout, not rAF: the loader must still advance in a tab that is
        // not compositing frames.
        await new Promise(r => setTimeout(r, 24));
        try {
            const maybe = steps[i][1]();
            if (maybe && typeof maybe.then === 'function') await maybe;
        } catch (err) {
            $('loadMsg').textContent = 'Failed: ' + steps[i][0];
            console.error('[boot]', steps[i][0], err);
            throw err;
        }
    }
    $('loadBar').style.width = '100%';
}

/**
 * Pull in the skinned GLB soldiers before the first match so bots are built
 * with them. This resolves either way — if the assets are absent, ai.js falls
 * back to the procedural rig and the game plays identically.
 */
async function loadCharacters() {
    // Both resolve either way; a missing asset falls back to the procedural
    // model rather than failing the boot.
    await Promise.all([
        characterAssets.load('assets/models/'),
        vmAssets.load('assets/models/'),
        loadRebel(),
        loadGign(),
        loadPhoenix()
    ]);
}

/**
 * Compile everything the scene is going to ask for, off the render path.
 *
 * The single most common "the game froze for a second then carried on" in a
 * three.js game is shader compilation: a program is built the first frame a
 * material is on screen, and a post-processing chain has a dozen of them. With
 * KHR_parallel_shader_compile (Chrome, Edge, Firefox, Safari 17+) the driver
 * builds them in worker threads while the loading bar is still up; where the
 * extension is missing three falls back to a synchronous compile, which is just
 * the same work done in one go. Either way this never blocks a frame in play.
 */
function warmShaders() {
    if (!renderer || !scene || !camera) return;
    try {
        const p = renderer.compileAsync
            ? renderer.compileAsync(scene, camera)
            : Promise.resolve(renderer.compile(scene, camera));
        if (p && p.catch) p.catch(() => { /* warming is a nicety, never a dependency */ });
    } catch { /* older renderer without compile(): shaders build lazily */ }
}

/**
 * requestPointerLock returns a promise in current browsers and rejects if the
 * document is not eligible (embedded frame, too soon after an Escape exit).
 * Unhandled, every respawn threw an uncaught rejection into the console.
 */
/**
 * Ask for the pointer. On a phone there is nothing to ask for: the flag the mouse
 * handlers hide behind is set from the state instead, so `locked` means "you are in
 * a match and not looking at a menu" for both devices. Every caller of this keeps
 * working unchanged, which is why the branch is here and not at the call sites.
 */
function grabPointer() {
    if (IS_TOUCH) {
        if (player) player.locked = true;
        document.body.classList.add('playing');
        return;
    }
    const r = canvas.requestPointerLock();
    if (r && typeof r.catch === 'function') r.catch(() => { /* user can click to re-lock */ });
    document.body.classList.add('playing');
}

/** True while a screen you are meant to click is on top of the game. */
function menuOpen() {
    const m = $('menu');
    if (m && m.style.display !== 'none') return true;
    // The Controls / settings card can be opened over a live match, and a slider
    // you cannot see the pointer of is not a slider.
    const pn = $('panel');
    if (pn && pn.style.display === 'flex') return true;
    // How to Play is a card from the menu, and it stays up over one: it counts as a
    // menu for the same reason the settings card does — the pointer belongs to it.
    const ht = $('howTo');
    if (ht && ht.style.display === 'flex') return true;
    return ['pause', 'end', 'diffGate'].some(id => { const n = $(id); return !!n && n.classList.contains('on'); });
}

/**
 * The mouse belongs to the menus, never to the game's overlay screens. Releasing
 * pointer lock is asynchronous and does nothing at all if nothing is locked, so
 * the class that hides the system cursor is dropped here as well: without it the
 * arrow stayed invisible over the main menu and the pause card.
 */
function releaseCursor() {
    // The touch flag first, then the mouse: the two are independent, and a phone
    // never held the pointer, so nothing below it has to know about the branch.
    if (IS_TOUCH && player) player.locked = false;
    if (document.pointerLockElement) document.exitPointerLock();
    document.body.classList.remove('playing');
}

function setupRenderer() {
    try {
        renderer = new THREE.WebGLRenderer({
            canvas, antialias: false, stencil: false,
            // 'high-performance' asks for the discrete GPU. On a machine that is
            // already losing contexts, the request is a nudge towards the driver
            // that dropped it, so in safe mode the browser chooses.
            powerPreference: safeGfx ? 'default' : 'high-performance'
        });
    } catch (err) {
        showBootError('The browser refused to give this page a 3D canvas',
            'The graphics driver threw the request out rather than answering it: '
            + String((err && err.message) || err)
            + '. Close the other tabs of this game and reload — a full quality pass is worth waiting for.');
        const e = new Error('webgl refused');
        e.handled = true;
        throw e;
    }
    // The phone's real rectangle, not the layout viewport: see viewportSize().
    const vs = IS_TOUCH ? viewportSize() : null;
    if (vs) applyViewportVars(vs.h);
    renderer.setSize(vs ? vs.w : window.innerWidth, vs ? vs.h : window.innerHeight);
    renderer.setPixelRatio(safeGfx ? 1.0 : curDpr);
    renderer.shadowMap.enabled = !safeGfx;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 0.92;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    // frameStats above: the counters are cleared once per frame by hand.
    renderer.info.autoReset = false;

    scene = new THREE.Scene();
    // The haze is a distance, not a fraction of the map: an 84 m street and a 122 m
    // one need the far end of the fog to sit at the same metre-marks relative to
    // the ground, so both numbers scale with it. Without this the far houses would
    // simply dissolve on a bigger map.
    // One number for how far anything can be drawn. The fog used to reach 360 map
    // units, which on a grown map is further than the camera can see — so the haze
    // did nothing but thin out and the desert's edge sat there crisp. Tie the two
    // together and the fog always finishes inside the far plane.
    const VIEW_FAR = 700;
    scene.fog = new THREE.Fog(0xcfc4ac, 110 * MAP_SCALE, Math.min(360 * MAP_SCALE, VIEW_FAR * 0.92));

    const startAspect = vs ? vs.w / vs.h : window.innerWidth / window.innerHeight;
    camera = new THREE.PerspectiveCamera(78, startAspect, 0.06, VIEW_FAR);
    scene.add(camera);

    // A lost WebGL context is Chrome taking the canvas away — a driver reset, a
    // backgrounded tab on a machine that ran out of GPU memory, a blacklisted
    // driver. Left alone, every call three.js makes afterwards returns
    // CONTEXT_LOST, and the page becomes an error log at 144 Hz until the tab is
    // killed. `preventDefault` is what buys us the restore event; stopping the loop
    // is what stops the tail-spin; the loader card is what tells the player to
    // press F5 instead of wondering whether the game ate their save.
    canvas.addEventListener('webglcontextlost', e => {
        e.preventDefault();
        glLost = true;
        releaseCursor();
        if (!readFlag(SAFE_GFX_KEY) && !readFlag(GFX_LOSS_KEY)) {
            writeFlag(GFX_LOSS_KEY, true);
            writeFlag(SAFE_GFX_KEY, true);
            showBootError('Recovering in safe graphics mode',
                'Chrome took the 3D context away — a driver reset, or the GPU being full. '
                + 'This tab is reloading itself once with the expensive parts switched off: '
                + 'shadows, post-processing and the resolution cap. Close the tab afterwards '
                + 'and the game comes back at full quality.', false);
            setTimeout(() => location.reload(), 2600);
            return;
        }
        showBootError('The graphics driver dropped this tab',
            'This tab has already come back once in safe graphics mode and the driver let go again. '
            + 'That usually means the GPU itself is short of memory: close other 3D or video tabs, '
            + 'and reload this one. Your settings, sensitivity and callsign are saved.');
    }, false);
    canvas.addEventListener('webglcontextrestored', () => {
        // three.js cannot rebuild what it had already uploaded, so the honest
        // answer is a reload — but say it once rather than leaving a black canvas.
        showBootError('Context restored — reload to continue', 'Press Reload, or hit Enter.', true);
    }, false);
}

// ── difficulty: the ask, the chip, the live switch ──────────────────────────
// Asked once, on the first Deploy screen, then remembered: a modal before every
// match is friction, and this is a decision about how you like the game rather
// than about this round. Controls carries the same three choices for afterwards,
// and picking one re-scales the soldiers already on the map — there is no reason
// to make someone quit a match to try Hard.
function showDiffGate() {
    const g = $('diffGate'); if (g) g.classList.add('on');
    releaseCursor();
    // Focus it only while it is still blank: a returning player has a name, and
    // stealing their caret (or an automated test's keystrokes) is not the point.
    const f = settings.name ? null : document.querySelector('#diffGate .callsignInput');
    if (f && !IS_TOUCH) f.focus();   // on a phone the keyboard pops up mid-startup; let the player tap instead
}
function hideDiffGate() { const g = $('diffGate'); if (g) g.classList.remove('on'); }
const diffGateOpen = () => { const g = $('diffGate'); return !!g && g.classList.contains('on'); };

function paintDifficulty() {
    const d = diffEntry();
    const chip = $('menuDiffVal');
    if (chip) chip.textContent = d.name;
    for (const b of document.querySelectorAll('#diffGateOpts .diffOpt')) b.classList.toggle('on', b.dataset.id === d.id);
    for (const b of document.querySelectorAll('#diffSeg button')) b.classList.toggle('on', b.dataset.id === d.id);
    const out = $('diffOut');
    if (out) out.textContent = d.blurb;
}

function setDifficulty(id, announce = false) {
    const d = difficultyById(id);            // unknown ids fall back to Medium
    settings.difficulty = d.id;
    saveSettings();
    for (const b of bots) applyDifficulty(b, d);
    paintDifficulty();
    if (announce) hud.banner(`ENEMY SKILL — ${d.name.toUpperCase()}`, '#FFC24A', d.blurb);
}

function buildDifficultyUI() {
    const gate = $('diffGateOpts'), seg = $('diffSeg');
    if (gate && !gate.childElementCount) {
        for (const d of DIFFICULTIES) {
            const b = document.createElement('button');
            b.type = 'button'; b.className = 'diffOpt'; b.dataset.id = d.id;
            b.innerHTML = `<h4>${d.name}</h4><p>${d.blurb}</p>`;
            b.onclick = () => { setDifficulty(d.id); hideDiffGate(); };
            gate.appendChild(b);
        }
    }
    if (seg && !seg.childElementCount) {
        for (const d of DIFFICULTIES) {
            const b = document.createElement('button');
            b.type = 'button'; b.dataset.id = d.id; b.textContent = d.name;
            // Mid-match it is worth saying something, because the fight visibly
            // changes; on the menu the chip already shows it.
            b.onclick = () => setDifficulty(d.id, state === 'playing' || state === 'paused');
            seg.appendChild(b);
        }
    }
    const skip = $('diffGateSkip');
    if (skip) skip.onclick = () => { setDifficulty(DEFAULT_DIFFICULTY); hideDiffGate(); };
    const change = $('btnDiffChange');
    if (change) change.onclick = showDiffGate;
    paintDifficulty();
    buildNameUI();
    applyCallsign(settings.name);        // paints the chip and the fields
}

function setupWorld() {
    cw = new CollisionWorld();
    const built = buildNuketown(scene, cw);
    sky = built.sky;
    dust = built.dust;
    // Batch the map before anything dynamic joins the scene. Collision lives in
    // separate AABBs, so this is purely a rendering optimisation.
    //
    // Instanced tiles rather than one merged mesh per material: a bucket that
    // spans the whole town can never be rejected by the frustum test, so the old
    // scheme handed the GPU all 107k map vertices every frame in the colour pass
    // and 60k more in the shadow pass, whichever way the player was facing. The
    // town is now ~26 tiles of shared unit-box instances — 74% fewer vertices per
    // frame, and a little over half the vertex memory.
    const pruned = pruneShadowCasters(scene);
    const stats = batchStaticScene(scene, { cell: TILE, minInstances: 2 });
    console.info(`[map] batched ${stats.before} meshes into ${stats.groups} groups ` +
                 `(${stats.instances} instanced), ${(stats.bytesBefore / 1048576).toFixed(1)} MB ` +
                 `-> ${(stats.bytesAfter / 1048576).toFixed(1)} MB of vertex buffers, ` +
                 `dropped ${pruned} small shadow casters`);
    if (stats.lost !== 0) {
        console.warn(`[map] batching changed the triangle count by ${stats.lost} — something was dropped`);
    }
    effects = new Effects(scene);
}

function setupLighting() {
    // Afternoon desert sun, matching the sky shader's sun vector.
    sun = new THREE.DirectionalLight(0xfff0d6, 2.35);
    sun.position.set(-52, 68, 34);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.camera.near = 1;
    sun.shadow.camera.far = 170;
    // Tight box that follows the player — keeps texel density high without a
    // cascaded setup.
    sun.shadow.camera.left = -34;
    sun.shadow.camera.right = 34;
    sun.shadow.camera.top = 34;
    sun.shadow.camera.bottom = -34;
    sun.shadow.bias = -0.0006;
    sun.shadow.normalBias = 0.028;
    scene.add(sun);
    scene.add(sun.target);

    scene.add(new THREE.HemisphereLight(0x9dbde0, 0xbda482, 0.42));
    scene.add(new THREE.AmbientLight(0xffe9cf, 0.10));

    // Image-based lighting straight from the sky shader — this is what makes
    // metal, glass and skin read as real rather than plastic.
    const pmrem = new THREE.PMREMGenerator(renderer);
    pmrem.compileEquirectangularShader();
    const skyScene = new THREE.Scene();
    const probe = sky.clone();
    probe.material = sky.material;
    skyScene.add(probe);
    const env = pmrem.fromScene(skyScene, 0.04, 1, 900);
    scene.environment = env.texture;
    // The sky is very bright; full-strength IBL turns dark ground surfaces blue.
    scene.environmentIntensity = 0.55;
    pmrem.dispose();
    skyScene.remove(probe);
}

function setupPlayerRig() {
    vm = new ViewModel(TEAM_A);
    vm.setEnvironment(scene.environment);
    // Every other gun gets built and drawn once, spread over the frames that have
    // room for it, so that switching to a weapon never costs the player a stall.
    vm.queueAll();
    hud = new HUD();
    // A placeholder so anything constructed below has a mode to read; the real
    // one is built per match in startMatch() from the chosen playlist.
    gamemode = createMode(selectedMode, {
        player, getBots: () => bots, hud, effects, scene, audio: A
    });

    streaks = new Killstreaks({
        scene, effects, hud,
        getBots: () => bots,
        get player() { return player; },
        // A getter, not the object: startMatch builds a fresh mode each match,
        // so a captured reference would go stale after the first one.
        getMode: () => gamemode,
        gamemode,
        onStreakKill: (bot, label) => registerKill(bot, label, false, true),
        onNukeComplete: () => { /* the nuke only wipes the enemy; the score limit ends the match */ },
        shake: (amt) => player && player.addShake(amt)
    });

    airdrop = new Airdrop({
        scene, effects, hud, getBots: () => bots,
        get player() { return player; }, get grenades() { return grenades; },
        get streaks() { return streaks; }, shake: (a) => player && player.addShake(a)
    });

    vault = new Vault({
        scene, cw, effects, hud,
        get player() { return player; }, get grenades() { return grenades; }, shake: (a) => player && player.addShake(a)
    });

    player = new Player(camera, cw, vm, {
        effects, hud,
        getBots: () => (vault && vault.foes.length ? bots.concat(vault.foes) : bots),
        onHit: onPlayerHit,
        onPlayerDeath: onPlayerDeath,
        useStreak: id => tryStreak(id),
        onLoadout: list => hud.setLoadout(list),
        onRefusedSwap: refuseSwapHint
    });

    // Frag grenade (0) and flashbang (9): own viewmodel, throw arc and blast.
    grenades = new Grenades({
        vm, cw, camera, scene, effects, hud, player, getBots: () => bots,
        onHit: onGrenadeHit
    });
    player.ctx.grenades = grenades;
    melee = new Melee({
        vm, cw, camera, player,
        getBots: () => (vault && vault.foes.length ? bots.concat(vault.foes) : bots),
        onHit: onPlayerHit
    });
    player.ctx.melee = melee;
    grenades.onBoom = (k, p) => vault && vault.onBoom(k, p);

    hud.onStreakClick(tryStreak);
}

function setupPost() {
    composerFX = createPostFX(renderer, scene, camera, vm);
    warmShaders();
    loadSettings();
    // The player object exists before the profile is read, so its name is set
    // from here as well — otherwise the scoreboard says "You" once, at the very
    // first match, whatever you typed.
    applyCallsign(settings.name);
    applyQuality();
    if (safeGfx) {
        // Deliberately not saved. The saved profile still says what the player
        // chose; this tab is only borrowing the cheap settings to stay alive.
        renderer.shadowMap.enabled = false;
        if (typeof sun !== 'undefined' && sun) sun.castShadow = false;
        if (composerFX && composerFX.setQuality) composerFX.setQuality(0);
        maxDpr = 1.0;
        curDpr = 1.0;
        renderer.setPixelRatio(1.0);
    }
    if (player) {
        player.sensitivity = 0.0016 * settings.sens;
        player.baseFov = settings.fov;
        camera.fov = settings.fov;
        camera.updateProjectionMatrix();
    }
}

function finishBoot() {
    bindUI();
    buildDifficultyUI();
    // The touch HUD owns its own elements and reads the player, so it comes up
    // after the rig exists. initTouch() returns null on a desktop, where nothing
    // in this file happens at all.
    touchCtl = initTouch({
        getPlayer: () => player,
        roam,
        settings: () => settings,
        saveSettings,
        state: () => state,
        menuOpen,
        // Controls only over live play. A paused or ended screen, or the settings
        // card, must leave the whole screen free for tapping.
        visible: () => state === 'playing' && !menuOpen(),
        roaming: () => roam.active,
        canSkip: () => { const b = $('skipRound'); return !!(b && b.classList.contains('on')); },
        skip: skipRoundNow,
        nextPlayer: dir => cycleFocus(dir),
        scoreboard: on => { boardOpen = !!on; },
        // The touch layer pauses the match itself when the page stops being the one
        // the player is looking at, and keeps the screen awake while it is.
        pause: on => pause(on)
    });
    if (touchCtl) document.body.classList.add('touch');
    state = 'menu';
    // The one ask. Everything after this is a setting like any other.
    if (!isDifficulty(settings.difficulty)) showDiffGate();
    $('loader').style.opacity = '0';
    setTimeout(() => $('loader').style.display = 'none', 500);

    // Photo textures swap in behind the menu, one per frame. Deliberately not
    // awaited: the procedural surfaces are already on screen and correct, so
    // this only ever makes things look better, never delays getting in.
    upgradeTextures('assets/textures/').catch(() => { /* procedural stays */ });
    window.__nuketown = {
        get state() { return state; },
        get scene() { return scene; },
        get renderer() { return renderer; },
        get player() { return player; },
        get bots() { return bots; },
        get touch() { return touchCtl; },
        get camera() { return camera; },
        /**
         * Run the real kill path for one synthetic kill, so the browser harness can
         * assert what a kill does to the HUD (medals, feed, streak strip, score)
         * without having to land a shot on a moving soldier through a software
         * rasteriser. `registerKill` is the same function a hit calls.
         */
        debugKill: (head = false, name = 'TEST') => registerKill({ name: name || 'TEST' }, 'M4A1', !!head, false),
        /** The last wave of spawn-table placements, as the game decided it. */
        deploySpread: () => deploySpread(),
        // one frame of the free-roam camera, callable without rendering —
        // scripts/verify.mjs asserts on what it does
        get roamTicks() { return roamTicks; },
        roamStep: updateFreeRoam,
        roamKey: (code, down) => roam.key(code, !!down),
        roamExit: exitFreeRoam,
        cycleFocus,
        roamInfo() {
            return {
                on: roam.active, x: +roam.pos.x.toFixed(2), y: +roam.pos.y.toFixed(2), z: +roam.pos.z.toFixed(2),
                yaw: +roam.yaw.toFixed(3), pitch: +roam.pitch.toFixed(3),
                speed: +roam.speedNow.toFixed(2), focus: roam.watching ? roam.watching.name : null,
                held: Object.keys(roam.keys).filter(k => roam.keys[k])
            };
        },
        // the imported FBX soldier: what loaded, and which side wears it
        rebel: () => rebelInfo(),
        setRebel: (m) => setRebelMode(m),
        get cw() { return cw; },
        get streaks() { return streaks; },
        // 'easy' | 'medium' | 'hard' — the same three buttons the menu asks with
        get difficulty() { return settings.difficulty; },
        setDifficulty: (id) => setDifficulty(id, false),
        get gamemode() { return gamemode; },
        // Which of the optional GLB/photo layers actually landed. Handy in the
        // console, and this is what scripts/verify.mjs asserts on.
        get perf() { return frameStats; },
        get quality() { return QUALITY[settings.quality].name; },
        get assets() {
            return {
                soldiers: characterAssets.ready,
                soldiersFailed: characterAssets.failed,
                viewmodels: vmAssetsReady(),
                photos: photoStatus()
            };
        },
        step: (n = 1, ms = 16) => { for (let i = 0; i < n; i++) loop(last + ms); },
        setState: s => { state = s; },
        startMatch, THREE
    };
    // Repeat visits skip the download entirely: the shell caches the models,
    // textures and fonts once they have been fetched. Skipped on http (the
    // local PLAY.bat flow) so a dev folder never gets stuck on a stale cache.
    const secure = location.protocol === 'https:' ||
        location.hostname === 'localhost' || location.hostname === '127.0.0.1';
    if ('serviceWorker' in navigator && secure) {
        navigator.serviceWorker.register('./sw.js', { scope: './' }).catch(() => { /* optional */ });
    }

    requestAnimationFrame(loop);
}

// ── UI wiring ───────────────────────────────────────────────────────────────
function bindUI() {
    $('btnStart').onclick = () => { A.unlockAudio(); startMatch(); };
    $('btnControls').onclick = () => $('panel').style.display = 'flex';
    $('btnPanelClose').onclick = () => $('panel').style.display = 'none';
    $('btnHowTo').onclick = () => $('howTo').style.display = 'flex';
    $('btnHowToClose').onclick = () => $('howTo').style.display = 'none';
    $('howTo').onclick = e => { if (e.target === $('howTo')) $('howTo').style.display = 'none'; };
    $('btnMute').onclick = () => {
        const m = A.toggleMute();
        $('btnMute').textContent = 'Sound: ' + (m ? 'Off' : 'On');
    };
    $('btnHudMute').onclick = e => {
        e.stopPropagation();
        const m = A.toggleMute();
        $('btnHudMute').classList.toggle('off', m);
        $('btnHudMute').innerHTML = m ? '&#128264;' : '&#128266;';
    };
    $('btnHudPause').onclick = e => { e.stopPropagation(); pause(true); };
    $('btnResume').onclick = () => pause(false);
    $('btnPauseControls').onclick = () => $('panel').style.display = 'flex';
    $('btnQuit').onclick = () => toMenu();
    $('btnAgain').onclick = () => { hud.hideEnd(); startMatch(); };
    $('btnMenu').onclick = () => { hud.hideEnd(); toMenu(); };

    const sens = $('sensRange'), sensOut = $('sensOut');
    sens.value = Math.round(settings.sens * 100);
    sensOut.textContent = settings.sens.toFixed(2);
    sens.oninput = () => {
        settings.sens = sens.value / 100;
        sensOut.textContent = settings.sens.toFixed(2);
        player.sensitivity = 0.0016 * settings.sens;
        saveSettings();
    };

    // Touch-only rows. They are in the card for every device (the CSS hides them
    // on a desktop) so the layout does not jump when ?touch=1 is used to test.
    const tsens = $('touchSensRange'), tsOut = $('touchSensOut');
    if (tsens) {
        tsens.value = Math.round(settings.touchSens * 100);
        tsOut.textContent = settings.touchSens.toFixed(2);
        tsens.oninput = () => {
            settings.touchSens = tsens.value / 100;
            tsOut.textContent = settings.touchSens.toFixed(2);
            saveSettings();
        };
    }
    for (const [id, key, out, fmt] of [
        ['ctrlSizeRange', 'ctrlSize', 'ctrlSizeOut', v => `${Math.round(v * 100)}%`],
        ['ctrlOpacityRange', 'ctrlOpacity', 'ctrlOpacityOut', v => `${Math.round(v * 100)}%`]]) {
        const el = $(id);
        if (!el) continue;
        el.value = Math.round(settings[key] * 100);
        $(out).textContent = fmt(settings[key]);
        el.oninput = () => {
            settings[key] = el.value / 100;
            $(out).textContent = fmt(settings[key]);
            saveSettings();
        };
    }
    const adsMode = $('adsModeSeg');
    if (adsMode) {
        for (const b of adsMode.querySelectorAll('button')) {
            b.classList.toggle('on', b.dataset.mode === settings.adsMode);
            b.onclick = () => {
                settings.adsMode = b.dataset.mode;
                for (const o of adsMode.querySelectorAll('button')) o.classList.toggle('on', o === b);
                saveSettings();
            };
        }
    }

    const fov = $('fovRange'), fovOut = $('fovOut');
    fov.value = settings.fov;
    fovOut.textContent = settings.fov;
    fov.oninput = () => {
        settings.fov = +fov.value;
        fovOut.textContent = settings.fov;
        player.baseFov = settings.fov;
        saveSettings();
    };

    const qual = $('qualitySel');
    qual.value = String(settings.quality);
    qual.onchange = () => {
        settings.quality = +qual.value;
        // A hand-picked preset stops the auto-tuner overriding the choice.
        autoQualityLocked = true;
        settings.qualityManual = true;   // remembered across visits
        applyQuality();
        saveSettings();
    };

    canvas.addEventListener('click', () => {
        // A click that lands on the canvas through a menu is the menu being
        // clicked, not the player asking for the mouse back.
        if (state === 'playing' && !menuOpen() && !document.pointerLockElement) grabPointer();
    });
    document.addEventListener('pointerlockchange', () => {
        const locked = document.pointerLockElement === canvas;
        if (player) player.locked = locked;
        document.body.classList.toggle('playing', locked && !menuOpen());
        if (!locked && state === 'playing' && player.alive && !menuOpen()) pause(true);
    });
    window.addEventListener('keydown', e => {
        if (e.code === 'Escape') {
            if (diffGateOpen()) { hideDiffGate(); return; }
            if ($('howTo').style.display === 'flex') { $('howTo').style.display = 'none'; return; }
            if ($('panel').style.display === 'flex') { $('panel').style.display = 'none'; return; }
            if (state === 'playing') pause(true);
            else if (state === 'paused') pause(false);
        }
        if (e.code === 'Tab' && state === 'playing') { e.preventDefault(); boardOpen = true; }
        if (e.code === 'KeyF') $('perfHud').classList.toggle('hidden');
        // Killstreak keys, read off the same table the HUD chips print their hint
        // from. They used to be advertised on the chips and bound nowhere: you
        // earned the UAV, pressed its key, and nothing happened — the reward looked
        // broken. One table, one binding, and `e.repeat` so holding it does not
        // spam the not-ready banner.
        if (state === 'playing' && !e.repeat && !menuOpen()) {
            for (const st of STREAKS) {
                if (e.code !== st.key) continue;
                e.preventDefault();
                tryStreak(st.id);
                break;
            }
        }
        // Free roam owns the movement keys while it is up — Space is "fly", not
        // "jump", and A/D strafe instead of changing who you watch. `J`/`K` and a
        // right-click are the only way to hop to another operator.
        if (roam.active) {
            if (ROAM_KEYS.has(e.code)) {
                roam.key(e.code, true);
                e.preventDefault();          // Space would scroll the page, Tab the UI
            }
            if (e.code === 'KeyJ') cycleFocus(1);
            else if (e.code === 'KeyK') cycleFocus(-1);
        }
    });
    window.addEventListener('keyup', e => { if (roam.active && ROAM_KEYS.has(e.code)) roam.key(e.code, false); });

    // In free roam the mouse is for looking, so the focus jump lives on the right
    // button. Bound on the canvas so it does not fire when the skip button is used.
    canvas.addEventListener('mousedown', e => {
        if (state !== 'playing' || !roam.active) return;
        if (e.button === 2) cycleFocus(1);
        else if (e.button === 1) cycleFocus(-1);
    });
    // The player's own look handler bails while it is dead, which is exactly when
    // the roam camera needs these deltas.
    window.addEventListener('mousemove', e => {
        if (!roam.active || document.pointerLockElement !== canvas || player.paused) return;
        roam.look(Math.max(-LOOK_CLAMP, Math.min(LOOK_CLAMP, e.movementX || 0)),
                  Math.max(-LOOK_CLAMP, Math.min(LOOK_CLAMP, e.movementY || 0)), settings.sens);
    });

    $('skipRound').addEventListener('click', skipRoundNow);
    window.addEventListener('keyup', e => { if (e.code === 'Tab') boardOpen = false; });
    // Keys the roam camera swallows. Anything else still reaches the normal
    // handlers, so the scoreboard and the perf strip work mid-flight.
    const ROAM_KEYS = new Set(['KeyW', 'KeyA', 'KeyS', 'KeyD', 'Space', 'KeyC', 'KeyE', 'KeyQ',
        'ShiftLeft', 'ShiftRight', 'ControlLeft', 'ControlRight', 'ArrowUp', 'ArrowDown',
        'ArrowLeft', 'ArrowRight']);

    window.addEventListener('resize', onResize);
    if (IS_TOUCH) {
        // A phone changes shape without a resize: the URL bar slides away, the
        // toolbar comes back, iOS reports the old size for a beat after a rotation,
        // and going fullscreen swaps the whole rectangle for the locked one. None of
        // those are a window resize on every browser, so listen to the things that
        // actually move and re-measure on all of them.
        const vv = window.visualViewport;
        if (vv) { vv.addEventListener('resize', onResize); vv.addEventListener('scroll', onResize); }
        window.addEventListener('orientationchange', () => {
            onResize();
            setTimeout(onResize, 250);       // iOS: the new size lands late
            setTimeout(onResize, 700);
        });
        document.addEventListener('fullscreenchange', () => { onResize(); setTimeout(onResize, 250); });
        document.addEventListener('visibilitychange', () => { if (!document.hidden) onResize(); });
        document.addEventListener('focusout', () => setTimeout(onResize, 350));
    }
}

/**
 * Fit the drawing buffer and every full-screen layer to the rectangle the device
 * is really showing. Cheap to call and safe to call often: the layers are sized by
 * the CSS variable, and the expensive part — reallocating the post-processing
 * targets — only happens when the numbers actually changed.
 */
let menuAcc = 0;
const typing = () => { const a = document.activeElement; return !!a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA'); };
function onResize() {
    const vs = IS_TOUCH ? viewportSize() : null;
    const w = vs ? vs.w : window.innerWidth, h = vs ? vs.h : window.innerHeight;
    if (vs) applyViewportVars(h);
    if (typing()) return;   // on-screen keyboard: re-allocating the render targets per frame is what froze the name prompt
    if (w === lastW && h === lastH && curDpr === lastDpr) return;
    lastW = w; lastH = h; lastDpr = curDpr;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setPixelRatio(curDpr);
    renderer.setSize(w, h);
    composerFX.setSize(w * curDpr, h * curDpr);
    vm.resize(w / h);
}

/**
 * Hold 60 fps by scaling render resolution rather than dropping frames.
 * Reacts down quickly (1 s) and back up slowly (3 s) so it settles instead of
 * oscillating around the threshold.
 */
function adaptResolution(dt) {
    frameAvg += (dt * 1000 - frameAvg) * 0.06;
    // A quality the player picked by hand is final: never lower it (or the
    // resolution) automatically, even if the frame rate drops.
    const manual = autoQualityLocked || settings.qualityManual;   // resolution still adapts; the preset stays put
    dprCooldown -= dt;
    if (dprCooldown > 0) return;

    // Resolution is the first lever.
    let next = curDpr;
    if (frameAvg > 17.5 && curDpr > DPR_FLOOR) { next = Math.max(DPR_FLOOR, curDpr - 0.12); dprCooldown = 1.0; }
    else if (frameAvg < 12.5 && curDpr < maxDpr) { next = Math.min(maxDpr, curDpr + 0.10); dprCooldown = 3.0; }
    if (next !== curDpr) {
        curDpr = next;
        frameAvg = 15;
        onResize();
        return;
    }
    if (manual) return;

    // Already at the floor and still missing the budget: resolution alone
    // cannot save this machine, so step the whole preset down. Shadow map size
    // and post effects only change with the preset, and on a weak GPU those are
    // what is actually costing the frame.
    if (curDpr <= DPR_FLOOR + 1e-6 && frameAvg > 19 && settings.quality > 0) {
        settings.quality--;
        applyQuality();
        saveSettings();
        hud.banner(`Quality lowered to ${QUALITY[settings.quality].name}`, '#FFC24A', 'holding frame rate');
        frameAvg = 15;
        dprCooldown = 6.0;
        qualityHeadroom = 0;
        return;
    }

    // The opposite case: running comfortably at full resolution with room to
    // spare. Step the preset back up so a capable machine is not left on Low
    // forever. Needs a sustained stretch of easy frames, and a long cooldown,
    // so this cannot ping-pong against the rule above.
    // The ladder is allowed to make this tab cheaper, never dearer: in safe mode
    // a quiet stretch of frames is not a licence to ask the driver for the
    // shadows back.
    if (!safeGfx && !autoQualityLocked && curDpr >= maxDpr - 1e-6 && frameAvg < 11 && settings.quality < QUALITY.length - 1) {
        qualityHeadroom += dprCooldownStep;
        if (qualityHeadroom > 8) {
            settings.quality++;
            applyQuality();
            saveSettings();
            hud.banner(`Quality raised to ${QUALITY[settings.quality].name}`, '#7FD97F', 'plenty of headroom');
            qualityHeadroom = 0;
            dprCooldown = 10.0;
        }
    } else {
        qualityHeadroom = 0;
    }
}

function applyQuality() {
    const q = QUALITY[settings.quality] || QUALITY[1];
    sun.shadow.mapSize.set(q.shadow, q.shadow);
    if (sun.shadow.map) { sun.shadow.map.dispose(); sun.shadow.map = null; }
    sun.shadow.autoUpdate = false;
    sun.shadow.needsUpdate = true;

    // Shadow filter cost varies enormously: PCFSoft takes many taps per pixel,
    // Basic takes one. This is one of the largest single levers available.
    if (renderer.shadowMap.type !== q.shadowType) {
        renderer.shadowMap.type = q.shadowType;
        scene.traverse(o => { if (o.isMesh && o.material) o.material.needsUpdate = true; });
    }

    // Interior fill lights are point lights, and every point light is evaluated
    // per pixel by every lit material on screen — indoors and out. Below High
    // the rooms lean on the sun, sky and environment map instead.
    let lightsChanged = false;
    scene.traverse(o => {
        if (!o.isLight) return;
        let want = o.visible;
        if (o.userData.interiorFill) want = q.interiorLights;
        else if (o.userData.fxLight) want = settings.quality > 0;
        if (o.visible !== want) { o.visible = want; lightsChanged = true; }
    });
    if (lightsChanged) scene.traverse(o => { if (o.isMesh && o.material) o.material.needsUpdate = true; });

    // Character shadows mean re-skinning every soldier a second time.
    charShadowsEnabled = q.charShadows;

    // keep the dropdown honest when the auto-tuner moves the preset
    const sel = $('qualitySel');
    if (sel && sel.value !== String(settings.quality)) sel.value = String(settings.quality);

    // A phone's screen is small, bright and often 2x-or-3x: past ~1.5 device
    // pixels per CSS pixel nobody can see the extra detail and the GPU pays for it
    // in fill rate, which is the one budget a phone does not have.
    maxDpr = Math.min(q.dprCap, Math.max(1, DEVICE_DPR), IS_TOUCH ? 1.5 : Infinity);
    // Jump straight to the new ceiling so picking a higher preset looks better
    // immediately; the adaptive scaler pulls it back within a second if the
    // frame budget cannot take it.
    curDpr = maxDpr;
    frameAvg = 15;
    dprCooldown = 1.5;
    composerFX.setQuality(q.post);
    onResize();
}

// ── match flow ──────────────────────────────────────────────────────────────
function startMatch() {
    // A fresh match is a fresh deal of the spawn table.
    resetDeploySpread();
    // Starting a match from the keyboard while the ask is still up (Enter reaches
    // Deploy) is an answer too: it means Medium, and it is remembered, so the
    // gate does not come back next visit to ask a question that was answered.
    if (!isDifficulty(settings.difficulty)) setDifficulty(DEFAULT_DIFFICULTY);
    $('menu').style.display = 'none';
    $('panel').style.display = 'none';
    $('howTo').style.display = 'none';
    hud.hideEnd(); hud.hideDeath();
    killChain.reset();
    hud.clearMedals();
    hud.streakRun(0);
    $('pause').classList.remove('on');
    hud.show(true);

    // Build the ruleset for the chosen playlist. Everything below asks the mode
    // how many soldiers to field and whether respawning is allowed, instead of
    // assuming Team Deathmatch.
    gamemode = createMode(selectedMode, {
        player, getBots: () => bots, hud, effects, scene, audio: A
    });
    gamemode.reset();
    shop.beginMatch({ player, vm, scene, roam });
    // The armory is the default; a mode that owns your weapon (Gun Game) locks it
    // to one gun from its own onMatchStart. Cleared here so a match after a Gun
    // Game does not inherit the lock and leave you holding a pistol forever.
    if (player.setLoadout) player.setLoadout(null);
    // Hands the HUD the ruleset: it labels the mode line, takes the score limit
    // from the mode (Round Control wins at 3 rounds, not 75 kills) and hides the
    // streak row for modes that do not use killstreaks. Nothing used to call this.
    hud.setMode(gamemode);
    // Build the viewmodels this mode can actually hand you. In Gun Game that is
    // four guns instead of fifteen, which is eleven fewer model built, uploaded and
    // kept in memory for a match where you could never hold them.
    if (gamemode.warmGuns && vm.queueOnly) vm.queueOnly(gamemode.warmGuns);
    else vm.queueAll();
    streaks.reset();
    if (airdrop) airdrop.reset();
    if (vault) vault.reset();
    effects.clearHoles();
    if (effects.clearParticles) effects.clearParticles();

    for (const b of bots) b.dispose();
    bots = [];

    const nA = gamemode.botsA, nB = gamemode.botsB;
    const namesA = shuffle(BOT_NAMES_A).slice(0, nA);
    const namesB = shuffle(BOT_NAMES_B).slice(0, nB);
    // A mode with no teams must not have a "your team" at all. The roster is
    // still split in two for names and spawn spread, but every soldier wears the
    // enemy side — because the player's weapon skips same-team bodies (no
    // friendly fire) and the radar paints them blue. Free For All used to keep
    // three of the eight on your side, which is exactly the bunch you could
    // neither hit nor spot.
    const asEnemy = !!gamemode.noTeams;
    // Skill used to be one roll for everyone, so "harder" was not a thing the
    // player could ask for. The band comes from difficulty.js and the aim,
    // reaction and miss-spread scales go on the bot with it.
    const diff = diffEntry();
    for (let i = 0; i < nA; i++) {
        const b = new Bot(namesA[i], asEnemy ? TEAM_B : TEAM_A, scene, rollSkill(diff));
        applyDifficulty(b, diff);
        b.spawn(); bots.push(b);
    }
    for (let i = 0; i < nB; i++) {
        const b = new Bot(namesB[i], TEAM_B, scene, rollSkill(diff));
        applyDifficulty(b, diff);
        b.spawn(); bots.push(b);
    }

    // Bots bring their own materials with them. Nobody is moving during the
    // opening freeze, so this is the cheap moment to have them compiled.
    warmShaders();

    player.resetMatch();
    // The hitscan rule has to match the bots' (ai.js isHostile) or the two sides
    // disagree about who is fair game; the mode owns that answer.
    player.allHostile = asEnemy;
    // Claimed, not just chosen: the spawn table must know a live player is
    // standing on this one, or the next bot it hands out lands at your feet.
    player.respawn(claimPoint(randElement(SPAWN_A), TEAM_A, 3));
    // The chosen LOADOUT: primary + secondary + one grenade type. Gun Game keeps
    // ownership of the guns (it sets its own one-gun loadout at kickoff).
    loadout.applyToMatch(player, { weapons: selectedMode !== 'gun' });
    player.sensitivity = 0.0016 * settings.sens;
    player.baseFov = settings.fov;
    player.paused = false;
    respawnTimer = 0;
    deadInfo = null;
    exitFreeRoam();        // a fresh match starts in your own body, not in the air

    state = 'playing';
    grabPointer();
    A.playAmbient();
    // The mode opens its own match. This used to be a hard-coded "TEAM DEATHMATCH
    // — First to 75" banner, so Round Control, Free For All and Gun Game each
    // announced the wrong rules at kickoff, and because nothing called
    // onMatchStart() Round Control never numbered its first round (the HUD read
    // ROUND 0) and Gun Game never put you on the first gun.
    cine.init({ camera, hud, audio: A, player: () => player, bots: () => bots,
        playerName: () => player.name || callsign(), teamA: TEAM_A });
    const mi = MODES.find(m => m.id === selectedMode);
    cine.intro({
        modeName: mi && mi.name,
        onGo: () => { A.playMatchStart(); player.spawnProtect = Math.max(player.spawnProtect, 2); if (gamemode.onMatchStart) gamemode.onMatchStart(); }
    });
}

function toMenu() {
    cine.cancel();
    if (state !== 'ended' && window.NTLB && player) window.NTLB.submit({ mode: selectedMode, kills: player.matchKills, deaths: player.deaths, won: false }, true);
    state = 'menu';
    exitFreeRoam();
    hud.show(false);
    hud.hideDeath();
    hud.hideEnd();
    $('pause').classList.remove('on');
    $('menu').style.display = 'flex';
    releaseCursor();
    player.paused = true;
    // The streaks own things that outlive a match unless they are told to stop:
    // the nuke whiteout and bloom are graded every frame from streak state, the
    // countdown overlay is only ever cleared by the flash that follows it, and
    // and the smoke from the blast keeps drifting. Quitting mid-nuke used to leave the menu
    // behind a white fog with "5" in the middle of it.
    if (streaks) streaks.reset();
    if (airdrop) airdrop.reset();
    if (vault) vault.reset();
    if (effects.clearParticles) effects.clearParticles();
    if (hud.abortNuke) hud.abortNuke();
}

function pause(on) {
    if (state !== 'playing' && state !== 'paused') return;
    state = on ? 'paused' : 'playing';
    player.paused = on;
    $('pause').classList.toggle('on', on);
    if (on) releaseCursor();
    else grabPointer();
}

function endMatch() {
    if (state === 'ended') return;
    state = 'ended';
    player.paused = true;
    releaseCursor();
    if (streaks) streaks.reset();
    if (airdrop) airdrop.reset();
    if (vault) vault.reset();
    if (effects.clearParticles) effects.clearParticles();
    if (hud.abortNuke) hud.abortNuke();
    hud.hideDeath();
    // The result card is the end of the flight: give the camera back so the frozen
    // last frame is the game's own view, and so nothing keeps integrating movement
    // behind a full-screen overlay.
    exitFreeRoam();
    const won = gamemode.winner === TEAM_A;
    hud.showEnd(won, player);
    shop.endMatch(won, player);
    if (window.NTLB) window.NTLB.submit({ mode: selectedMode, kills: player.matchKills, deaths: player.deaths, won });
    (won ? A.playVictory : A.playDefeat)();
}

// ── combat callbacks ────────────────────────────────────────────────────────
function onPlayerHit(bot, killed, head, def) {
    hud.hitmarker(killed, head);
    if (bot.isVaultFoe) { if (killed) A.playKillConfirm(); else head ? A.playHeadshot() : A.playHitmarker(); return; }
    if (killed) {
        A.playKillConfirm();
        registerKill(bot, def.short, head, false);
    } else {
        head ? A.playHeadshot() : A.playHitmarker();
    }
}

function onGrenadeHit(bot, killed, label) {
    hud.hitmarker(killed, false);
    if (killed) { A.playKillConfirm(); registerKill(bot, label, false, false); }
}

function registerKill(bot, weaponLabel, head, fromStreak) {
    player.kills++;
    shop.onKill({ head, type: fromStreak ? null : (player.def && player.def.type), label: weaponLabel,
        streak: player.killStreak + 1, matchKills: player.matchKills + 1 });
    cine.noteKill({ byPlayer: true, killerName: player.name || callsign(), victim: bot, victimName: bot.name,
        weapon: weaponLabel, head, killerPos: camera.position.clone() });
    player.matchKills++;
    if (window.NTLB) window.NTLB.live(selectedMode, player.matchKills, player.deaths);
    player.killStreak++;
    player.score += head ? 150 : 100;
    // One path, not two. main used to call gamemode.addKill() here and onKill()
    // for bot kills, which (a) counted a bot-vs-bot kill twice against the team
    // tally, (b) handed Round Control a round win every third player kill, since
    // that mode scores rounds through the same tally, and (c) meant a *player*
    // kill never reached the mode at all — so in Gun Game you could never move up
    // a gun and in Free For All you could never reach 200. Modes decide what a
    // kill is worth; main just reports it.
    gamemode.onKill(player, bot, player.def || { short: weaponLabel, name: weaponLabel }, head);
    hud.killfeed(player.name || callsign(), bot.name, weaponLabel, true, head);

    // The stack over the crosshair says what the kill was; the feed on the right
    // says who it was. A reward that came off a streak (nukes, airstrikes) still
    // earns the kill but keeps the milestone banners to itself.
    const chain = killChain.note(performance.now() / 1000, head, player.killStreak);
    if (!fromStreak) hud.medals(chain.medals);
    hud.streakRun(player.killStreak,
        milestoneFor(player.killStreak)?.label,
        milestoneProgress(player.killStreak));

    // announce newly available rewards
    for (const s of ['air', 'nuke']) {
        const p = streaks.progress(s);
        if (p.ready && !streaks.announced?.[s]) {
            streaks.announced = streaks.announced || {};
            streaks.announced[s] = true;
            const meta = { air: ['AIRSTRIKE READY', '#ffb02e', 'Press X'], nuke: ['☢ TACTICAL NUKE READY ☢', '#FF3B15', 'Press V to wipe them out'] }[s];
            hud.banner(meta[0], meta[1], meta[2]);
        }
    }
}

function onPlayerDeath(killerName) {
    A.playDeath();
    // A streak is only worth anything because it can be lost, so say so when it
    // was long enough to matter.
    if (player.killStreak >= 3) {
        hud.banner(`STREAK LOST ×${player.killStreak}`, '#FF4D4D', 'Reset by ' + (killerName || 'the map'));
    }
    killChain.reset();
    hud.clearMedals();
    hud.streakRun(0);
    streaks.onPlayerDeath();
    streaks.announced = {};
    respawnTimer = RESPAWN_TIME;
    deadInfo = { by: killerName || '—' };
    hud.showDeath(deadInfo.by, deadInfo.weapon || '');
    hud.respawnCountdown(respawnTimer, RESPAWN_TIME);
    // Pointer lock stays: the death camera should keep pointing where the fall
    // put it, and releasing the mouse here would pop the cursor over the screen.
}

function tryStreak(id) {
    if (state !== 'playing' || !player.alive) return;
    if (!streaks.canUse(id)) {
        const p = streaks.progress(id);
        const label = (STREAKS.find(x => x.id === id) || {}).label || 'THAT REWARD';
        // Never silent. Two passes at this used to do nothing and say nothing,
        // which is indistinguishable from a broken key: a reward the ruleset
        // forbids, and a reward you already spent this life.
        if (!p.enabled)
            hud.banner(`${label} OFF IN THIS MODE`, 'rgba(255,255,255,.6)', 'This ruleset does not allow it');
        else if (streaks.used[id])
            hud.banner(`${label} ALREADY USED`, 'rgba(255,255,255,.6)', 'One per life — it re-arms when you die');
        else
            hud.banner('NOT READY', 'rgba(255,255,255,.6)', `${p.have}/${p.need} kills`);
        return;
    }
    streaks.use(id);
}

/**
 * Trying to change weapons in a one-gun mode. Throttled, because the natural
 * reaction to being handed a shotgun is to mash 1-4 and Q.
 */
let _refusedAt = -1e9;
function refuseSwapHint() {
    const now = performance.now();
    if (now - _refusedAt < 2500) return;
    _refusedAt = now;
    const gg = gamemode && gamemode.killTarget ? `${gamemode.killTarget} kills wins` : 'the ladder moves you on a kill';
    hud.banner('ONE GUN AT A TIME', '#FFC24A', gg);
}

// ── bot event handling ──────────────────────────────────────────────────────
function handleBotEvents(bot, events) {
    for (const e of events) {
        if (e.type === 'shot') {
            const d = e.position.distanceTo(camera.position);
            if (Number.isFinite(d)) {
                if (d < 4) A.playGunshot(bot.weapon.audioType);
                else A.playGunshotDistant(bot.weapon.audioType, d);
                if (d < 30) effects.gunFlash(e.position);
            }
            if (gamemode.noTeams || bot.team !== TEAM_A) hud.noteEnemyFire(bot);
        } else if (e.type === 'miss') {
            effects.tracer(e.from, e.to, 300);
            if (e.normal) effects.impact(e.to, e.normal, 'default');
        } else if (e.type === 'hit') {
            effects.tracer(e.from, e.to, 300);
            const tgt = e.target;
            if (tgt === playerProxy) {
                // No world blood here — the hit point is the player's own chest,
                // which would paint a red billboard across the camera.
                player.takeDamage(e.damage, bot.name, e.from);
                if (!player.alive) {
                    cine.noteKill({ killerPos: e.from.clone(), killerName: bot.name, victim: player, victimIsPlayer: true,
                        victimName: player.name || callsign(), weapon: bot.weapon.short, head: e.head });
                    gamemode.onKill(bot, playerProxy, bot.weapon, e.head);
                    bot.kills++; bot.killStreak++; bot.score += 100;
                    hud.killfeed(bot.name, player.name || callsign(), bot.weapon.short, false, e.head);
                    deadInfo = { by: bot.name, weapon: bot.weapon.name };
                    hud.showDeath(bot.name, bot.weapon.name);
                }
            } else if (tgt && tgt.takeDamage) {
                effects.blood(e.to, _v.set(0, 0, 0));
                const killed = tgt.takeDamage(e.damage, bot.name);
                if (killed) {
                    cine.noteKill({ killerPos: e.from.clone(), killerName: bot.name, victim: tgt,
                        victimName: tgt.name, weapon: bot.weapon.short, head: e.head });
                    gamemode.onKill(bot, tgt, bot.weapon, e.head);
                    gamemode.onBotDeath(tgt);
                    bot.kills++; bot.killStreak++; bot.score += 100;
                    hud.killfeed(bot.name, tgt.name, bot.weapon.short, false, e.head);
                }
            }
        }
    }
}

// ── free roam (round modes) ─────────────────────────────────────────────────
// Killed with no respawn left? You do not inherit a teammate's eyes — you leave
// your body and fly. Counter-Strike has let a dead player drift around the map
// since forever, and for good reason: it is the only spectator mode that never
// breaks, because there is no camera to thread through a doorway behind someone.
// All the movement maths lives in freeroam.js; everything here is the handover —
// who owns the camera, when, and which keys reach it.
const roam = createFreeRoam();
const LOOK_CLAMP = 180;         // px per mouse event, the same spike guard the player uses

function roamName() { return roam.watching ? roam.watching.name : ''; }

/** Who `J` can jump to: everyone still standing, both teams. */
function roamTargets() {
    return bots.filter(b => b.alive && b !== playerProxy).sort((x, y) => x.name.localeCompare(y.name));
}

/** The Round Control skip, from either the HUD button or the touch one. */
function skipRoundNow() {
    if (gamemode.skipRound && gamemode.skipRound()) {
        hud.banner('ROUND SKIPPED', '#FFC24A', 'Next round starting');
        exitFreeRoam();
    }
}

function exitFreeRoam() {
    if (!roam.active) return;
    roam.exit(camera);
    hud.freeRoam(false);
}

/** Cycle the focus jump. `dir` 0 re-frames whoever we are already watching. */
function cycleFocus(dir = 1) {
    const list = roamTargets();
    if (!list.length) { roam.watching = null; hud.freeRoam(true, '', deadInfo && deadInfo.by); return; }
    const i = list.indexOf(roam.watching);
    const next = list[(((i < 0 ? -1 : i) + dir) % list.length + list.length) % list.length];
    roam.focusOn(next, camera);   // method — it records the target on roam.watching
    hud.freeRoam(true, next.name, deadInfo && deadInfo.by);
}

function updateFreeRoam(dt = 0.016) {
    roamTicks++;
    // The death collapse owns the camera for its first second. Lifting off early
    // is the difference between "I died and flew" and "my view glitched".
    if (!player.alive && player.deathProgress < 1) return;
    if (!roam.active) {
        roam.enter(camera);
        // The big red card has done its job — you know who got you, and the strip
        // at the bottom keeps saying it. Now let you see the map you are flying over.
        hud.hideDeath();
        hud.freeRoam(true, '', deadInfo && deadInfo.by);
    }
    if (state === 'playing' && !player.paused) roam.update(dt, camera);
}

// A lightweight stand-in so bots can treat the player like any other entity.
const playerProxy = {
    position: new THREE.Vector3(), alive: true, team: TEAM_A, isCrouching: false,
    name: callsign(), spawnProtect: 0,
    takeDamage() { return false; }
};

// ── loop ────────────────────────────────────────────────────────────────────
function loop(ts) {
    requestAnimationFrame(loop);
    if (glLost) return;            // the card on screen already says what happened
    const _info = renderer.info.render;
    frameStats.calls = _info.calls;
    frameStats.triangles = _info.triangles;
    renderer.info.reset();
    const rdt = Math.min((ts - last) / 1000, 0.05) || 0;
    const dt = rdt * cine.timeScale();   // slow motion on the final kill
    last = ts;
    elapsed += dt;

    if (sky && sky.material.uniforms) sky.material.uniforms.time.value = elapsed;

    if (state === 'menu' || state === 'loading') {
        if (typing() || diffGateOpen()) return;         // the gate is 90% opaque: do not render the map behind it
        menuAcc += dt; if (menuAcc < 1 / 30) return; menuAcc = 0;   // menu backdrop at 30 fps
        // slow cinematic orbit over the map
        const t = elapsed * 0.09;
        camera.position.set(Math.cos(t) * 46, 17 + Math.sin(t * 0.7) * 5, Math.sin(t) * 40);
        camera.lookAt(Math.sin(t * 0.5) * 6, 4.5, Math.cos(t * 0.5) * 4);
        camera.fov = 62; camera.updateProjectionMatrix();
        if (composerFX) {
            composerFX.vmPass.enabled = false;
            composerFX.grade.uniforms.time.value = elapsed;
            composerFX.composer.render();
        }
        return;
    }

    // The touch HUD mirrors state into player.touch before anything reads it, and
    // hides itself the moment a menu is on screen. It runs before the paused and
    // ended branches below rather than after them, because those two return: a
    // phone that paused mid-match kept a full set of live-looking buttons over the
    // pause card, and the fire button was still lit when the match ended. No-op on
    // a desktop.
    if (touchCtl) {
        touchCtl.frame();
        if (player) player.locked = !menuOpen();
    }

    if (state === 'paused') { composerFX.composer.render(); return; }

    if (state === 'ended') {
        effects.update(dt, camera);
        composerFX.grade.uniforms.time.value = elapsed;
        composerFX.composer.render();
        return;
    }

    // ── playing ──
    // the viewmodel is not drawn once the death camera takes over
    composerFX.vmPass.enabled = player.alive && !cine.hideVM();
    adaptResolution(dt);
    // Building a viewmodel and letting the GPU compile and upload it is 10-20 ms
    // of work that used to land on the frame you pressed a number key, which is the
    // "the game stopped for a second and then the gun changed" that a switch felt
    // like. It happens here instead, one weapon per call, and only when the frames
    // are already fast enough to absorb it.
    if (frameAvg < 15) vm.prebuild(renderer, 6);

    // Shadows only need refreshing every other frame; at 60 fps the lag is
    // invisible and it halves the cost of the most expensive pass.
    const q = QUALITY[settings.quality] || QUALITY[1];
    shadowTick = (shadowTick + 1) % q.shadowEvery;
    sun.shadow.needsUpdate = (shadowTick === 0);

    const nowSec = ts / 1000;

    if (!cine.introActive()) gamemode.update(dt);
    streaks.update(dt);
    shop.poll(streaks);

    // During a round's frozen setup nobody may move or shoot.
    const frozen = (gamemode.isFrozen && gamemode.isFrozen()) || cine.frozen();
    player.paused = frozen;
    airdrop.update(dt, !frozen && !cine.introActive() && !gamemode.matchOver);
    vault.update(dt, !frozen && !cine.introActive() && !gamemode.matchOver);

    if (player.alive) {
        if (roam.active) exitFreeRoam();
        player.update(dt, nowSec);
        if (!frozen) player.tryFire(nowSec);
    } else if (!gamemode.canRespawn(player)) {
        // Round modes own the respawn cycle: the player stays down until the
        // round flips. Rather than stare at the sky, ride a surviving
        // teammate's eyes until then.
        player.update(dt, nowSec);
        updateFreeRoam(dt);
    } else {
        player.update(dt, nowSec);
        respawnTimer -= dt;
        hud.respawnCountdown(respawnTimer, RESPAWN_TIME);
        if (respawnTimer <= 0 && !cine.busy()) {
            player.respawn(pickSafeSpawn());
            hud.hideDeath();
            exitFreeRoam();
            grabPointer();
        }
    }

    grenades.update(dt);
    melee.update(dt);

    // keep the bot-facing view of the player current
    playerProxy.position.copy(player.position);
    playerProxy.alive = player.alive;
    playerProxy.isCrouching = player.isCrouching;
    playerProxy.spawnProtect = player.spawnProtect;

    const entities = [playerProxy, ...bots];
    for (const bot of bots) {
        bot.respawnBlocked = !gamemode.canRespawn(bot) || cine.busy();
        bot.frozen = frozen;
        const ev = bot.update(dt, ts, entities, cw, charShadowsEnabled ? camera.position : null);
        if (!charShadowsEnabled && bot.rig.setShadows) bot.rig.setShadows(false);
        if (ev && ev.length) handleBotEvents(bot, ev);
    }

    effects.update(dt, camera);

    // sun shadow box follows the player so shadows stay crisp
    sun.position.set(player.position.x - 52, 68, player.position.z + 34);
    sun.target.position.set(player.position.x, 0, player.position.z);
    sun.target.updateMatrixWorld();

    // drifting dust
    if (dust) {
        dust.position.x = player.position.x;
        dust.position.z = player.position.z;
        dust.rotation.y = elapsed * 0.008;
    }

    // HUD
    hud.update(dt, {
        player, bots,
        // the live mode object, every frame: the HUD decides which panels belong to
        // a mode (team bars in a teamless one, round pips in Round Control) from
        // this, so it cannot be left holding a mode from the previous match
        mode: gamemode,
        teamA: gamemode.teamAScore, teamB: gamemode.teamBScore,
        timeLeft: gamemode.timeRemaining,
        killstreaks: streaks,
        scopeAmount: vm.scopeAmount
    });
    hud.scope(vm.scopeAmount || 0);
    hud.scoreboard(boardOpen, player, bots, gamemode.teamAScore, gamemode.teamBScore, gamemode);

    // grade uniforms
    const g = composerFX.grade.uniforms;
    g.time.value = elapsed;
    // The grade is match state. Left running on the menu it holds the last frame
    // of the fight — the nuke wash, the red of low health, the death fade — over
    // everything you then try to read.
    const graded = state === 'playing' || state === 'paused';
    g.damage.value = graded ? clamp((1 - player.health / 100) * 0.5, 0, 0.5) * (player.alive ? 1 : 0) : 0;
    g.death.value = graded ? player.deathProgress * 0.82 : 0;
    g.whiteout.value = graded && streaks.nukeFired
        ? clamp(1 - (streaks.nukeT - 5.0) / 2.2, 0, 1) : 0;
    composerFX.bloom.strength = 0.34 + (graded && streaks.nukeFired ? 1.4 : 0) * g.whiteout.value;

    // live fps readout — settings panel and the on-screen perf strip
    fpsAccum += dt; fpsFrames++;
    if (fpsAccum >= 0.5) {
        const fps = Math.round(fpsFrames / fpsAccum);
        const el = $('fpsOut');
        if (el) el.textContent = fps + ' fps';
        const strip = $('perfHud');
        if (strip && !strip.classList.contains('hidden')) {
            const cls = fps >= 55 ? '' : fps >= 40 ? 'mid' : 'bad';
            strip.innerHTML = `<b class="${cls}">${fps} FPS</b> · ${frameStats.calls} draws · ` +
                `${(frameStats.triangles / 1000).toFixed(0)}k tris · ${(curDpr * 100).toFixed(0)}% res · ` +
                `${QUALITY[settings.quality].name}`;
        }
        fpsAccum = 0; fpsFrames = 0;
    }

    cine.update(rdt);
    cine.applyCamera();
    // The match ends on the mode's own limit; the ending sequence plays first, then the result card.
    if (gamemode.matchOver && !(streaks && streaks.nukeActive)) cine.finale(endMatch);

    composerFX.composer.render();
}

/** Prefer a spawn no enemy is standing on top of. */
function pickSafeSpawn() {
    const list = SPAWN_A;
    let best = list[0], bestD = -1;
    for (const s of list) {
        let nearest = 1e9;
        for (const b of bots) {
            // In a solo mode everyone in the lobby is an enemy, so everyone is a
            // reason to pick a different spawn.
            if (!b.alive || (!gamemode.noTeams && b.team === TEAM_A)) continue;
            nearest = Math.min(nearest, Math.hypot(b.position.x - s.x, b.position.z - s.z));
        }
        if (nearest > bestD) { bestD = nearest; best = s; }
    }
    return claimPoint(best, TEAM_A, 3);
}

void MAP_BOUNDS; void SPAWN_B; void WEAPON_DEFS; void TEAM_B;

boot().catch(err => {
    console.error('[boot]', err);
    if (err && err.handled) return;       // the card is already up, with the right words on it
    showBootError('The game could not start', String((err && err.message) || err));
});
