-- Run this in Supabase SQL Editor (after the first setup). Totals across ALL matches per player.
create or replace view public.leaderboard_all as
  select min(name) as name, sum(kills)::int as kills, sum(deaths)::int as deaths,
         (count(*) filter (where won))::int as wins, count(*)::int as matches
  from public.scores group by lower(name);

create or replace view public.leaderboard_modes as
  select min(name) as name, mode, sum(kills)::int as kills, sum(deaths)::int as deaths,
         (count(*) filter (where won))::int as wins, count(*)::int as matches
  from public.scores group by lower(name), mode;

grant select on public.leaderboard_all, public.leaderboard_modes to anon, authenticated;
