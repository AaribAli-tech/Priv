Want your own music? Drop MP3 files in this folder with these exact names:
  loading.mp3   - plays on the loading screen
  menu.mp3      - plays on the main menu
  game.mp3      - plays during matches
Any file that is missing falls back to the built-in synthesized music.
Only use music you own or that is royalty-free (e.g. pixabay.com/music, incompetech.com).
