/* NUKETOWN music: loading / menu / in-game. Uses /audio/*.mp3 if present, else synthesizes its own. */
(function () {
  var FILES = { loading: '/audio/loading.mp3', menu: '/audio/menu.mp3', game: '/audio/game.mp3' };
  var VOL = { loading: 0.5, menu: 0.5, game: 0.32 };
  var have = {}, ctx = null, master = null, cur = null, want = null, unlocked = false, muted = false;
  try { muted = localStorage.getItem('nuketown.mute') === '1'; } catch (e) {}

  // ---- which files exist? ----
  Object.keys(FILES).forEach(function (k) {
    fetch(FILES[k], { method: 'HEAD' }).then(function (r) {
      have[k] = r.ok && /audio|octet/.test(r.headers.get('content-type') || '');
    }).catch(function () { have[k] = false; });
  });

  // ---- synthesized fallback ----
  var N = function (m) { return 440 * Math.pow(2, (m - 69) / 12); };
  function osc(type, f, t0, dur, vol, dest, lp) {
    var o = ctx.createOscillator(), g = ctx.createGain(), n = dest;
    o.type = type; o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, t0); g.gain.linearRampToValueAtTime(vol, t0 + Math.min(0.03, dur / 4));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    if (lp) { var fl = ctx.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = lp; o.connect(fl); fl.connect(g); }
    else o.connect(g);
    g.connect(n); o.start(t0); o.stop(t0 + dur + 0.05);
  }
  function noise(t0, dur, vol, dest, hp) {
    var len = Math.max(1, (ctx.sampleRate * dur) | 0), b = ctx.createBuffer(1, len, ctx.sampleRate), d = b.getChannelData(0);
    for (var i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    var s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
    s.buffer = b; f.type = 'highpass'; f.frequency.value = hp;
    g.gain.setValueAtTime(vol, t0); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    s.connect(f); f.connect(g); g.connect(dest); s.start(t0);
  }
  function kick(t0, dest) {
    var o = ctx.createOscillator(), g = ctx.createGain();
    o.frequency.setValueAtTime(140, t0); o.frequency.exponentialRampToValueAtTime(40, t0 + 0.14);
    g.gain.setValueAtTime(0.9, t0); g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.22);
    o.connect(g); g.connect(dest); o.start(t0); o.stop(t0 + 0.25);
  }
  var A = 57; // A3
  var PENT = [0, 3, 5, 7, 10, 12, 15];
  var synth = {
    menu: { bpm: 70, step: function (i, t, d, spb) {            // slow cinematic pads + sparse melody
      if (i % 16 === 0) { [A - 24, A - 12, A - 5, A].forEach(function (m, k) { osc('sawtooth', N(m) * (1 + k * 0.002), t, spb * 16, 0.07, d, 500); }); }
      if (i % 16 === 8) { [A - 19, A - 12, A - 8].forEach(function (m) { osc('sawtooth', N(m), t, spb * 8, 0.05, d, 450); }); }
      if (i % 4 === 0 && Math.random() < 0.55) osc('triangle', N(A + 12 + PENT[(Math.random() * PENT.length) | 0]), t, spb * 3, 0.07, d);
    } },
    loading: { bpm: 90, step: function (i, t, d, spb) {         // low drone + ticking pulse that rises
      if (i % 16 === 0) { osc('sawtooth', N(A - 24), t, spb * 16, 0.09, d, 300); osc('sawtooth', N(A - 17), t, spb * 16, 0.05, d, 300); }
      if (i % 2 === 0) osc('square', N(A + 12 + (i % 8 === 0 ? 7 : 0)), t, 0.07, 0.04, d, 1800);
      if (i % 8 === 4) noise(t, 0.08, 0.05, d, 6000);
    } },
    game: { bpm: 104, step: function (i, t, d, spb) {           // driving, tense, quiet enough to hear gunfire
      var bar = ((i / 16) | 0) % 4, s = i % 16;
      if (s % 4 === 0) kick(t, d);
      if (s % 2 === 0) noise(t, 0.04, 0.12, d, 8000);
      if (s === 4 || s === 12) noise(t, 0.12, 0.2, d, 1800);
      var root = [A - 24, A - 24, A - 21, A - 19][bar];
      if (s % 2 === 0) osc('sawtooth', N(root), t, spb * 1.6, 0.22, d, 380);
      if (s === 0 && bar % 2 === 1) [0, 3, 7].forEach(function (m) { osc('sawtooth', N(A - 12 + m), t, spb * 6, 0.05, d, 700); });
      if (s === 14) osc('triangle', N(A + 7 + PENT[(Math.random() * PENT.length) | 0]), t, spb * 2, 0.06, d);
    } }
  };

  function startSynth(name) {
    var def = synth[name], g = ctx.createGain(); g.gain.value = 0; g.connect(master);
    var dly = ctx.createDelay(1), fb = ctx.createGain(); dly.delayTime.value = 0.38; fb.gain.value = 0.35;
    dly.connect(fb); fb.connect(dly); dly.connect(g);
    var bus = ctx.createGain(); bus.connect(g); bus.connect(dly);
    var spb = 60 / def.bpm / 4, i = 0, next = ctx.currentTime + 0.1;
    var iv = setInterval(function () { while (next < ctx.currentTime + 0.25) { def.step(i++, next, bus, spb); next += spb; } }, 80);
    return { gain: g, stop: function () { clearInterval(iv); setTimeout(function () { try { g.disconnect(); } catch (e) {} }, 1500); } };
  }
  function startFile(name) {
    var a = new Audio(FILES[name]); a.loop = true; a.volume = 0;
    a.play().catch(function () {});
    var h = { gain: null, el: a, vol: 0 };
    return h;
  }

  function fade(t, to, secs) {
    if (t.el) {
      var from = t.el.volume, st = Date.now();
      var iv = setInterval(function () {
        var k = Math.min(1, (Date.now() - st) / (secs * 1000));
        try { t.el.volume = Math.max(0, Math.min(1, from + (to - from) * k)); } catch (e) {}
        if (k >= 1) clearInterval(iv);
      }, 50);
    } else if (t.gain) {
      var gg = t.gain.gain; gg.cancelScheduledValues(ctx.currentTime);
      gg.setValueAtTime(gg.value, ctx.currentTime); gg.linearRampToValueAtTime(to, ctx.currentTime + secs);
    }
  }

  function play(name) {
    if (!unlocked || cur && cur.name === name) return;
    if (cur) { var old = cur; fade(old.t, 0, 1.2); setTimeout(function () { if (old.t.stop) old.t.stop(); if (old.t.el) old.t.el.pause(); }, 1400); }
    var t = have[name] ? startFile(name) : startSynth(name);
    cur = { name: name, t: t, base: VOL[name] };
    fade(t, muted ? 0 : cur.base * duck, 1.5);
  }

  var duck = 1;
  function setDuck(d) { if (d === duck) return; duck = d; if (cur) fade(cur.t, muted ? 0 : cur.base * duck, 0.6); }

  function vis(id) {
    var e = document.getElementById(id); if (!e) return false;
    var c = getComputedStyle(e);
    return c.display !== 'none' && c.visibility !== 'hidden' && parseFloat(c.opacity) > 0.05;
  }
  function tick() {
    var name = vis('loader') ? 'loading' : vis('menu') ? 'menu' : 'game';
    want = name; play(name);
    var p = document.getElementById('pause'), en = document.getElementById('end');
    setDuck(name === 'game' && ((p && p.classList.contains('on')) || (en && en.classList.contains('on'))) ? 0.4 : 1);
  }

  function unlock() {
    if (unlocked) return;
    try {
      ctx = new (window.AudioContext || window.webkitAudioContext)();
      master = ctx.createGain(); master.gain.value = 1; master.connect(ctx.destination);
      ctx.resume(); unlocked = true; cur = null; tick();
    } catch (e) {}
  }
  ['pointerdown', 'keydown', 'touchstart'].forEach(function (ev) { window.addEventListener(ev, unlock, { once: false, passive: true }); });

  // mute button
  var b = document.createElement('button');
  b.style.cssText = 'position:fixed;left:12px;bottom:12px;z-index:9998;background:#111c;color:#fff;border:1px solid #ffb02e;border-radius:4px;padding:6px 10px;cursor:pointer;font:600 13px Rajdhani,sans-serif';
  function label() { b.textContent = muted ? 'MUSIC: OFF' : 'MUSIC: ON'; }
  b.onclick = function () {
    muted = !muted; label();
    try { localStorage.setItem('nuketown.mute', muted ? '1' : '0'); } catch (e) {}
    if (cur) fade(cur.t, muted ? 0 : cur.base * duck, 0.4);
  };
  label(); document.body.appendChild(b);
  // only show the button on menu / loading / pause so it never covers the HUD
  setInterval(function () { tick(); b.style.display = (want !== 'game' || vis('pause')) ? 'block' : 'none'; }, 300);
})();
