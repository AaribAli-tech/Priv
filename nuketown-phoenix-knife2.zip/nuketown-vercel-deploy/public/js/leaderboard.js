/* NUKETOWN online leaderboard + unique names (Supabase). */
(function () {
  var SUPABASE_URL = 'https://ysauzctrsrjmjcazyhme.supabase.co';
  var SUPABASE_KEY = 'sb_publishable_sEXhgZaPwXBcu8Qct-GioQ_18T420c5';
  var MODES = { tdm: 'Team Deathmatch', ffa: 'Free For All', gun: 'Gun Game', ctl: 'Round Control' };
  var ready = SUPABASE_URL.indexOf('http') === 0 && SUPABASE_KEY.length > 20;
  var H = { apikey: SUPABASE_KEY, 'Content-Type': 'application/json' };
  if (SUPABASE_KEY.indexOf('eyJ') === 0) H.Authorization = 'Bearer ' + SUPABASE_KEY;
  var curMode = 'all', curPer = 'all', cur = null, fixes = 0;

  // ---- who am I (saved on this device until RESET NAME) ----
  function acct() { try { return JSON.parse(localStorage.getItem('nuketown.claim') || 'null'); } catch (e) { return null; } }
  function getName() { var a = acct(); return a ? a.name : ''; }
  function cleanName(n) { return String(n || '').toUpperCase().replace(/[^A-Z0-9 _.\-]/g, '').replace(/\s+/g, ' ').trim().slice(0, 14); }
  function token() {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID() + crypto.randomUUID();
    var s = ''; for (var i = 0; i < 40; i++) s += Math.floor(Math.random() * 36).toString(36); return s;
  }
  function rpc(fn, body, keep) {
    return fetch(SUPABASE_URL + '/rest/v1/rpc/' + fn, { method: 'POST', headers: H, keepalive: !!keep, body: JSON.stringify(body) })
      .then(function (r) { return r.json(); });
  }

  // ---- styles + DOM ----
  var css = document.createElement('style');
  css.textContent =
    '#ntlbBtn,#ntReset{position:fixed;z-index:9998;background:#111c;color:#fff;border:1px solid #ffb02e;padding:8px 14px;' +
    'font:600 14px Rajdhani,sans-serif;letter-spacing:1px;cursor:pointer;border-radius:4px}#ntlbBtn{top:12px;right:12px}' +
    '#ntReset{top:12px;right:150px;border-color:#888}' +
    '#ntlb,#ntSign{position:fixed;inset:0;z-index:9999;background:#000d;display:none;align-items:center;justify-content:center;font-family:Rajdhani,sans-serif;color:#fff}' +
    '#ntSign{z-index:10001;background:#000f}#ntlb.on,#ntSign.on{display:flex}' +
    '.ntbox{background:#14181c;border:1px solid #ffb02e;padding:20px;width:min(520px,94vw);max-height:90vh;overflow:auto;border-radius:6px}' +
    '.ntbox h2{margin:0 0 10px;letter-spacing:2px;color:#ffb02e}.ntbox .tabs button{background:#222;color:#fff;border:0;padding:6px 10px;margin:0 4px 8px 0;cursor:pointer;font:600 13px Rajdhani,sans-serif}' +
    '.ntbox .tabs button.on{background:#ffb02e;color:#000}.ntbox table{width:100%;border-collapse:collapse;font-size:15px}.ntbox td,.ntbox th{padding:4px 6px;text-align:left}' +
    '.ntbox th{color:#999;font-weight:600}.ntbox tr.me td{color:#ffb02e}.ntbox input{padding:8px;width:190px;margin-right:6px;font-size:16px;text-transform:uppercase}' +
    '.ntbox button.go{padding:8px 14px;background:#ffb02e;border:0;font:700 15px Rajdhani,sans-serif;cursor:pointer}.ntbox p{color:#aaa;font-size:14px}' +
    '.x{float:right;cursor:pointer;font-size:20px}.msg{color:#f88;min-height:20px;font-size:14px;margin-top:8px}';
  document.head.appendChild(css);
  function box(id, html) { var d = document.createElement('div'); d.id = id; d.innerHTML = '<div class="ntbox">' + html + '</div>'; document.body.appendChild(d); return d; }
  var $ = function (id) { return document.getElementById(id); };

  var lb = box('ntlb', '<span class="x" id="ntlbX">&times;</span><h2>LEADERBOARD</h2><div class="tabs" id="ntlbPer"></div><div class="tabs" id="ntlbTabs"></div><div id="ntlbBody">Loading...</div><div class="msg" id="ntlbMsg" style="color:#9cf"></div>');
  var sg = box('ntSign', '<h2>CHOOSE YOUR NAME</h2><p>Pick a name for the leaderboard. Names are unique: once someone takes a name, nobody else can ever use it. It is saved on this device until you press RESET NAME.</p>' +
    '<input id="ntName" maxlength="14" placeholder="YOUR NAME" autocomplete="off" spellcheck="false"><button class="go" id="ntClaim">CLAIM NAME</button><div class="msg" id="ntSignMsg"></div>');
  var btn = document.createElement('button'); btn.id = 'ntlbBtn'; btn.textContent = 'LEADERBOARD'; document.body.appendChild(btn);
  var rst = document.createElement('button'); rst.id = 'ntReset'; rst.textContent = 'RESET NAME'; document.body.appendChild(rst);
  ['keydown', 'keyup'].forEach(function (ev) { $('ntName').addEventListener(ev, function (e) { e.stopPropagation(); }); });

  // ---- sign in ----
  function showSign() { $('ntName').value = ''; $('ntSignMsg').textContent = ''; sg.classList.add('on'); setTimeout(function () { $('ntName').focus(); }, 50); }
  function claim() {
    var n = cleanName($('ntName').value), m = $('ntSignMsg');
    if (n.length < 2) { m.textContent = 'Use at least 2 letters or numbers.'; return; }
    if (!ready) { m.textContent = 'Online features are not set up.'; return; }
    m.style.color = '#9cf'; m.textContent = 'Checking...';
    var t = token();
    rpc('claim_name', { p_name: n, p_token: t }).then(function (res) {
      m.style.color = '#f88';
      if (res === 'ok') {
        try { localStorage.setItem('nuketown.claim', JSON.stringify({ name: n, token: t })); } catch (e) {}
        fixes = 0; sg.classList.remove('on');
      } else if (res === 'taken') m.textContent = 'That name is taken. Try another.';
      else m.textContent = 'Invalid name. Use letters, numbers, space, _ . -';
    }).catch(function () { m.style.color = '#f88'; m.textContent = 'No internet. You need a connection to claim a name.'; });
  }
  $('ntClaim').onclick = claim;
  $('ntName').addEventListener('keydown', function (e) { if (e.key === 'Enter') claim(); });
  rst.onclick = function () {
    var a = acct(); if (!a) { showSign(); return; }
    if (!confirm('Reset your name? "' + a.name + '" will be released so anyone can take it, and its leaderboard stats are deleted.')) return;
    rst.textContent = 'RESETTING...';
    rpc('release_name', { p_name: a.name, p_token: a.token }).then(function (res) {
      rst.textContent = 'RESET NAME';
      if (res !== 'ok' && res !== 'denied') throw 0;   // denied = already gone on the server, still fine to reset
      try { localStorage.removeItem('nuketown.claim'); } catch (e) {}
      fixes = 0;
      document.querySelectorAll('.callsignInput').forEach(function (el) { el.readOnly = false; el.value = ''; el.dispatchEvent(new Event('blur')); });
      showSign();
    }).catch(function () { rst.textContent = 'RESET NAME'; alert('Could not reach the server. Connect to the internet and try again.'); });
  };

  // ---- leaderboard view ----
  function tabs() {
    var h = '<button data-m="all" class="' + (curMode === 'all' ? 'on' : '') + '">All Modes</button>';
    for (var k in MODES) h += '<button data-m="' + k + '" class="' + (k === curMode ? 'on' : '') + '">' + MODES[k] + '</button>';
    $('ntlbTabs').innerHTML = h;
    $('ntlbPer').innerHTML = '<button data-p="week" class="' + (curPer === 'week' ? 'on' : '') + '">This Week</button><button data-p="all" class="' + (curPer === 'all' ? 'on' : '') + '">All Time</button>';
  }
  // Rank comes from the row's own stats, so it needs no database change and is the same for every viewer.
  var RANKS = [[0, 'Recruit'], [50, 'Private'], [150, 'Corporal'], [350, 'Sergeant'], [700, 'Lieutenant'], [1300, 'Captain'], [2500, 'Major'], [5000, 'Colonel'], [10000, 'General']];
  function rankOf(r) {
    var pts = (r.kills || 0) + (r.wins || 0) * 20, n = 0;
    for (var i = 0; i < RANKS.length; i++) if (pts >= RANKS[i][0]) n = i;
    return '<span class="ntRk r' + n + '">' + RANKS[n][1] + '</span>';
  }
  (function(){var st=document.createElement('style');st.textContent='\n.ntlbNote{color:#98a4ad;font-size:13px;margin:2px 0 6px;letter-spacing:.06em}.ntlbT1 td{background:#ffd23a22;font-weight:700}.ntlbT2 td{background:#cfd8dc1c}.ntlbT3 td{background:#cd7f3224}.ntlbT td:first-child{font-size:18px}.ntRk{font-weight:700;letter-spacing:.06em;font-size:12px;text-transform:uppercase;color:#98a4ad}.ntRk.r3,.ntRk.r4{color:#7dff8a}.ntRk.r5,.ntRk.r6{color:#5ab0ff}.ntRk.r7{color:#c58bff}.ntRk.r8{color:#ffd23a}';document.head.appendChild(st);})();
  function load(silent) {
    tabs();
    if (!ready) { $('ntlbBody').textContent = 'Leaderboard is not set up yet.'; return; }
    if (!silent) $('ntlbBody').textContent = 'Loading...';
    var wk = curPer === 'week', A = wk ? 'leaderboard_week_all' : 'leaderboard_all', Mv = wk ? 'leaderboard_week_modes' : 'leaderboard_modes';
    var q = curMode === 'all' ? '/rest/v1/' + A + '?select=*&order=kills.desc,wins.desc&limit=25'
      : '/rest/v1/' + Mv + '?select=*&mode=eq.' + curMode + '&order=kills.desc,wins.desc&limit=25';
    function draw(rows, note) {
      var me = getName().toLowerCase();
      var h = (note ? '<div class="ntlbNote" style="color:#ffb02e">' + note + '</div>' : '') + (wk ? '<div class="ntlbNote">Resets every Monday (00:00 UTC)</div>' : '') + '<table><tr><th>#</th><th>Player</th>' + (wk ? '' : '<th>Rank</th>') + '<th>Kills</th><th>K/D</th><th>Wins</th><th>Matches</th></tr>';
      rows.forEach(function (r, i) {
        var kd = r.deaths ? (r.kills / r.deaths).toFixed(2) : r.kills;
        var medal = ['\uD83E\uDD47', '\uD83E\uDD48', '\uD83E\uDD49'][i];
        h += '<tr class="' + (r.name.toLowerCase() === me ? 'me ' : '') + (i < 3 ? 'ntlbT ntlbT' + (i + 1) : '') + '"><td>' + (medal || (i + 1)) + '</td><td>' + r.name.replace(/</g, '&lt;') +
          '</td>' + (wk ? '' : '<td>' + rankOf(r) + '</td>') + '<td>' + r.kills + '</td><td>' + kd + '</td><td>' + r.wins + '</td><td>' + r.matches + '</td></tr>';
      });
      $('ntlbBody').innerHTML = rows.length ? h + '</table>' : (wk ? 'No scores this week yet. Be the first!' : 'No scores yet. Be the first!');
    }
    function fail() { $('ntlbBody').textContent = 'Could not reach the leaderboard. Check your internet connection.'; }
    fetch(SUPABASE_URL + q, { headers: H }).then(function (r) { return r.json(); }).then(function (rows) {
      if (!Array.isArray(rows)) throw 0;
      draw(rows, '');
    }).catch(function () { if (!silent) fail(); });
  }
  // Live: while the board is open it re-reads Supabase every 10 s, so a score someone just
  // posted shows up for everyone without reopening anything.
  setInterval(function () { if (lb.classList.contains('on') && !document.hidden) load(true); }, 10000);
  function open() { lb.classList.add('on'); load(); }
  btn.onclick = open;
  $('ntlbX').onclick = function () { lb.classList.remove('on'); };
  $('ntlbPer').onclick = function (e) { var m = e.target.getAttribute && e.target.getAttribute('data-p'); if (m) { curPer = m; load(); } };
  $('ntlbTabs').onclick = function (e) { var m = e.target.getAttribute && e.target.getAttribute('data-m'); if (m) { curMode = m; load(); } };

  // ---- hidden admin panel (open: tap the LEADERBOARD title 5 times, or Ctrl+Shift+A) ----
  var adCss = document.createElement('style');
  adCss.textContent = '#ntAdmin{position:fixed;inset:0;z-index:10002;background:#000e;display:none;align-items:center;justify-content:center;font-family:Rajdhani,sans-serif;color:#fff}' +
    '#ntAdmin.on{display:flex}#ntAdList .r{display:flex;align-items:center;gap:6px;border-bottom:1px solid #333;padding:6px 0;font-size:15px}' +
    '#ntAdList .r b{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis}#ntAdList .r small{color:#999}' +
    '#ntAdList button{background:#222;color:#fff;border:1px solid #666;padding:4px 8px;cursor:pointer;font:600 12px Rajdhani,sans-serif}' +
    '#ntAdList button.del{border-color:#f55;color:#f88}';
  document.head.appendChild(adCss);
  var ad = box('ntAdmin', '<span class="x" id="ntAdX">&times;</span><h2>ADMIN</h2>' +
    '<div id="ntAdLogin"><input id="ntAdPass" type="password" placeholder="Admin password" style="text-transform:none"><button class="go" id="ntAdGo">LOGIN</button></div>' +
    '<div id="ntAdMain" style="display:none"><input id="ntAdSearch" placeholder="Search name" style="width:140px"><button class="go" id="ntAdFind">SEARCH</button>' +
    '<p>Remove scores = off the leaderboard, name stays taken. Delete name = scores gone and the name is free for anyone.</p><div id="ntAdList"></div></div>' +
    '<div class="msg" id="ntAdMsg"></div>');
  var adPass = '';
  ['ntAdPass', 'ntAdSearch'].forEach(function (id) { ['keydown', 'keyup'].forEach(function (ev) { $(id).addEventListener(ev, function (e) { e.stopPropagation(); }); }); });
  function adMsg(t) { $('ntAdMsg').textContent = t || ''; }
  function adLogout(m) { adPass = ''; $('ntAdMain').style.display = 'none'; $('ntAdLogin').style.display = 'block'; adMsg(m); }
  function openAdmin() { lb.classList.remove('on'); ad.classList.add('on'); if (!adPass) adLogout(''); }
  function adList() {
    adMsg('Loading...');
    rpc('admin_list', { p_pass: adPass, p_search: $('ntAdSearch').value.trim() }).then(function (rows) {
      if (!Array.isArray(rows)) { adLogout('Wrong password.'); return; }
      $('ntAdLogin').style.display = 'none'; $('ntAdMain').style.display = 'block'; adMsg(rows.length + ' player(s)');
      var box2 = $('ntAdList'); box2.innerHTML = '';
      rows.forEach(function (r) {
        var d = document.createElement('div'); d.className = 'r';
        var b = document.createElement('b'); b.textContent = r.name; d.appendChild(b);
        var sm = document.createElement('small'); sm.textContent = r.kills + ' kills / ' + r.matches + ' matches'; d.appendChild(sm);
        [['Remove scores', true, ''], ['Delete name', false, 'del']].forEach(function (x) {
          var bt = document.createElement('button'); bt.textContent = x[0]; bt.className = x[2];
          bt.onclick = function () {
            if (!confirm((x[1] ? 'Remove all scores of ' : 'DELETE the name and scores of ') + r.name + '?')) return;
            rpc('admin_delete', { p_pass: adPass, p_name: r.name, p_keep_name: x[1] }).then(function (res) {
              if (res === 'ok') adList(); else adLogout('Wrong password.');
            }).catch(function () { adMsg('No internet.'); });
          };
          d.appendChild(bt);
        });
        box2.appendChild(d);
      });
    }).catch(function () { adMsg('No internet.'); });
  }
  $('ntAdGo').onclick = function () { adPass = $('ntAdPass').value; $('ntAdPass').value = ''; if (adPass) adList(); };
  $('ntAdPass').addEventListener('keydown', function (e) { if (e.key === 'Enter') $('ntAdGo').onclick(); });
  $('ntAdFind').onclick = adList;
  $('ntAdSearch').addEventListener('keydown', function (e) { if (e.key === 'Enter') adList(); });
  $('ntAdX').onclick = function () { ad.classList.remove('on'); adPass = ''; };
  var tapN = 0, tapT = 0;
  lb.querySelector('h2').addEventListener('click', function () {
    var now = Date.now(); tapN = now - tapT < 1500 ? tapN + 1 : 1; tapT = now;
    if (tapN >= 5) { tapN = 0; openAdmin(); }
  });
  window.addEventListener('keydown', function (e) { if (e.ctrlKey && e.shiftKey && e.code === 'KeyA') { e.preventDefault(); openAdmin(); } });

  // ---- keep the game's callsign locked to the claimed name; show buttons only on the menu ----
  setInterval(function () {
    var m = document.getElementById('menu'), onMenu = m && getComputedStyle(m).display !== 'none';
    btn.style.display = onMenu ? 'block' : 'none'; rst.style.display = onMenu && getName() ? 'block' : 'none';
    var a = getName();
    if (ready && !a && onMenu && !sg.classList.contains('on')) showSign();
    if (a) document.querySelectorAll('.callsignInput').forEach(function (el) {
      el.readOnly = true;
      if (el.value !== a && fixes < 6) { fixes++; el.value = a; el.dispatchEvent(new Event('input')); el.dispatchEvent(new Event('blur')); }
    });
  }, 400);

  // ---- scores ----
  function send(r, keep) {
    var a = acct(); if (!ready || !a || !r || !MODES[r.mode] || (r.kills | 0) < 1) return Promise.resolve();
    return rpc('submit_score', { p_name: a.name, p_token: a.token, p_mode: r.mode,
      p_kills: Math.max(0, Math.min(100, r.kills | 0)), p_deaths: Math.max(0, Math.min(500, r.deaths | 0)), p_won: !!r.won }, keep)
      .then(function (res) { if (res === 'denied') { try { localStorage.removeItem('nuketown.claim'); } catch (e) {} } }).catch(function () {});
  }
  function bail() { if (cur && cur.kills > 0) { var r = cur; cur = null; send(r, true); } }
  window.addEventListener('pagehide', bail);
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') bail(); });

  window.NTLB = {
    live: function (mode, kills, deaths) { cur = { mode: mode, kills: kills, deaths: deaths }; },
    submit: function (r, silent) {
      cur = null; if (!r) return;
      if (silent) { send(r); return; }
      curMode = MODES[r.mode] ? r.mode : 'all'; open();
      $('ntlbMsg').textContent = 'Saving your score...';
      send(r).then(function () { $('ntlbMsg').textContent = 'Score saved!'; load(); });
    }
  };
})();
